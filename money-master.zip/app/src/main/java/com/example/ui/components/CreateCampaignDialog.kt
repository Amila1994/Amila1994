package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import coil.compose.AsyncImage
import com.example.ui.theme.SuccessGreen
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.CoinGold
import com.example.ui.theme.CoinGoldDark
import com.example.ui.theme.RedPrimary
import com.example.data.youtube.YouTubeApiService
import kotlin.math.roundToInt

@Composable
fun CreateCampaignDialog(
    userCoins: Int,
    isAdmin: Boolean = false,
    economyConfig: com.example.data.model.AdminEconomyConfig = com.example.data.model.AdminEconomyConfig(),
    accessToken: String = "",
    onDismiss: () -> Unit,
    onCreate: (
        videoUrl: String,
        videoTitle: String,
        channelName: String,
        channelId: String,
        thumbnailUrl: String,
        campaignType: String,
        targetCount: Int,
        durationSeconds: Int,
        costPerAction: Int,
        isAdminPriority: Boolean,
        isGlobal: Boolean
    ) -> Unit
) {
    var videoUrl by remember { mutableStateOf("") }
    var videoTitle by remember { mutableStateOf("") }
    var channelName by remember { mutableStateOf("") }
    var channelId by remember { mutableStateOf("") }
    var thumbnailUrl by remember { mutableStateOf("") }
    var isFetchingDetails by remember { mutableStateOf(false) }
    var autoFetchSuccess by remember { mutableStateOf(false) }
    var autoFetchMessage by remember { mutableStateOf<String?>(null) }

    var campaignType by remember { mutableStateOf("SUBSCRIBE") } // "SUBSCRIBE", "VIEW", "LIKE"
    var targetCount by remember { mutableIntStateOf(if (isAdmin) 100 else 10) }
    var durationMinutes by remember { mutableIntStateOf(1) } // 1, 2, 3, 5, 10 mins
    var isGlobalPriority by remember { mutableStateOf(isAdmin) }

    // Dynamic cost calculations from Admin economy config:
    val costPerAction by remember(campaignType, durationMinutes, isAdmin, economyConfig) {
        derivedStateOf {
            if (isAdmin) 0
            else when (campaignType) {
                "SUBSCRIBE" -> economyConfig.costPerSubscribe
                "VIEW" -> durationMinutes * economyConfig.costPerWatchMinute
                "LIKE" -> economyConfig.costPerLike
                else -> economyConfig.costPerSubscribe
            }
        }
    }

    val totalCost by remember(targetCount, costPerAction, isAdmin) {
        derivedStateOf { if (isAdmin) 0 else targetCount * costPerAction }
    }

    val canAfford by remember(userCoins, totalCost, isAdmin) {
        derivedStateOf { isAdmin || userCoins >= totalCost }
    }

    var isPlayingCampaignAd by remember { mutableStateOf(false) }
    var campaignAdCountdown by remember { mutableIntStateOf(5) }
    val extractedVideoId: String = remember(videoUrl) { YouTubeApiService.extractVideoId(videoUrl) }
    val isValidUrl = videoUrl.isNotBlank() && extractedVideoId.isNotBlank()

    // Automatic Fetch Logic:
    // When the user pastes or types a valid YouTube video URL,
    // automatically query YouTube Data API v3 and prefill Video Title, Channel Name, and Thumbnail!
    LaunchedEffect(videoUrl) {
        val trimmed = videoUrl.trim()
        val videoId = YouTubeApiService.extractVideoId(trimmed)
        if (videoId.isNotBlank()) {
            isFetchingDetails = true
            autoFetchMessage = "Fetching video details from YouTube..."
            // Debounce 350ms so user pasting completes cleanly
            delay(350L)
            val result = YouTubeApiService.fetchVideoDetails(videoId, accessToken)
            isFetchingDetails = false
            result.onSuccess { details ->
                if (details.title.isNotBlank()) {
                    videoTitle = details.title
                }
                if (details.channelTitle.isNotBlank()) {
                    channelName = details.channelTitle
                }
                if (details.channelId.isNotBlank()) {
                    channelId = details.channelId
                }
                if (details.thumbnailUrl.isNotBlank()) {
                    thumbnailUrl = details.thumbnailUrl
                }
                autoFetchSuccess = true
                autoFetchMessage = "✓ Auto-fetched from YouTube"
            }.onFailure { err ->
                autoFetchSuccess = false
                autoFetchMessage = "Could not auto-fetch title. You can type it manually."
            }
        } else {
            isFetchingDetails = false
            autoFetchSuccess = false
            autoFetchMessage = null
        }
    }

    LaunchedEffect(isPlayingCampaignAd) {
        if (isPlayingCampaignAd) {
            campaignAdCountdown = 5
            for (i in 5 downTo 1) {
                campaignAdCountdown = i
                delay(1000L)
            }
            isPlayingCampaignAd = false
            val vid = if (extractedVideoId.isNotBlank()) extractedVideoId else "video"
            val realThumb = if (thumbnailUrl.isNotBlank()) thumbnailUrl else "https://img.youtube.com/vi/$vid/hqdefault.jpg"
            val resolvedChannelId = if (channelId.startsWith("UC")) {
                channelId
            } else {
                YouTubeApiService.resolveChannelIdFromVideo(videoUrl)
            }
            onCreate(
                videoUrl.trim(),
                videoTitle.trim().ifBlank { "Promoted Video" },
                channelName.trim().ifBlank { "YouTube Creator" },
                resolvedChannelId,
                realThumb,
                campaignType,
                targetCount,
                durationMinutes * 60,
                costPerAction,
                isGlobalPriority,
                isGlobalPriority
            )
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("create_campaign_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Create Promotion Campaign",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Campaign Type Chips
                Text(
                    text = "Select Campaign Goal",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GoalChip(
                        label = "Subscribers",
                        sub = "10 coins/sub",
                        icon = Icons.Default.Subscriptions,
                        selected = campaignType == "SUBSCRIBE",
                        onClick = { campaignType = "SUBSCRIBE" }
                    )
                    GoalChip(
                        label = "Watch Views",
                        sub = "5 coins/min",
                        icon = Icons.Default.Visibility,
                        selected = campaignType == "VIEW",
                        onClick = { campaignType = "VIEW" }
                    )
                    GoalChip(
                        label = "Likes",
                        sub = "5 coins/like",
                        icon = Icons.Default.ThumbUp,
                        selected = campaignType == "LIKE",
                        onClick = { campaignType = "LIKE" }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Video URL Input with Auto-Fetch indicator
                OutlinedTextField(
                    value = videoUrl,
                    onValueChange = { videoUrl = it },
                    label = { Text("YouTube Video URL") },
                    placeholder = { Text("https://youtu.be/... or https://youtube.com/watch?v=...") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("campaign_url_input"),
                    trailingIcon = {
                        if (isFetchingDetails) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = RedPrimary
                            )
                        } else if (autoFetchSuccess) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Auto-fetched",
                                tint = SuccessGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RedPrimary,
                        cursorColor = RedPrimary
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Next
                    )
                )

                // Status indication below Video URL
                if (isFetchingDetails) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp, color = RedPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Auto-fetching Video Title & Channel Name from YouTube...",
                            fontSize = 11.sp,
                            color = RedPrimary
                        )
                    }
                } else if (autoFetchSuccess) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "✓ Title & Channel auto-filled from YouTube Data API",
                            fontSize = 11.sp,
                            color = SuccessGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Thumbnail & Video Preview Card when videoId is valid
                if (extractedVideoId.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = 80.dp, height = 48.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black)
                            ) {
                                val thumb = if (thumbnailUrl.isNotBlank()) thumbnailUrl else "https://img.youtube.com/vi/$extractedVideoId/hqdefault.jpg"
                                AsyncImage(
                                    model = thumb,
                                    contentDescription = "Video Thumbnail",
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = videoTitle.ifBlank { "Fetching title..." },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                                Text(
                                    text = channelName.ifBlank { "Fetching channel..." },
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Video Title
                OutlinedTextField(
                    value = videoTitle,
                    onValueChange = { videoTitle = it },
                    label = { Text("Video Title") },
                    placeholder = { Text("Auto-fetched from YouTube URL") },
                    supportingText = if (autoFetchSuccess) {
                        { Text("Auto-filled from YouTube (editable)", fontSize = 11.sp, color = SuccessGreen) }
                    } else null,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RedPrimary,
                        cursorColor = RedPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Channel Name
                OutlinedTextField(
                    value = channelName,
                    onValueChange = { channelName = it },
                    label = { Text("Channel Name") },
                    placeholder = { Text("Auto-fetched from YouTube URL") },
                    supportingText = if (autoFetchSuccess) {
                        { Text("Auto-filled from YouTube (editable)", fontSize = 11.sp, color = SuccessGreen) }
                    } else null,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RedPrimary,
                        cursorColor = RedPrimary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Required Watch Duration: $durationMinutes Minute${if (durationMinutes > 1) "s" else ""} (${durationMinutes * 60}s)",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 2, 3, 5, 10).forEach { min ->
                        FilterChip(
                            selected = durationMinutes == min,
                            onClick = { durationMinutes = min },
                            label = { Text("${min}m") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = RedPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Admin Global Campaign Switch (Only visible for Admin)
                if (isAdmin) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = RedPrimary.copy(alpha = 0.12f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RedPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "🌐 Global Priority Broadcast",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = RedPrimary
                                )
                                Text(
                                    text = "Broadcast to all users in app. Delivery within 24 hours.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            androidx.compose.material3.Switch(
                                checked = isGlobalPriority,
                                onCheckedChange = { isGlobalPriority = it },
                                colors = androidx.compose.material3.SwitchDefaults.colors(
                                    checkedThumbColor = RedPrimary,
                                    checkedTrackColor = RedPrimary.copy(alpha = 0.5f)
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Target Quantity Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Target Quantity: $targetCount",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (isAdmin) "Free (Admin)" else "$costPerAction Coins each",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Slider(
                    value = targetCount.toFloat(),
                    onValueChange = { targetCount = it.roundToInt() },
                    valueRange = if (isAdmin) 10f..500f else 5f..100f,
                    steps = if (isAdmin) 48 else 18,
                    modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(
                        thumbColor = RedPrimary,
                        activeTrackColor = RedPrimary
                    )
                )

                // Cost Summary Card
                Spacer(modifier = Modifier.height(14.dp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (canAfford)
                            CoinGold.copy(alpha = 0.12f)
                        else
                            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Total Campaign Cost:",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = CoinGoldDark,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isAdmin) "FREE (Admin Access)" else "$totalCost Coins",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (canAfford) CoinGoldDark else MaterialTheme.colorScheme.error
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Your Current Balance:",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "$userCoins Coins",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        if (!canAfford) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "⚠️ You need ${totalCost - userCoins} more coins! Watch videos or claim daily ads to earn coins.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Submit Button
                Button(
                    onClick = {
                        isPlayingCampaignAd = true
                    },
                    enabled = canAfford && isValidUrl && !isPlayingCampaignAd,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_campaign_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RedPrimary,
                        disabledContainerColor = Color(0xFF666666)
                    )
                ) {
                    if (isPlayingCampaignAd) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("දැන්වීම වාදනය වේ ($campaignAdCountdown s)...", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    } else {
                        Text(
                            text = if (!isValidUrl && videoUrl.isNotBlank()) "Enter Valid YouTube URL" else if (isAdmin) "Launch Global Admin Campaign (Free)" else if (canAfford) "Launch Campaign ($totalCost Coins)" else "Not Enough Coins",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }

                if (isPlayingCampaignAd) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CoinGold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.LiveTv, contentDescription = null, tint = CoinGold, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Sponsored Campaign Ad", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Campaign එක සක්‍රීය කිරීමට පෙර අනුග්‍රාහක දැන්වීම වාදනය වේ ($campaignAdCountdown s)...", color = Color.LightGray, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GoalChip(
    label: String,
    sub: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) RedPrimary else MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = sub,
                fontSize = 9.sp,
                color = if (selected) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
