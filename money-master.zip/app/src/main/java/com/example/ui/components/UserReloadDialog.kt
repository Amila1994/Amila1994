package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.ReloadRequestEntity
import com.example.data.local.entity.UserEntity
import com.example.data.model.AdminEconomyConfig
import com.example.ui.theme.CoinGoldDark
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UserReloadDialog(
    user: UserEntity?,
    economyConfig: AdminEconomyConfig,
    userHistory: List<ReloadRequestEntity>,
    onDismiss: () -> Unit,
    onSubmitReload: (phone: String, operator: String, type: String, amountLkr: Int) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = New Reload, 1 = History
    var phoneNumber by remember { mutableStateOf("") }
    var selectedOperator by remember { mutableStateOf("Dialog") }
    var connectionType by remember { mutableStateOf("PREPAID") } // PREPAID or POSTPAID
    var amountLkrText by remember { mutableStateOf("100") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val isAdmin = com.example.data.firebase.FirebaseService.isAppAdmin(user?.email)
    val userTotalCoins = user?.coins ?: 0

    // Strict requirement: Only coins earned by completing video tasks (watch + sub + like + comment)
    val eligibleCoins = if (isAdmin || (user?.eligibleReloadCoins ?: 0) > 0) {
        (user?.eligibleReloadCoins ?: 0).coerceAtLeast(userTotalCoins)
    } else {
        user?.eligibleReloadCoins ?: 0
    }

    val coinsPerLkr = economyConfig.coinsPerLkrReload.coerceAtLeast(1)
    val maxReloadPossibleLkr = eligibleCoins / coinsPerLkr

    val amountLkr = amountLkrText.toIntOrNull() ?: 0
    val requiredCoins = amountLkr * coinsPerLkr
    val hasEnoughCoins = eligibleCoins >= requiredCoins && requiredCoins > 0

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .wrapContentHeight()
                .heightIn(min = 200.dp, max = 660.dp)
                .testTag("user_reload_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(SuccessGreen.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = SuccessGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Mobile Reload Service",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "උපයාගත් කොයින් වලින් Reload දාගන්න",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Service Status Warning if Disabled
                if (!economyConfig.isReloadServiceActive) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = RedPrimary.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = RedPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Reload පහසුකම ඇඩ්මින් විසින් තාවකාලිකව අත්හිටුවා ඇත (Service is currently paused).",
                                fontSize = 11.sp,
                                color = RedPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Balance & Eligibility Card
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CoinGoldDark.copy(alpha = 0.12f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Eligible Video Coins:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = CoinGoldDark, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("$eligibleCoins Coins", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = CoinGoldDark)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("Max Reload Available:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    "Rs. $maxReloadPossibleLkr",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = SuccessGreen
                                )
                            }
                        }

                        if (!isAdmin && eligibleCoins <= 0) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "💡 Reload ලබා ගත හැක්කේ වීඩියෝ නරඹා (Watch), Subscribe, Like සහ Comment යන සියල්ල සම්පූර්ණ කර උපයාගත් කොයින් වලින් පමණි.",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Tabs: New Request & History
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = RedPrimary
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Request Reload", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("My History (${userHistory.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (selectedTab == 0) {
                    // New Reload Request Form
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            // Phone Number Field
                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = {
                                    phoneNumber = it.filter { ch -> ch.isDigit() }
                                    errorMessage = null
                                },
                                label = { Text("Reload කල යුතු දුරකථන අංකය (Phone Number)") },
                                placeholder = { Text("07XXXXXXXX") },
                                leadingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            // Operator Selection
                            Text("සිම් වර්ගය (Operator):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val operators = listOf("Dialog", "Mobitel", "Airtel", "Hutch")
                                operators.forEach { op ->
                                    FilterChip(
                                        selected = selectedOperator == op,
                                        onClick = { selectedOperator = op },
                                        label = { Text(op, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                        modifier = Modifier.weight(1f),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = SuccessGreen,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                        }

                        item {
                            // Connection Type: Prepaid or Postpaid
                            Text("සම්බන්ධතා වර්ගය (Connection Type):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = connectionType == "PREPAID",
                                    onClick = { connectionType = "PREPAID" },
                                    label = { Text("Prepaid", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.weight(1f),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = RedPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                                FilterChip(
                                    selected = connectionType == "POSTPAID",
                                    onClick = { connectionType = "POSTPAID" },
                                    label = { Text("Postpaid (Bill)", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.weight(1f),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = RedPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        item {
                            // Reload Amount
                            Text("මුදල (Amount in LKR):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = amountLkrText,
                                onValueChange = {
                                    amountLkrText = it.filter { ch -> ch.isDigit() }
                                    errorMessage = null
                                },
                                label = { Text("Reload Amount (Rs.)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Preset Amount Chips
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                listOf("50", "100", "200", "500", "1000").forEach { preset ->
                                    SuggestionChip(
                                        onClick = { amountLkrText = preset },
                                        label = { Text("Rs. $preset", fontSize = 11.sp) },
                                        colors = SuggestionChipDefaults.suggestionChipColors(
                                            containerColor = if (amountLkrText == preset) SuccessGreen.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                    )
                                }
                            }
                        }

                        item {
                            // Calculation & Coin Check Summary
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (hasEnoughCoins) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("කැපෙන කොයින් ප්‍රමාණය (Required):", fontSize = 11.sp)
                                        Text(
                                            "$requiredCoins Coins",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (hasEnoughCoins) Color(0xFF2E7D32) else Color(0xFFC62828)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    if (!hasEnoughCoins) {
                                        Text(
                                            text = "❌ ප්‍රමාණවත් කොයින් නොමැත! ඔබට තවත් ${(requiredCoins - eligibleCoins)} කොයින් අවශ්‍යයි.",
                                            color = Color(0xFFC62828),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    } else {
                                        Text(
                                            text = "✓ ප්‍රමාණවත් කොයින් ඇත. ඇඩ්මින් අනුමත කල පසු පමණක් කොයින් කැපී යයි.",
                                            color = Color(0xFF2E7D32),
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }

                        errorMessage?.let { err ->
                            item {
                                Text(err, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                            }
                        }

                        item {
                            Button(
                                onClick = {
                                    if (phoneNumber.length < 9) {
                                        errorMessage = "කරුණාකර නිවැරදි දුරකථන අංකයක් ඇතුලත් කරන්න (Invalid phone number)."
                                        return@Button
                                    }
                                    if (amountLkr <= 0) {
                                        errorMessage = "කරුණාකර මුදලක් ඇතුලත් කරන්න."
                                        return@Button
                                    }
                                    if (!hasEnoughCoins) {
                                        errorMessage = "ප්‍රමාණවත් කොයින් නොමැත."
                                        return@Button
                                    }
                                    onSubmitReload(phoneNumber, selectedOperator, connectionType, amountLkr)
                                    selectedTab = 1 // Switch to history tab to show pending status
                                },
                                enabled = economyConfig.isReloadServiceActive && hasEnoughCoins && phoneNumber.isNotBlank(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                                    .testTag("submit_reload_button")
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Request Reload (Rs. $amountLkr)", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                } else {
                    // Reload History List
                    if (userHistory.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "තවමත් කිසිදු Reload එකක් ඉල්ලුම් කර නොමැත (No history).",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f, fill = false),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(userHistory, key = { it.id }) { item ->
                                ReloadHistoryItemCard(item = item, dateFormat = dateFormat)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReloadHistoryItemCard(
    item: ReloadRequestEntity,
    dateFormat: SimpleDateFormat
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(item.phoneNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("(${item.operator} • ${item.connectionType})", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                // Status Badge
                Box(
                    modifier = Modifier
                        .background(
                            when (item.status) {
                                "APPROVED" -> Color(0xFF2E7D32)
                                "REJECTED" -> Color(0xFFC62828)
                                else -> Color(0xFFF57C00) // Pending
                            },
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = when (item.status) {
                            "APPROVED" -> "Successful ✓"
                            "REJECTED" -> "Rejected ✗"
                            else -> "Pending ⏳"
                        },
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Amount: Rs. ${item.amountLkr} (${item.coinsRequired} Coins)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = dateFormat.format(Date(item.timestamp)),
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (item.adminNote.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Note: ${item.adminNote}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
