package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AppUpdateConfig
import com.example.ui.theme.RedPrimary

@Composable
fun AdminUpdateSettingsDialog(
    currentConfig: AppUpdateConfig,
    onDismiss: () -> Unit,
    onPublishUpdate: (AppUpdateConfig, sendNotification: Boolean) -> Unit,
    onClearUpdate: () -> Unit
) {
    var versionName by remember { mutableStateOf(if (currentConfig.versionName == "1.0") "1.1" else currentConfig.versionName) }
    var versionCode by remember { mutableStateOf(if (currentConfig.requiredVersionCode <= 1) "2" else currentConfig.requiredVersionCode.toString()) }
    var updateTitle by remember { mutableStateOf(currentConfig.updateTitle) }
    var updateMessage by remember { mutableStateOf(currentConfig.updateMessage) }
    var downloadUrl by remember { mutableStateOf(currentConfig.downloadUrl) }
    var directApkDownloadUrl by remember { mutableStateOf(currentConfig.directApkDownloadUrl) }
    var tutorialVideoUrl by remember { mutableStateOf(currentConfig.tutorialVideoUrl) }
    var announcementImageUrl by remember { mutableStateOf(currentConfig.announcementImageUrl) }
    var requireVideoWatch by remember { mutableStateOf(currentConfig.requireVideoWatch) }
    var isMandatory by remember { mutableStateOf(currentConfig.isMandatory) }
    var sendNotification by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("admin_update_settings_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(RedPrimary.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SystemUpdate,
                                contentDescription = null,
                                tint = RedPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "App Updates & Push",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "PlayStore, Direct APK, Video/Photo Notice",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(14.dp))

                // Version Code & Name
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = versionName,
                        onValueChange = { versionName = it },
                        label = { Text("Version Name") },
                        placeholder = { Text("1.1") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = versionCode,
                        onValueChange = { versionCode = it.filter { c -> c.isDigit() } },
                        label = { Text("Version Code") },
                        placeholder = { Text("2") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = updateTitle,
                    onValueChange = { updateTitle = it },
                    label = { Text("Update Notification Title") },
                    placeholder = { Text("Sub Exchange Update Available!") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = updateMessage,
                    onValueChange = { updateMessage = it },
                    label = { Text("Update Release Notes & Message") },
                    placeholder = { Text("Please update to continue watching videos.") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 4
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = downloadUrl,
                    onValueChange = { downloadUrl = it },
                    label = { Text("Play Store / Store Link") },
                    placeholder = { Text("https://play.google.com/...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Direct APK Link (If not on Play Store)
                OutlinedTextField(
                    value = directApkDownloadUrl,
                    onValueChange = { directApkDownloadUrl = it },
                    label = { Text("Direct APK Download Link (Play Store නැතිනම්)") },
                    placeholder = { Text("https://example.com/subexchange-v1.1.apk") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Video Announcement URL
                OutlinedTextField(
                    value = tutorialVideoUrl,
                    onValueChange = { tutorialVideoUrl = it },
                    label = { Text("Update / Explanatory Video URL (YouTube or Web)") },
                    placeholder = { Text("https://www.youtube.com/watch?v=...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Announcement Image / Poster Photo URL
                OutlinedTextField(
                    value = announcementImageUrl,
                    onValueChange = { announcementImageUrl = it },
                    label = { Text("Update Announcement Photo / Banner URL") },
                    placeholder = { Text("https://images.unsplash.com/...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Require Video Watch Toggle (Speed up blocked, user must watch to proceed)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (requireVideoWatch) Color(0xFFFFF3E0) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Require Video Watch (Normal Speed)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (requireVideoWatch) Color(0xFFE65100) else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "User must watch update video at normal speed (cannot speed up or skip) before entering app",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = requireVideoWatch,
                            onCheckedChange = { requireVideoWatch = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFFE65100),
                                checkedTrackColor = Color(0xFFE65100).copy(alpha = 0.5f)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Mandatory Update Toggle
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isMandatory) Color(0xFFFFEBEE) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Mandatory Update Lock",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (isMandatory) Color(0xFFC62828) else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Block video watching until user updates to this version",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isMandatory,
                            onCheckedChange = { isMandatory = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = RedPrimary,
                                checkedTrackColor = RedPrimary.copy(alpha = 0.5f)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Send Notification Toggle
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Send System Notification",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Dispatch status bar notification to user's device",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = sendNotification,
                            onCheckedChange = { sendNotification = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = RedPrimary,
                                checkedTrackColor = RedPrimary.copy(alpha = 0.5f)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Publish Button
                Button(
                    onClick = {
                        val parsedCode = versionCode.toIntOrNull() ?: 2
                        val updated = currentConfig.copy(
                            versionName = versionName.ifBlank { "1.1" },
                            requiredVersionCode = parsedCode,
                            updateTitle = updateTitle.ifBlank { "Sub Exchange Update Available" },
                            updateMessage = updateMessage.ifBlank { "A new update is available. Please update the app to continue." },
                            downloadUrl = downloadUrl.ifBlank { "https://play.google.com/store/apps/details?id=com.sub4sub.exchangeapp" },
                            directApkDownloadUrl = directApkDownloadUrl,
                            tutorialVideoUrl = tutorialVideoUrl,
                            announcementImageUrl = announcementImageUrl,
                            requireVideoWatch = requireVideoWatch,
                            isMandatory = isMandatory,
                            lastAnnouncedTimestamp = System.currentTimeMillis()
                        )
                        onPublishUpdate(updated, sendNotification)
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("publish_update_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RedPrimary)
                ) {
                    Icon(
                        imageVector = if (sendNotification) Icons.Default.NotificationsActive else Icons.Default.Send,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (sendNotification) "Publish Update & Send Notification" else "Save Update Configuration",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Clear/Reset Update Restriction Button
                OutlinedButton(
                    onClick = {
                        onClearUpdate()
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("clear_update_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Clear Update Lock (Unblock Videos)",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
