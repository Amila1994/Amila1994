package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.youtube.YouTubeApiService
import com.example.data.youtube.YouTubeAuthAndVerification
import com.example.ui.theme.CoinGold
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * YouTube Sub & Like Verification Screen
 * Allows users to open the YouTube video in the official YouTube application,
 * subscribe to the channel, and verify their subscription status in real-time
 * via YouTube Data API v3 (`subscriptions?part=snippet&mine=true&forChannelId=UC...`).
 *
 * Automatically resolves the actual YouTube Channel ID (UC...) even if a channel title
 * like 'PN FUNNY SHORTS' is initially passed.
 * Automatically requests and retrieves the Google OAuth Access Token (ya29...) so it never remains blank.
 */
@Composable
fun YouTubeVerificationScreen(
    channelId: String,
    videoUrl: String,
    channelName: String = "",
    accessToken: String = "", // Google OAuth Access Token
    coinReward: Int,
    onVerifiedSuccess: () -> Unit,
    onVerificationFailed: (String) -> Unit,
    onBackPressed: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isChecking by remember { mutableStateOf(false) }
    var verificationStatus by remember { mutableStateOf("") }

    // If channelId is already a valid 24-character UC... channel ID, use it. Otherwise, initialize as blank to resolve.
    val initialValidChannelId = remember(channelId) {
        val trimmed = channelId.trim()
        if (trimmed.startsWith("UC") && trimmed.length == 24) trimmed else ""
    }

    var effectiveChannelId by remember(channelId) { mutableStateOf(initialValidChannelId) }
    var displayChannelName by remember(channelName, channelId) {
        val name = if (channelName.isNotBlank()) {
            channelName.trim()
        } else if (!channelId.trim().startsWith("UC")) {
            channelId.trim()
        } else {
            ""
        }
        mutableStateOf(name)
    }

    var effectiveToken by remember(accessToken) { mutableStateOf(accessToken.trim()) }
    var isResolvingChannelId by remember { mutableStateOf(false) }
    var isAcquiringToken by remember { mutableStateOf(false) }
    var showManualTokenSection by remember { mutableStateOf(false) }
    var copiedToClipboard by remember { mutableStateOf(false) }

    if (onBackPressed != null) {
        BackHandler {
            onBackPressed()
        }
    }

    // 1. Auto-request Google Sign-in OAuth Access Token if token is blank
    LaunchedEffect(accessToken) {
        if (effectiveToken.isBlank()) {
            isAcquiringToken = true
            val acquiredToken = YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(context)
            if (!acquiredToken.isNullOrBlank()) {
                effectiveToken = acquiredToken.trim()
            }
            isAcquiringToken = false
        }
    }

    // 2. Auto-resolve the actual YouTube Channel ID (UC...) from videoUrl or channelName if missing
    LaunchedEffect(videoUrl, channelId, channelName) {
        if (effectiveChannelId.isBlank()) {
            isResolvingChannelId = true

            // Attempt 1: Resolve from videoUrl
            var resolved = if (videoUrl.isNotBlank()) {
                YouTubeApiService.resolveChannelIdFromVideo(videoUrl)
            } else ""

            // Attempt 2: If blank, try resolving from video details (oEmbed / YouTube API)
            if (resolved.isBlank() && videoUrl.isNotBlank()) {
                val detailsResult = YouTubeApiService.fetchVideoDetails(videoUrl, effectiveToken.ifBlank { null })
                detailsResult.getOrNull()?.let { details ->
                    if (details.channelId.startsWith("UC")) {
                        resolved = details.channelId
                    }
                    if (displayChannelName.isBlank() && details.channelTitle.isNotBlank()) {
                        displayChannelName = details.channelTitle
                    }
                }
            }

            // Attempt 3: If still blank, resolve from channelId string or channelName
            if (resolved.isBlank() && channelId.isNotBlank()) {
                resolved = YouTubeApiService.resolveChannelIdFromVideo(channelId)
            }
            if (resolved.isBlank() && channelName.isNotBlank()) {
                resolved = YouTubeApiService.resolveChannelIdFromVideo(channelName)
            }

            if (resolved.isNotBlank() && resolved.startsWith("UC")) {
                effectiveChannelId = resolved
            }
            isResolvingChannelId = false
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            if (onBackPressed != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBackPressed,
                        modifier = Modifier.testTag("verify_screen_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "YouTube Verification",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header icon badge
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(RedPrimary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Subscriptions,
                    contentDescription = null,
                    tint = RedPrimary,
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "YouTube Sub & Like Verification",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "නාලිකාව Subscribe කර App එකට පැමිණ Verify ක්ලික් කරන්න.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Reward Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Reward for Task",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Verified Subscription",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(CoinGold)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "+$coinReward Coins",
                                color = Color.Black,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Target Channel & Verification Info Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Display Channel Name
                    if (displayChannelName.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Channel:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.width(80.dp)
                            )
                            Text(
                                text = displayChannelName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // Display Actual YouTube Channel ID (UC...)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Channel ID:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(80.dp)
                        )

                        if (isResolvingChannelId) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(12.dp),
                                    strokeWidth = 1.5.dp,
                                    color = RedPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Resolving UC... ID",
                                    fontSize = 12.sp,
                                    color = RedPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        } else if (effectiveChannelId.isNotBlank()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = effectiveChannelId,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF2E7D32),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Channel ID", effectiveChannelId)
                                        clipboard.setPrimaryClip(clip)
                                        copiedToClipboard = true
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = if (copiedToClipboard) Icons.Default.CheckCircle else Icons.Default.ContentCopy,
                                        contentDescription = "Copy Channel ID",
                                        tint = if (copiedToClipboard) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = "Resolving from video...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // OAuth Access Token Status indicator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "OAuth Token:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(80.dp)
                        )

                        if (isAcquiringToken) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(12.dp),
                                    strokeWidth = 1.5.dp,
                                    color = RedPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Auto-requesting Google Token...",
                                    fontSize = 11.sp,
                                    color = RedPrimary
                                )
                            }
                        } else if (effectiveToken.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF2E7D32),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Active (${effectiveToken.take(8)}...)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        } else {
                            Text(
                                text = "Pending sign-in token",
                                fontSize = 11.sp,
                                color = Color(0xFFC62828)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Step 1: Open YouTube Video Button
            Button(
                onClick = {
                    val targetUrl = videoUrl.ifBlank { "https://www.youtube.com" }
                    val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                        setPackage("com.google.android.youtube")
                    }
                    try {
                        context.startActivity(appIntent)
                    } catch (_: Exception) {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)))
                        } catch (_: Exception) {}
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("open_youtube_video_button")
            ) {
                Icon(
                    imageVector = Icons.Default.OpenInNew,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Open Video & Subscribe on YouTube",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Step 2: Real-Time Verify Button via YouTube Data API v3
            Button(
                onClick = {
                    isChecking = true
                    verificationStatus = "Preparing YouTube Data API v3 real-time verification..."

                    coroutineScope.launch {
                        // 1. Automatically acquire OAuth Access Token if blank
                        var tokenToUse = effectiveToken.trim()
                        if (tokenToUse.isBlank()) {
                            verificationStatus = "Requesting Google Sign-in OAuth Access Token..."
                            val acquired = YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(context)
                            if (!acquired.isNullOrBlank()) {
                                tokenToUse = acquired.trim()
                                effectiveToken = tokenToUse
                            }
                        }

                        // 2. Automatically resolve Channel ID if missing or non-UC format
                        var channelToVerify = effectiveChannelId.trim()
                        if (channelToVerify.isBlank() || !channelToVerify.startsWith("UC")) {
                            verificationStatus = "Resolving YouTube Channel ID (UC...)..."
                            val resolved = if (videoUrl.isNotBlank()) {
                                YouTubeApiService.resolveChannelIdFromVideo(videoUrl)
                            } else ""
                            if (resolved.isNotBlank() && resolved.startsWith("UC")) {
                                channelToVerify = resolved
                                effectiveChannelId = resolved
                            } else if (displayChannelName.isNotBlank()) {
                                val resolvedFromTitle = YouTubeApiService.resolveChannelIdFromVideo(displayChannelName)
                                if (resolvedFromTitle.isNotBlank() && resolvedFromTitle.startsWith("UC")) {
                                    channelToVerify = resolvedFromTitle
                                    effectiveChannelId = resolvedFromTitle
                                }
                            }
                        }

                        // 3. Validation checks
                        if (tokenToUse.isBlank()) {
                            isChecking = false
                            verificationStatus = "Error: Google OAuth Access Token missing. Please sign in with Google or paste token."
                            onVerificationFailed("Google OAuth token required for YouTube verification.")
                            showManualTokenSection = true
                            return@launch
                        }

                        if (channelToVerify.isBlank() || !channelToVerify.startsWith("UC")) {
                            isChecking = false
                            verificationStatus = "Error: Target Channel ID missing or unresolved. Please verify video link."
                            onVerificationFailed("Could not resolve 24-character YouTube Channel ID (UC...).")
                            return@launch
                        }

                        // 4. Query YouTube Data API v3 checkUserSubscription
                        verificationStatus = "Querying YouTube Data API v3 for subscription ($channelToVerify)..."
                        val isSubscribed = checkUserSubscription(tokenToUse, channelToVerify)
                        if (!isSubscribed) {
                            isChecking = false
                            verificationStatus = "Error: You have not subscribed to this channel yet on YouTube!"
                            onVerificationFailed("Please subscribe to the channel first on YouTube to verify!")
                            return@launch
                        }

                        // 5. Query YouTube Data API v3 checkUserVideoLike
                        val videoId = YouTubeApiService.extractVideoId(videoUrl)
                        if (videoId.isNotBlank()) {
                            verificationStatus = "Querying YouTube Data API v3 for video like ($videoId)..."
                            val isLiked = checkUserVideoLike(tokenToUse, videoId)
                            if (!isLiked) {
                                isChecking = false
                                verificationStatus = "Error: You have not liked this video yet on YouTube!"
                                onVerificationFailed("Please like the video on YouTube first to verify!")
                                return@launch
                            }
                        }

                        isChecking = false
                        verificationStatus = "Verified in real-time via YouTube Data API v3! Rewarding coins..."
                        onVerifiedSuccess()
                    }
                },
                enabled = !isChecking,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1B5E20),
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("verify_subscription_button")
            ) {
                if (isChecking) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Verifying Subscription...", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Verify & Return App", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Verification status banner
            if (verificationStatus.isNotEmpty()) {
                val isError = verificationStatus.contains("Error") || verificationStatus.contains("failed")
                val isSuccess = verificationStatus.contains("Verified") || verificationStatus.contains("Rewarding")
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            isError -> Color(0xFFFFEBEE)
                            isSuccess -> Color(0xFFE8F5E9)
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when {
                                isError -> Icons.Default.Error
                                isSuccess -> Icons.Default.CheckCircle
                                else -> Icons.Default.Refresh
                            },
                            contentDescription = null,
                            tint = when {
                                isError -> Color(0xFFC62828)
                                isSuccess -> Color(0xFF2E7D32)
                                else -> MaterialTheme.colorScheme.primary
                            },
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = verificationStatus,
                            color = when {
                                isError -> Color(0xFFC62828)
                                isSuccess -> Color(0xFF2E7D32)
                                else -> MaterialTheme.colorScheme.onSurface
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Optional Manual / Diagnostics Section
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        coroutineScope.launch {
                            isAcquiringToken = true
                            val token = YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(context)
                            if (!token.isNullOrBlank()) {
                                effectiveToken = token
                            }
                            isAcquiringToken = false
                        }
                    },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Re-fetch Token", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = { showManualTokenSection = !showManualTokenSection },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(imageVector = Icons.Default.Key, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (showManualTokenSection) "Hide Manual" else "Manual Token", fontSize = 11.sp)
                }
            }

            if (showManualTokenSection) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = effectiveToken,
                    onValueChange = { effectiveToken = it },
                    label = { Text("OAuth Access Token (Optional Manual Input)") },
                    placeholder = { Text("ya29.a0...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RedPrimary,
                        cursorColor = RedPrimary
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = effectiveChannelId,
                    onValueChange = { effectiveChannelId = it },
                    label = { Text("Target Channel ID (e.g. UC_x5XG1OV2P6uZZ5FSM9Ttw)") },
                    placeholder = { Text("UC...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RedPrimary,
                        cursorColor = RedPrimary
                    )
                )
            }
        }
    }
}

/**
 * YouTube Data API v3 Subscriptions Verification Function
 * Endpoint: GET https://www.googleapis.com/youtube/v3/subscriptions?part=snippet&mine=true&forChannelId=$cleanChannelId
 *
 * @param accessToken OAuth 2.0 Access Token with 'youtube.readonly' or 'youtube' scope.
 * @param channelId Target 24-character YouTube Channel ID starting with UC (e.g., UC_x5XG1OV2P6uZZ5FSM9Ttw).
 */
suspend fun checkUserSubscription(accessToken: String, channelId: String): Boolean {
    return withContext(Dispatchers.IO) {
        try {
            val cleanChannelId = channelId.trim()
            if (cleanChannelId.isBlank() || !cleanChannelId.startsWith("UC")) {
                return@withContext false
            }

            val cleanToken = accessToken.trim()
            if (cleanToken.isBlank()) {
                return@withContext false
            }

            val bearerToken = if (cleanToken.startsWith("Bearer ", ignoreCase = true)) {
                cleanToken
            } else {
                "Bearer $cleanToken"
            }

            val client = OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build()

            // YouTube API endpoint to check if the authenticated user is subscribed to the target channel
            val url = "https://www.googleapis.com/youtube/v3/subscriptions?part=snippet&mine=true&forChannelId=$cleanChannelId"

            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", bearerToken)
                .build()

            val response = client.newCall(request).execute()
            val bodyString = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val jsonObject = JSONObject(bodyString)
                val items = jsonObject.optJSONArray("items")
                return@withContext items != null && items.length() > 0
            }
            false
        } catch (e: Exception) {
            false
        }
    }
}

/**
 * YouTube Data API v3 Video Like Verification Function
 * Endpoint: GET https://www.googleapis.com/youtube/v3/videos/getRating?id=$videoId
 */
suspend fun checkUserVideoLike(accessToken: String, videoId: String): Boolean {
    return withContext(Dispatchers.IO) {
        try {
            val cleanVideoId = videoId.trim()
            if (cleanVideoId.isBlank()) return@withContext false

            val cleanToken = accessToken.trim()
            if (cleanToken.isBlank()) return@withContext false

            val bearerToken = if (cleanToken.startsWith("Bearer ", ignoreCase = true)) {
                cleanToken
            } else {
                "Bearer $cleanToken"
            }

            val client = OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build()

            val url = "https://www.googleapis.com/youtube/v3/videos/getRating?id=$cleanVideoId"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", bearerToken)
                .build()

            val response = client.newCall(request).execute()
            val bodyString = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val jsonObject = JSONObject(bodyString)
                val items = jsonObject.optJSONArray("items")
                if (items != null && items.length() > 0) {
                    val rating = items.getJSONObject(0).optString("rating", "")
                    return@withContext rating.equals("like", ignoreCase = true)
                }
            }
            false
        } catch (e: Exception) {
            false
        }
    }
}
