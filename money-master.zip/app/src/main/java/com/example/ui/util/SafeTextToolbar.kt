package com.example.ui.util

import android.view.View
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.platform.TextToolbar
import androidx.compose.ui.platform.TextToolbarStatus

/**
 * A safe, crash-proof TextToolbar for Jetpack Compose.
 * Completely eliminates DecorView "Destroying unexpected ActionMode instance of TYPE_FLOATING" errors
 * by preventing rogue FloatingActionMode instances from being attached to DecorView during screen transitions.
 */
class SafeTextToolbar(private val view: View) : TextToolbar {

    override var status: TextToolbarStatus = TextToolbarStatus.Hidden
        private set

    override fun showMenu(
        rect: Rect,
        onCopyRequested: (() -> Unit)?,
        onPasteRequested: (() -> Unit)?,
        onCutRequested: (() -> Unit)?,
        onSelectAllRequested: (() -> Unit)?
    ) {
        status = TextToolbarStatus.Shown
    }

    override fun hide() {
        status = TextToolbarStatus.Hidden
    }
}
