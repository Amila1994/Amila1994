package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.UserEntity
import com.example.ui.theme.CoinGold
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen
import kotlinx.coroutines.delay

@Composable
fun AccountBannedScreen(
    user: UserEntity,
    isWatchingAd: Boolean,
    adCountdown: Int,
    statusMessage: String?,
    onWatchAd: () -> Unit,
    onSubmitAppeal: (String) -> Unit,
    onLogout: () -> Unit,
    onClearStatusMessage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var appealText by remember { mutableStateOf("") }
    var selectedOption by remember { mutableStateOf(2) } // 1: Help/Admin Message, 2: Watch Ads

    // Calculate 3-day countdown
    val threeDaysMillis = 3L * 24L * 60L * 60L * 1000L
    val banTime = if (user.banTimestamp > 0) user.banTimestamp else System.currentTimeMillis()
    val expireTime = banTime + threeDaysMillis

    var millisLeft by remember { mutableLongStateOf((expireTime - System.currentTimeMillis()).coerceAtLeast(0L)) }

    LaunchedEffect(banTime) {
        while (true) {
            val rem = (expireTime - System.currentTimeMillis()).coerceAtLeast(0L)
            millisLeft = rem
            delay(1000L)
        }
    }

    val hoursLeft = millisLeft / (1000 * 60 * 60)
    val minutesLeft = (millisLeft / (1000 * 60)) % 60
    val secondsLeft = (millisLeft / 1000) % 60

    Scaffold(
        containerColor = Color(0xFF0F0F0F),
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Large Red Ban Badge
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .background(Color(0xFF330000), CircleShape)
                    .border(2.dp, RedPrimary, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Block,
                    contentDescription = "Banned",
                    tint = RedPrimary,
                    modifier = Modifier.size(46.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "ගිණුම තහනම් කර ඇත",
                color = RedPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Account Suspended / Banned",
                color = Color.LightGray,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Reason Display in Bold Red
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF240E0E)),
                border = androidx.compose.foundation.BorderStroke(1.dp, RedPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = RedPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "තහනම් කිරීමට හේතුව (Ban Reason):",
                            color = RedPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (user.banReason.isNotBlank()) user.banReason else "Repeated Unsubscribing/Unliking (3 Violations)",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "කාසි (Coins) ලබා ගැනීමෙන් පසු නාලිකා Sub හෝ Like 3 වරක් ඉවත් කිරීම හේතුවෙන් ප්‍රතිපත්ති උල්ලංඝනය වී ඇත.",
                        color = Color(0xFFFFB4B4),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Recovery Section Header
            Text(
                text = "ගිණුම යථා තත්ත්වයට පත් කරගැනීම (Unban Options):",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Tab Selector for Option 1 & Option 2
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { selectedOption = 2 },
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (selectedOption == 2) Color(0xFF221100) else Color(0xFF1A1A1A),
                        contentColor = if (selectedOption == 2) CoinGold else Color.Gray
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (selectedOption == 2) CoinGold else Color(0xFF333333)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("විකල්ප 2", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Ads 20ක් නැරඹීම", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }

                OutlinedButton(
                    onClick = { selectedOption = 1 },
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (selectedOption == 1) Color(0xFF001A26) else Color(0xFF1A1A1A),
                        contentColor = if (selectedOption == 1) Color(0xFF4FC3F7) else Color.Gray
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (selectedOption == 1) Color(0xFF4FC3F7) else Color(0xFF333333)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("විකල්ප 1", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Help / Admin", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Feedback Message Banner
            if (statusMessage != null) {
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2E1E)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = statusMessage, color = Color.White, fontSize = 12.sp)
                    }
                }
            }

            // OPTION 2: Watch 20 ads over 3 days (max 7/day)
            if (selectedOption == 2) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF181818)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CoinGold.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LiveTv, contentDescription = null, tint = CoinGold, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "දවස් 3ක් ඇතුළත Ads 20ක් නරඹා Unban වන්න",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "දිනකට උපරිම ads 7ක් බැගින් දවස් 3ක් ඇතුළත දැන්වීම් 20ක් නැරඹූ වහාම ඔබගේ ගිණුම ස්වයංක්‍රීයව Unban වේ.",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // 3 Days Countdown
                        Row(
                            modifier = Modifier
                                .background(Color(0xFF262626), RoundedCornerShape(8.dp))
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Timer, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ඉතිරි කාලය: %02d පැය %02d මි %02d ත".format(hoursLeft, minutesLeft, secondsLeft),
                                color = Color(0xFFFFB300),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Progress indicators
                        val totalProgress = (user.unbanAdsWatched.toFloat() / 20f).coerceIn(0f, 1f)
                        val dailyLeft = (7 - user.unbanDailyAdsWatched).coerceAtLeast(0)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("මුළු ප්‍රගතිය: ${user.unbanAdsWatched} / 20", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("අද දිනට: ${user.unbanDailyAdsWatched} / 7", color = CoinGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        LinearProgressIndicator(
                            progress = { totalProgress },
                            color = CoinGold,
                            trackColor = Color(0xFF333333),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        val isDailyLimitReached = user.unbanDailyAdsWatched >= 7 && user.unbanAdsWatched < 20
                        val isTimeExpired = millisLeft <= 0L && user.unbanAdsWatched < 20

                        Button(
                            onClick = onWatchAd,
                            enabled = !isDailyLimitReached && !isTimeExpired,
                            colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("watch_unban_ad_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LiveTv, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isDailyLimitReached) "අද දිනට නියමිත දැන්වීම් 7 සම්පූර්ණයි" else if (isTimeExpired) "දින 3 ක කාලය අවසන් වී ඇත" else "දැන්වීමක් නරඹන්න (+1 Ad)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }

                        if (isDailyLimitReached) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "අද දින සීමාව (7/7) සම්පූර්ණයි. හෙට නැවත Ads නරඹන්න.",
                                color = Color(0xFFFFB300),
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // OPTION 1: Help / Contact Admin
            if (selectedOption == 1) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF181818)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF0288D1)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.HelpOutline, contentDescription = null, tint = Color(0xFF4FC3F7), modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Help / Admin වෙත පණිවිඩයක් යවන්න",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "නොදැනුවත්ව සිදුවූයේ නම් කරුණාකර Admin වෙත හේතුව පැහැදිලි කර Unban ඉල්ලීමක් යොමු කරන්න.",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        if (user.appealStatus == "PENDING") {
                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF002233)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("ඉල්ලීමේ තත්ත්වය: සමාලෝචනය වෙමින් පවතී (Pending Review)", color = Color(0xFF81D4FA), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("ඔබ යැවූ පණිවිඩය: \"${user.appealMessage}\"", color = Color.White, fontSize = 12.sp)
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = appealText,
                                onValueChange = { appealText = it },
                                label = { Text("ඔබගේ පණිවිඩය / හේතුව (Appeal Message)") },
                                placeholder = { Text("කරුණාකර මාගේ ගිණුම නැවත සක්‍රීය කර දෙන ලෙස කාරුණිකව ඉල්ලා සිටිමි...") },
                                minLines = 3,
                                maxLines = 5,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color(0xFF0288D1),
                                    unfocusedBorderColor = Color(0xFF444444),
                                    focusedLabelColor = Color(0xFF4FC3F7),
                                    unfocusedLabelColor = Color.Gray
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().testTag("appeal_message_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    if (appealText.isNotBlank()) {
                                        onSubmitAppeal(appealText)
                                    }
                                },
                                enabled = appealText.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("submit_appeal_button")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Admin වෙත ඉල්ලීම යොමු කරන්න", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Logout / Return to Main Screen (Login Screen) button as requested
            OutlinedButton(
                onClick = onLogout,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = RedPrimary,
                    containerColor = Color(0xFF1E1414)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, RedPrimary.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("logout_to_login_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Logout, contentDescription = null, tint = RedPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "මුල් පිටුවට යන්න (Return to Login Screen)",
                        color = RedPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Unban Ad Playback Overlay Modal
    if (isWatchingAd) {
        Dialog(
            onDismissRequest = { /* Must watch full ad */ },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
                border = androidx.compose.foundation.BorderStroke(1.dp, CoinGold),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(54.dp).background(Color(0xFF241804), CircleShape)
                    ) {
                        Icon(Icons.Default.LiveTv, contentDescription = null, tint = CoinGold, modifier = Modifier.size(30.dp))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Sponsored Unban Partner Ad",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "ගිණුම සක්‍රීය කර ගැනීමට දැන්වීම අවසන් වනතුරු රැඳී සිටින්න...",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    CircularProgressIndicator(color = CoinGold, modifier = Modifier.size(40.dp))
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "තත්පර $adCountdown කින් අවසන් වේ",
                        color = CoinGold,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
