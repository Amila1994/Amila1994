package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.FraudViolationItem
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen

@Composable
fun MultiItemViolationBlockingScreen(
    userEmail: String,
    strikeCount: Int,
    violations: List<FraudViolationItem>,
    isVerifying: Boolean,
    verificationStatusMessage: String?,
    onOpenYouTubeItem: (FraudViolationItem) -> Unit,
    onToggleSubResolved: (violationId: String) -> Unit,
    onToggleLikeResolved: (violationId: String) -> Unit,
    onVerifyAndResolveAll: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val totalCount = violations.size
    val resolvedCount = violations.count { it.isFullyResolved }
    val allFixedLocally = resolvedCount == totalCount && totalCount > 0

    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Scaffold(
        containerColor = Color(0xFF0D0505),
        bottomBar = {
            // Sticky Bottom Resolution Action Bar
            Surface(
                color = Color(0xFF160808),
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                border = BorderStroke(1.dp, Color(0xFF3B1212)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    // Progress Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Resolution Progress:",
                            fontSize = 12.sp,
                            color = Color.LightGray,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "$resolvedCount / $totalCount Items Fixed",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (allFixedLocally) SuccessGreen else Color(0xFFFF8A80)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { if (totalCount > 0) resolvedCount.toFloat() / totalCount.toFloat() else 0f },
                        color = if (allFixedLocally) SuccessGreen else RedPrimary,
                        trackColor = Color(0xFF331111),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (verificationStatusMessage != null) {
                        Text(
                            text = verificationStatusMessage,
                            color = if (allFixedLocally) SuccessGreen else Color(0xFFFF5252),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // Main Verification Button
                    Button(
                        onClick = onVerifyAndResolveAll,
                        enabled = !isVerifying,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (allFixedLocally) SuccessGreen else RedPrimary,
                            disabledContainerColor = Color(0xFF4A1E1E)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("verify_and_resolve_all_button")
                    ) {
                        if (isVerifying) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.5.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Verifying All Subscriptions on YouTube...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(
                                imageVector = if (allFixedLocally) Icons.Default.CheckCircle else Icons.Default.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (allFixedLocally) "Verify & Restore Full App Access ✓" else "Verify All & Check Fixes",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Sign Out / Switch User Option
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Logged in as $userEmail • ",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Text(
                            text = "Sign Out",
                            fontSize = 11.sp,
                            color = Color(0xFF81D4FA),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { onLogout() }
                                .padding(4.dp)
                        )
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))

                // Compulsory Blocking Header with Warning Shield
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF220A0A)
                    ),
                    border = BorderStroke(1.5.dp, RedPrimary.copy(alpha = pulseAlpha)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(56.dp)
                                .background(Color(0xFF3D0C0C), CircleShape)
                                .border(2.dp, RedPrimary, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Security Alert",
                                tint = RedPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "🚨 ANTI-CHEAT: APP ACCESS BLOCKED",
                            color = RedPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "Sub / Like Fraud Detected on Rewarded Channels",
                            color = Color(0xFFFFB4B4),
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Strike Count Tag
                        Box(
                            modifier = Modifier
                                .background(RedPrimary, RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "STRIKE $strikeCount OF 3 " + if (strikeCount >= 2) "(FINAL WARNING)" else "(VIOLATION CYCLE)",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Compulsory Explanation
                        Text(
                            text = "අපගේ පද්ධතිය මගින් ඔබ කාසි ලබා ගැනීමෙන් පසු ඉවත් වූ (Unsubscribed/Unliked) නාලිකා හඳුනාගෙන ඇත. යෙදුම නැවත භාවිතයට ගැනීමට නම් පහත සඳහන් සියලුම නාලිකා සඳහා නැවත Sub & Like ලබා දී තහවුරු කළ යුතුය. මෙම ක්‍රියාකාරකම් සඳහා අමතර කාසි නොලැබේ.",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Violated Channels & Videos ($totalCount):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    Text(
                        text = "All items compulsory",
                        fontSize = 11.sp,
                        color = RedPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // List of All Violated Channels/Videos
            items(violations, key = { it.id.ifBlank { "${it.channelName}_${it.campaignId}" } }) { item ->
                ViolationItemCard(
                    item = item,
                    onOpenYouTube = { onOpenYouTubeItem(item) },
                    onToggleSub = { onToggleSubResolved(item.id) },
                    onToggleLike = { onToggleLikeResolved(item.id) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun ViolationItemCard(
    item: FraudViolationItem,
    onOpenYouTube: () -> Unit,
    onToggleSub: () -> Unit,
    onToggleLike: () -> Unit
) {
    val isResolved = item.isFullyResolved
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isResolved) Color(0xFF0F1F12) else Color(0xFF1E0A0A)
        ),
        border = BorderStroke(
            1.5.dp,
            if (isResolved) SuccessGreen else Color(0xFFFF3333)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Thumbnail + Title + Channel Name + Direct Link
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Video / Channel Thumbnail
                Box(
                    modifier = Modifier
                        .size(72.dp, 50.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF330000)),
                    contentAlignment = Alignment.Center
                ) {
                    if (item.thumbnailUrl.isNotBlank()) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(item.thumbnailUrl)
                                .crossfade(true)
                                .build(),
                            contentDescription = item.videoTitle,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Subscriptions,
                            contentDescription = null,
                            tint = Color(0xFFFF5252),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.channelName.ifBlank { "YouTube Channel" },
                        color = if (isResolved) SuccessGreen else Color(0xFFFF6B6B),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (item.videoTitle.isNotBlank()) {
                        Text(
                            text = item.videoTitle,
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "Unsub/Unlike detected after receiving reward",
                        color = if (isResolved) Color(0xFFA5D6A7) else Color(0xFFFFA4A4),
                        fontSize = 10.sp
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Direct YouTube Open Button
                OutlinedButton(
                    onClick = onOpenYouTube,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color(0xFFCC0000),
                        contentColor = Color.White
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Open in YouTube",
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("YouTube", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Resolution Action Buttons: Re-Sub & Re-Like
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Re-Subscribe Action
                ActionResolutionButton(
                    label = "1. Re-Subscribe",
                    isCompleted = item.isSubResolved,
                    icon = Icons.Default.Subscriptions,
                    onClick = {
                        onOpenYouTube()
                        onToggleSub()
                    },
                    modifier = Modifier.weight(1f)
                )

                // Re-Like Action
                ActionResolutionButton(
                    label = "2. Re-Like Video",
                    isCompleted = item.isLikeResolved,
                    icon = Icons.Default.ThumbUp,
                    onClick = {
                        onOpenYouTube()
                        onToggleLike()
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Card Footer Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "• No coins awarded for recovery",
                    fontSize = 10.sp,
                    color = Color.Gray,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )

                Box(
                    modifier = Modifier
                        .background(
                            if (isResolved) SuccessGreen.copy(alpha = 0.2f) else RedPrimary.copy(alpha = 0.2f),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isResolved) "RESOLVED ✓" else "PENDING FIX",
                        color = if (isResolved) SuccessGreen else Color(0xFFFF5252),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionResolutionButton(
    label: String,
    isCompleted: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isCompleted) Color(0xFF1B5E20) else Color(0xFF330A0A),
            contentColor = if (isCompleted) Color.White else Color(0xFFFF8A80)
        ),
        border = BorderStroke(
            1.dp,
            if (isCompleted) SuccessGreen else Color(0xFFFF5252)
        ),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp),
        modifier = modifier.height(36.dp)
    ) {
        Icon(
            imageVector = if (isCompleted) Icons.Default.Check else icon,
            contentDescription = null,
            tint = if (isCompleted) Color.White else Color(0xFFFF5252),
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = if (isCompleted) "$label ✓" else label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}
