package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.UserEntity
import com.example.ui.theme.CoinGold
import com.example.ui.theme.CoinGoldDark
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen

@Composable
fun AdminManageUsersDialog(
    users: List<UserEntity>,
    onDismiss: () -> Unit,
    onToggleBan: (email: String, currentBanned: Boolean) -> Unit,
    onModifyCoins: (email: String, delta: Int) -> Unit,
    onDeleteUser: (email: String) -> Unit,
    onSetCoins: (email: String, newBalance: Int) -> Unit = { _, _ -> }
) {
    var searchQuery by remember { mutableStateOf("") }
    var userToDelete by remember { mutableStateOf<UserEntity?>(null) }
    var editingCoinsUser by remember { mutableStateOf<UserEntity?>(null) }

    val filteredUsers = remember(users, searchQuery) {
        if (searchQuery.isBlank()) users
        else users.filter { it.email.contains(searchQuery, ignoreCase = true) }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .wrapContentHeight()
                .heightIn(min = 160.dp, max = 640.dp)
                .testTag("admin_manage_users_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = RedPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Admin: Manage & Control Users",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by user email...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RedPrimary,
                        cursorColor = RedPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Total Registered Users: ${filteredUsers.size} (Admin: amilalasantha940703@gmail.com)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                // LazyColumn with weight(1f, fill = false) to prevent unnecessary vertical empty space
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredUsers, key = { it.email }) { user ->
                        UserAdminItemCard(
                            user = user,
                            onToggleBan = { onToggleBan(user.email, user.isBanned) },
                            onModifyCoins = { delta -> onModifyCoins(user.email, delta) },
                            onOpenEditCoins = { editingCoinsUser = user },
                            onDeleteClick = { userToDelete = user }
                        )
                    }
                }
            }
        }
    }

    // Confirm Delete User Dialog
    userToDelete?.let { targetUser ->
        AlertDialog(
            onDismissRequest = { userToDelete = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Delete, contentDescription = null, tint = RedPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Delete User Account?", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    "Are you sure you want to permanently remove user '${targetUser.email}'? " +
                    "All associated campaigns and history for this user will be deleted immediately.",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteUser(targetUser.email)
                        userToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedPrimary)
                ) {
                    Text("Delete Account", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { userToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Comprehensive Edit Coins Dialog (Admin can set ANY desired amount, or add/deduct)
    editingCoinsUser?.let { targetUser ->
        EditUserCoinsDialog(
            user = targetUser,
            onDismiss = { editingCoinsUser = null },
            onSetCoins = { newCoins ->
                onSetCoins(targetUser.email, newCoins)
                editingCoinsUser = null
            },
            onModifyCoins = { delta ->
                onModifyCoins(targetUser.email, delta)
                editingCoinsUser = null
            }
        )
    }
}

@Composable
private fun UserAdminItemCard(
    user: UserEntity,
    onToggleBan: () -> Unit,
    onModifyCoins: (delta: Int) -> Unit,
    onOpenEditCoins: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val isPrimaryAdmin = user.email.equals("amilalasantha940703@gmail.com", ignoreCase = true)

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                user.isBanned -> Color(0x33D32F2F)
                isPrimaryAdmin -> RedPrimary.copy(alpha = 0.08f)
                else -> MaterialTheme.colorScheme.surfaceVariant
            }
        ),
        border = if (isPrimaryAdmin) {
            BorderStroke(1.5.dp, RedPrimary)
        } else {
            BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        },
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .padding(12.dp)
        ) {
            // User Header Row (compact, no extra vertical gaps)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (isPrimaryAdmin) RedPrimary else if (user.isAdmin) Color(0xFF2E7D32) else Color(0xFF666666),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (user.isAdmin || isPrimaryAdmin) Icons.Default.Shield else Icons.Default.Person,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = user.email,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            if (isPrimaryAdmin) {
                                Box(
                                    modifier = Modifier
                                        .background(RedPrimary, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text("SUPER ADMIN", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            } else if (user.isAdmin) {
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFF2E7D32), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text("ADMIN", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text(
                            text = "Watched: ${user.videosWatchedCount} • Subs: ${user.channelsSubscribedCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Balance Display
                Box(
                    modifier = Modifier
                        .background(CoinGoldDark.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = null,
                            tint = CoinGoldDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "${user.coins}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = CoinGoldDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            Spacer(modifier = Modifier.height(10.dp))

            // Coins Control Section: Direct Edit button to set ANY desired coins, plus quick presets
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Coins Balance:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Primary Action: EDIT COINS (Allows setting any custom amount directly)
                    Button(
                        onClick = onOpenEditCoins,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CoinGoldDark,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.height(32.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit coins",
                            modifier = Modifier.size(13.dp),
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit Coins", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    }

                    // Quick +500
                    OutlinedButton(
                        onClick = { onModifyCoins(500) },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(32.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("+500", fontSize = 11.sp, color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    }

                    // Quick +1000
                    OutlinedButton(
                        onClick = { onModifyCoins(1000) },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(32.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("+1K", fontSize = 11.sp, color = CoinGoldDark, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Moderation actions for non-primary admin users (Ban / Delete)
            if (!isPrimaryAdmin) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDeleteClick,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier.height(32.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delete", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = onToggleBan,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (user.isBanned) SuccessGreen else RedPrimary
                        ),
                        modifier = Modifier.height(32.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(
                            imageVector = if (user.isBanned) Icons.Default.CheckCircle else Icons.Default.Block,
                            contentDescription = null,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (user.isBanned) "Unban" else "Ban", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private enum class CoinEditMode {
    SET_EXACT, // Set exact amount (කැමති ගානක් කෙලින්ම Set කරන්න)
    ADD,       // Add coins (+ එකතු කරන්න)
    DEDUCT     // Deduct coins (- අඩු කරන්න)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EditUserCoinsDialog(
    user: UserEntity,
    onDismiss: () -> Unit,
    onSetCoins: (newCoins: Int) -> Unit,
    onModifyCoins: (delta: Int) -> Unit
) {
    var selectedMode by remember { mutableStateOf(CoinEditMode.SET_EXACT) }
    var inputAmountText by remember { mutableStateOf(user.coins.toString()) }

    val inputAmount = inputAmountText.toIntOrNull() ?: 0

    val calculatedNewBalance = when (selectedMode) {
        CoinEditMode.SET_EXACT -> inputAmount.coerceAtLeast(0)
        CoinEditMode.ADD -> (user.coins + inputAmount).coerceAtLeast(0)
        CoinEditMode.DEDUCT -> (user.coins - inputAmount).coerceAtLeast(0)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.MonetizationOn,
                    contentDescription = null,
                    tint = CoinGoldDark,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("Edit User Coins", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = user.email,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
            ) {
                // Current Balance Card
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = CoinGoldDark.copy(alpha = 0.1f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Current Balance:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = CoinGoldDark, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("${user.coins} Coins", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = CoinGoldDark)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Mode Selector Chips
                Text("Select Action:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedMode == CoinEditMode.SET_EXACT,
                        onClick = {
                            selectedMode = CoinEditMode.SET_EXACT
                            inputAmountText = user.coins.toString()
                        },
                        label = { Text("Set Exact", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(12.dp))
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CoinGoldDark,
                            selectedLabelColor = Color.Black,
                            selectedLeadingIconColor = Color.Black
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    FilterChip(
                        selected = selectedMode == CoinEditMode.ADD,
                        onClick = {
                            selectedMode = CoinEditMode.ADD
                            inputAmountText = "1000"
                        },
                        label = { Text("Add (+)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SuccessGreen,
                            selectedLabelColor = Color.White,
                            selectedLeadingIconColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    FilterChip(
                        selected = selectedMode == CoinEditMode.DEDUCT,
                        onClick = {
                            selectedMode = CoinEditMode.DEDUCT
                            inputAmountText = "500"
                        },
                        label = { Text("Deduct (-)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        leadingIcon = {
                            Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(12.dp))
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RedPrimary,
                            selectedLabelColor = Color.White,
                            selectedLeadingIconColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Amount Text Field (numeric)
                OutlinedTextField(
                    value = inputAmountText,
                    onValueChange = { inputAmountText = it.filter { ch -> ch.isDigit() } },
                    label = {
                        Text(
                            when (selectedMode) {
                                CoinEditMode.SET_EXACT -> "Enter exact new coin balance"
                                CoinEditMode.ADD -> "Enter coins to add"
                                CoinEditMode.DEDUCT -> "Enter coins to deduct"
                            },
                            fontSize = 12.sp
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = when (selectedMode) {
                            CoinEditMode.SET_EXACT -> CoinGoldDark
                            CoinEditMode.ADD -> SuccessGreen
                            CoinEditMode.DEDUCT -> RedPrimary
                        }
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Preset Chips for fast input
                Text("Quick presets:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val presets = when (selectedMode) {
                        CoinEditMode.SET_EXACT -> listOf("0", "1000", "5000", "10000", "50000", "100000")
                        CoinEditMode.ADD -> listOf("100", "500", "1000", "5000", "10000")
                        CoinEditMode.DEDUCT -> listOf("100", "500", "1000", "5000")
                    }
                    presets.forEach { preset ->
                        SuggestionChip(
                            onClick = { inputAmountText = preset },
                            label = { Text(preset, fontSize = 11.sp) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Result Preview
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("New Resulting Balance:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Text(
                            "$calculatedNewBalance Coins",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = CoinGoldDark
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when (selectedMode) {
                        CoinEditMode.SET_EXACT -> {
                            onSetCoins(calculatedNewBalance)
                        }
                        CoinEditMode.ADD -> {
                            if (inputAmount > 0) onModifyCoins(inputAmount)
                        }
                        CoinEditMode.DEDUCT -> {
                            if (inputAmount > 0) onModifyCoins(-inputAmount)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (selectedMode) {
                        CoinEditMode.SET_EXACT -> CoinGoldDark
                        CoinEditMode.ADD -> SuccessGreen
                        CoinEditMode.DEDUCT -> RedPrimary
                    },
                    contentColor = if (selectedMode == CoinEditMode.SET_EXACT) Color.Black else Color.White
                )
            ) {
                Text(
                    text = when (selectedMode) {
                        CoinEditMode.SET_EXACT -> "Set Balance ($calculatedNewBalance)"
                        CoinEditMode.ADD -> "Add +$inputAmount Coins"
                        CoinEditMode.DEDUCT -> "Deduct -$inputAmount Coins"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
