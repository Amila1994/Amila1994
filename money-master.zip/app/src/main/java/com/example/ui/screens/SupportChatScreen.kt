package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.SupportChatMessage
import com.example.data.model.SupportChatThread
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportChatScreen(
    currentUserEmail: String,
    isAdmin: Boolean,
    activeChatEmail: String,
    messages: List<SupportChatMessage>,
    threads: List<SupportChatThread>,
    isSending: Boolean,
    isUploading: Boolean,
    uploadProgressText: String?,
    onSendMessage: (text: String, imageUri: Uri?, context: android.content.Context) -> Unit,
    onSelectThread: (userEmail: String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var inputText by rememberSaveable { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var fullScreenImageUrl by remember { mutableStateOf<String?>(null) }
    var adminTab by rememberSaveable { mutableIntStateOf(if (isAdmin && activeChatEmail.isBlank()) 0 else 1) }

    // Google Play Policy compliant photo picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
        }
    }

    val listState = rememberLazyListState()

    // Auto-scroll to bottom when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    BackHandler {
        if (isAdmin && adminTab == 1 && threads.isNotEmpty()) {
            adminTab = 0
        } else {
            onClose()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (isAdmin && adminTab == 1 && threads.isNotEmpty()) {
                                adminTab = 0
                            } else {
                                onClose()
                            }
                        },
                        modifier = Modifier.testTag("support_chat_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isAdmin) Icons.Default.Shield else Icons.Default.SupportAgent,
                                contentDescription = null,
                                tint = RedPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isAdmin && adminTab == 0) {
                                    "Help Desk: User Inquiries"
                                } else if (isAdmin) {
                                    "Chat with ${activeChatEmail.substringBefore("@")}"
                                } else {
                                    "Help & Admin Support"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = if (isAdmin && adminTab == 0) {
                                "${threads.size} active user inquiries"
                            } else if (isAdmin) {
                                activeChatEmail
                            } else {
                                "🟢 Official Support Online • Replies in minutes"
                            },
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = if (!isAdmin) SuccessGreen else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.testTag("support_chat_top_bar")
            )
        },
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .testTag("support_chat_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Admin Tabs (if Admin is viewing)
            if (isAdmin) {
                TabRow(
                    selectedTabIndex = adminTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = RedPrimary
                ) {
                    Tab(
                        selected = adminTab == 0,
                        onClick = { adminTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Inquiries (${threads.size})", fontWeight = FontWeight.Bold)
                                val unreadCount = threads.count { it.unreadByAdmin }
                                if (unreadCount > 0) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(RedPrimary, CircleShape)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "$unreadCount",
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    )
                    Tab(
                        selected = adminTab == 1,
                        onClick = { adminTab = 1 },
                        text = {
                            Text(
                                text = if (activeChatEmail.isNotBlank()) "Chat (${activeChatEmail.substringBefore("@")})" else "Active Chat",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                }
            }

            // Body: Inquiries List (Admin tab 0) vs Chat Conversation
            if (isAdmin && adminTab == 0) {
                AdminThreadsList(
                    threads = threads,
                    activeEmail = activeChatEmail,
                    onSelectThread = { email ->
                        onSelectThread(email)
                        adminTab = 1
                    }
                )
            } else {
                // Chat Conversation Area
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (messages.isEmpty()) {
                        EmptyChatState(
                            isAdmin = isAdmin,
                            onQuickPrompt = { prompt ->
                                inputText = prompt
                            }
                        )
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(messages, key = { it.id }) { msg ->
                                val isMyMessage = if (isAdmin) {
                                    msg.isAdmin || msg.senderEmail.equals(currentUserEmail, ignoreCase = true)
                                } else {
                                    !msg.isAdmin && msg.senderEmail.equals(currentUserEmail, ignoreCase = true)
                                }

                                ChatBubbleItem(
                                    message = msg,
                                    isMyMessage = isMyMessage,
                                    onImageClick = { url -> fullScreenImageUrl = url }
                                )
                            }
                        }
                    }
                }

                // Quick Support Chips (shown to regular users to quickly tap common issues)
                if (!isAdmin) {
                    QuickIssueChips(
                        onSelectIssue = { issueText ->
                            inputText = issueText
                        }
                    )
                }

                // Image Preview Area (before sending)
                selectedImageUri?.let { uri ->
                    SelectedImagePreviewBar(
                        uri = uri,
                        isUploading = isUploading,
                        uploadProgressText = uploadProgressText,
                        onRemove = { selectedImageUri = null }
                    )
                }

                // Bottom Input Bar
                ChatBottomInputBar(
                    text = inputText,
                    onTextChanged = { inputText = it },
                    isSending = isSending || isUploading,
                    hasSelectedImage = selectedImageUri != null,
                    onAttachClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onSend = {
                        if (inputText.isNotBlank() || selectedImageUri != null) {
                            val msg = inputText
                            val img = selectedImageUri
                            inputText = ""
                            selectedImageUri = null
                            onSendMessage(msg, img, context)
                        }
                    }
                )
            }
        }
    }

    // Full screen image viewer dialog
    fullScreenImageUrl?.let { imgUrl ->
        FullScreenImageDialog(
            imageUrl = imgUrl,
            onDismiss = { fullScreenImageUrl = null }
        )
    }
}

@Composable
private fun QuickIssueChips(
    onSelectIssue: (String) -> Unit
) {
    val issues = listOf(
        "🚫 Appeal Account Strike / Ban",
        "❓ Missing Coins or Verification Error",
        "📱 Mobile Reload Inquiry",
        "⚠️ Video Not Playing in SubExchange"
    )

    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(issues) { issue ->
            FilterChip(
                selected = false,
                onClick = { onSelectIssue(issue) },
                label = { Text(issue, fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        }
    }
}

@Composable
private fun SelectedImagePreviewBar(
    uri: Uri,
    isUploading: Boolean,
    uploadProgressText: String?,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.1f))
            ) {
                AsyncImage(
                    model = uri,
                    contentDescription = "Selected screenshot",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Screenshot attached",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = uploadProgressText ?: "Ready to send with your message",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            if (isUploading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = RedPrimary)
            } else {
                IconButton(onClick = onRemove, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove photo", tint = RedPrimary)
                }
            }
        }
    }
}

@Composable
private fun ChatBubbleItem(
    message: SupportChatMessage,
    isMyMessage: Boolean,
    onImageClick: (String) -> Unit
) {
    val alignment = if (isMyMessage) Alignment.End else Alignment.Start
    val bubbleColor = if (isMyMessage) {
        RedPrimary
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    val textColor = if (isMyMessage) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
    val dateFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val timeString = remember(message.timestamp) { dateFormat.format(Date(message.timestamp)) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        horizontalAlignment = alignment
    ) {
        // Sender header for received messages
        if (!isMyMessage) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 2.dp, start = 4.dp)
            ) {
                if (message.isAdmin) {
                    Box(
                        modifier = Modifier
                            .background(RedPrimary.copy(alpha = 0.15f), CircleShape)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "🛡️ ADMIN SUPPORT",
                            color = RedPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 10.sp
                        )
                    }
                } else {
                    Text(
                        text = message.senderName.ifBlank { message.senderEmail.substringBefore("@") },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isMyMessage) 16.dp else 4.dp,
                bottomEnd = if (isMyMessage) 4.dp else 16.dp
            ),
            color = bubbleColor,
            modifier = Modifier.widthIn(max = 290.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                // Attached image if present
                message.imageUrl?.let { imgUrl ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black.copy(alpha = 0.1f))
                            .clickable { onImageClick(imgUrl) }
                    ) {
                        AsyncImage(
                            model = imgUrl,
                            contentDescription = "Chat image attachment",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    if (message.message.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }

                // Text body
                if (message.message.isNotBlank()) {
                    Text(
                        text = message.message,
                        color = textColor,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }

                // Timestamp & read status
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = timeString,
                        fontSize = 10.sp,
                        color = textColor.copy(alpha = 0.7f)
                    )
                    if (isMyMessage) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Sent",
                            tint = textColor.copy(alpha = 0.7f),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBottomInputBar(
    text: String,
    onTextChanged: (String) -> Unit,
    isSending: Boolean,
    hasSelectedImage: Boolean,
    onAttachClick: () -> Unit,
    onSend: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Attach Screenshot button (Play policy compliant)
            IconButton(
                onClick = onAttachClick,
                enabled = !isSending,
                modifier = Modifier
                    .size(42.dp)
                    .testTag("chat_attach_image_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Image,
                    contentDescription = "Attach screenshot or photo",
                    tint = if (hasSelectedImage) RedPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            // Input field
            OutlinedTextField(
                value = text,
                onValueChange = onTextChanged,
                placeholder = {
                    Text(
                        "Message Admin with details or screenshot...",
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 4.dp)
                    .testTag("chat_input_textfield"),
                maxLines = 4,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = RedPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
            )

            // Send button
            IconButton(
                onClick = onSend,
                enabled = !isSending && (text.isNotBlank() || hasSelectedImage),
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        if (!isSending && (text.isNotBlank() || hasSelectedImage)) RedPrimary else MaterialTheme.colorScheme.surfaceVariant,
                        CircleShape
                    )
                    .testTag("chat_send_button")
            ) {
                if (isSending) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                } else {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send Message",
                        tint = if (text.isNotBlank() || hasSelectedImage) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyChatState(
    isAdmin: Boolean,
    onQuickPrompt: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(RedPrimary.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isAdmin) Icons.Default.Chat else Icons.Default.SupportAgent,
                    contentDescription = null,
                    tint = RedPrimary,
                    modifier = Modifier.size(44.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = if (isAdmin) "No messages in this chat yet" else "How can Admin help you today?",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isAdmin) {
                    "Type a reply or attach instructions to help this user."
                } else {
                    "Send a message or attach a screenshot of any issue (account ban, reload pending, coins). Our admin responds directly here."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
private fun AdminThreadsList(
    threads: List<SupportChatThread>,
    activeEmail: String,
    onSelectThread: (String) -> Unit
) {
    if (threads.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Chat,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "No user inquiries yet",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Text(
                    text = "When users ask for help or send screenshots, they will appear here.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
    } else {
        val dateFormat = remember { SimpleDateFormat("MMM d, hh:mm a", Locale.getDefault()) }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(threads, key = { it.userEmail }) { thread ->
                val isSelected = thread.userEmail.equals(activeEmail, ignoreCase = true)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectThread(thread.userEmail) }
                        .testTag("admin_thread_${thread.userEmail}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) RedPrimary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                    ),
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, RedPrimary) else null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    if (thread.unreadByAdmin) RedPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = if (thread.unreadByAdmin) RedPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = thread.userName.ifBlank { thread.userEmail.substringBefore("@") },
                                    fontWeight = if (thread.unreadByAdmin) FontWeight.ExtraBold else FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 1
                                )
                                Text(
                                    text = dateFormat.format(Date(thread.lastTimestamp)),
                                    fontSize = 10.sp,
                                    color = if (thread.unreadByAdmin) RedPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                    fontWeight = if (thread.unreadByAdmin) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                            Text(
                                text = thread.userEmail,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = thread.lastMessage.ifBlank { "Conversation started" },
                                fontSize = 12.sp,
                                color = if (thread.unreadByAdmin) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                fontWeight = if (thread.unreadByAdmin) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (thread.unreadByAdmin) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(RedPrimary, CircleShape)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FullScreenImageDialog(
    imageUrl: String,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalAlignment = Alignment.End
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(400.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = imageUrl,
                        contentDescription = "Full screenshot",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            }
        }
    }
}
