package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AdminTasksConfig
import com.example.data.model.UserTasksState
import com.example.ui.theme.CoinGold
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen
import kotlinx.coroutines.delay

@Composable
fun PromoTasksDialog(
    tasksConfig: AdminTasksConfig,
    userTasksState: UserTasksState,
    onClaimTask: (taskId: String) -> Unit,
    onDismiss: () -> Unit
) {
    val promo = tasksConfig.promoEvent
    val promoProgress = userTasksState.promoProgress

    var remainingMillis by remember(promo.endTimestamp) {
        mutableLongStateOf((promo.endTimestamp - System.currentTimeMillis()).coerceAtLeast(0L))
    }

    LaunchedEffect(promo.endTimestamp) {
        while (remainingMillis > 0L) {
            delay(1000L)
            remainingMillis = (promo.endTimestamp - System.currentTimeMillis()).coerceAtLeast(0L)
        }
    }

    val hours = remainingMillis / (1000 * 3600)
    val minutes = (remainingMillis % (1000 * 3600)) / (1000 * 60)
    val seconds = (remainingMillis % (1000 * 60)) / 1000
    val countdownString = String.format("%02dh : %02dm : %02ds", hours, minutes, seconds)

    val isPromoGoalsMet = promoProgress.campaignsCount >= promo.targetCampaigns &&
            promoProgress.subscribesCount >= promo.targetSubscribes &&
            promoProgress.likesCount >= promo.targetLikes

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("promo_tasks_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(RedPrimary.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = RedPrimary, modifier = Modifier.size(22.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Promotion & Daily Tasks", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("ඉලක්ක සම්පූර්ණ කර නොමිලේ කාසි ලබාගන්න", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // LIMITED-TIME PROMOTION EVENT SECTION
                if (promo.isEventActive) {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF261212)),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, RedPrimary)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Timer, contentDescription = null, tint = RedPrimary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(promo.title, fontWeight = FontWeight.Black, fontSize = 13.sp, color = Color.White)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(RedPrimary, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(countdownString, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = Color.White)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = promo.description,
                                fontSize = 11.sp,
                                color = Color(0xFFFFCDD2),
                                lineHeight = 15.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Target 1: Campaigns
                            PromoProgressRow(
                                label = "1. Campaigns නිර්මාණය (Create Campaigns)",
                                current = promoProgress.campaignsCount,
                                target = promo.targetCampaigns
                            )

                            // Target 2: Subscribes
                            PromoProgressRow(
                                label = "2. නාලිකා Subscribe කිරීම (Channels Subscribed)",
                                current = promoProgress.subscribesCount,
                                target = promo.targetSubscribes
                            )

                            // Target 3: Likes
                            PromoProgressRow(
                                label = "3. වීඩියෝ වලට Like කිරීම (Videos Liked)",
                                current = promoProgress.likesCount,
                                target = promo.targetLikes
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Reward & Claim Status
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF3B1A1A), RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = CoinGold, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text("Event Reward: +${promo.rewardCoins} Coins", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CoinGold)
                                        Text(
                                            if (promoProgress.isRewardClaimed) "✅ ස්වයංක්‍රීයව ගිණුමට එකතු විය (Claimed)"
                                            else if (isPromoGoalsMet) "🎉 ඉලක්ක සියල්ල සම්පූර්ණයි!"
                                            else "ඉලක්ක සම්පූර්ණ කළ සැනින් auto-add වේ",
                                            fontSize = 10.sp,
                                            color = Color.LightGray
                                        )
                                    }
                                }
                                if (promoProgress.isRewardClaimed) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(24.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                }

                // 5 APP-TAILORED ENGAGEMENT TASKS SECTION
                Text("🎯 Daily Engagement Tasks (දෛනික කාර්යයන්)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(8.dp))

                // Task 1: Watch Streak
                if (tasksConfig.taskWatchStreak.isEnabled) {
                    val t = tasksConfig.taskWatchStreak
                    TaskItemCard(
                        icon = Icons.Default.Visibility,
                        title = t.title,
                        description = t.description,
                        current = userTasksState.watchStreakCount,
                        target = t.targetCount,
                        rewardCoins = t.rewardCoins,
                        isClaimed = userTasksState.isWatchStreakClaimed,
                        onClaim = { onClaimTask(t.id) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Task 2: Daily Login
                if (tasksConfig.taskDailyLogin.isEnabled) {
                    val t = tasksConfig.taskDailyLogin
                    TaskItemCard(
                        icon = Icons.Default.Login,
                        title = t.title,
                        description = t.description,
                        current = if (userTasksState.isDailyLoginClaimed) 1 else 1,
                        target = t.targetCount,
                        rewardCoins = t.rewardCoins,
                        isClaimed = userTasksState.isDailyLoginClaimed,
                        onClaim = { onClaimTask(t.id) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Task 3: Invite Friend
                if (tasksConfig.taskInviteFriend.isEnabled) {
                    val t = tasksConfig.taskInviteFriend
                    TaskItemCard(
                        icon = Icons.Default.PersonAdd,
                        title = t.title,
                        description = t.description,
                        current = userTasksState.referralsCount,
                        target = t.targetCount,
                        rewardCoins = t.rewardCoins,
                        isClaimed = userTasksState.isInviteFriendClaimed,
                        onClaim = { onClaimTask(t.id) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Task 4: High Watch Time
                if (tasksConfig.taskHighWatchTime.isEnabled) {
                    val t = tasksConfig.taskHighWatchTime
                    TaskItemCard(
                        icon = Icons.Default.OndemandVideo,
                        title = t.title,
                        description = t.description,
                        current = userTasksState.highWatchCount,
                        target = t.targetCount,
                        rewardCoins = t.rewardCoins,
                        isClaimed = userTasksState.isHighWatchClaimed,
                        onClaim = { onClaimTask(t.id) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Task 5: Community & Support Desk
                if (tasksConfig.taskCommunityDesk.isEnabled) {
                    val t = tasksConfig.taskCommunityDesk
                    TaskItemCard(
                        icon = Icons.Default.Help,
                        title = t.title,
                        description = t.description,
                        current = if (userTasksState.isCommunityDeskClaimed) 1 else 1,
                        target = t.targetCount,
                        rewardCoins = t.rewardCoins,
                        isClaimed = userTasksState.isCommunityDeskClaimed,
                        onClaim = { onClaimTask(t.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PromoProgressRow(
    label: String,
    current: Int,
    target: Int
) {
    val progressFraction = (current.toFloat() / target.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
    val isComplete = current >= target

    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(
                text = "$current / $target",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isComplete) SuccessGreen else CoinGold
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        LinearProgressIndicator(
            progress = { progressFraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color = if (isComplete) SuccessGreen else RedPrimary,
            trackColor = Color(0xFF4A1E1E),
        )
    }
}

@Composable
private fun TaskItemCard(
    icon: ImageVector,
    title: String,
    description: String,
    current: Int,
    target: Int,
    rewardCoins: Int,
    isClaimed: Boolean,
    onClaim: () -> Unit
) {
    val isReadyToClaim = current >= target && !isClaimed
    val progressFraction = (current.toFloat() / target.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(RedPrimary.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = RedPrimary, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(description, fontSize = 10.sp, color = Color.Gray)
                    }
                }
                Text("+$rewardCoins c", fontWeight = FontWeight.Black, fontSize = 12.sp, color = CoinGold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Progress", fontSize = 10.sp, color = Color.Gray)
                        Text("$current / $target", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    LinearProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp),
                        color = if (current >= target) SuccessGreen else RedPrimary,
                        trackColor = Color(0xFF333333),
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                if (isClaimed) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF1E331E), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Claimed", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                    }
                } else {
                    Button(
                        onClick = onClaim,
                        enabled = isReadyToClaim,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isReadyToClaim) SuccessGreen else Color.DarkGray,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text(if (isReadyToClaim) "Claim" else "In Progress", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
