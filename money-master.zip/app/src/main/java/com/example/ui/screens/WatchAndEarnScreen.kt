package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.data.local.entity.CampaignEntity
import com.example.data.model.AppUpdateConfig
import com.example.data.youtube.YouTubeApiService
import com.example.ui.components.AppUpdateDialog
import com.example.ui.theme.CoinGold
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen

@Composable
fun WatchAndEarnScreen(
    currentCampaign: CampaignEntity?,
    activeCampaigns: List<CampaignEntity>,
    isWatching: Boolean,
    remainingSeconds: Int,
    totalSeconds: Int,
    isTimerFinished: Boolean = remainingSeconds <= 0,
    isVideoPlaying: Boolean = true,
    isSubscribed: Boolean,
    isLiked: Boolean,
    fastMode: Boolean,
    dailyAdsWatched: Int,
    maxDailyAds: Int,
    isVerifyingYouTube: Boolean,
    youTubeVerificationStatus: String?,
    showNotEnoughWatchTimeDialog: Boolean = false,
    showNotSubscribedDialog: Boolean = false,
    isFullWatchMode: Boolean = false,
    isUpdateRequired: Boolean = false,
    appUpdateConfig: AppUpdateConfig = AppUpdateConfig(),
    onDismissNotEnoughWatchTimeDialog: () -> Unit = {},
    onDismissNotSubscribedDialog: () -> Unit = {},
    onStartWatching: () -> Unit,
    onStopWatching: () -> Unit,
    onOpenFullWatch: () -> Unit = {},
    onExitFullWatch: () -> Unit = {},
    onSimulateUpdate: () -> Unit = {},
    onVideoStateChanged: (Boolean) -> Unit = {},
    onSubscribeDetected: () -> Unit = {},
    onLikeDetected: () -> Unit = {},
    onCommentDetected: () -> Unit = {},
    onSeekAttempted: () -> Unit = {},
    onUnsubscribeDetected: () -> Unit = {},
    onToggleSubscribe: () -> Unit,
    onWatchOnYouTube: () -> Unit = {},
    onToggleLike: () -> Unit,
    onToggleFastMode: () -> Unit,
    onSelectCampaign: (CampaignEntity) -> Unit,
    onWatchAd: () -> Unit,
    onSeeOther: () -> Unit = {},
    onPrevious: () -> Unit = onSeeOther,
    onNext: () -> Unit = onSeeOther,
    onVerifyAndRewardUser: () -> Unit = {},
    onLikeVideo: () -> Unit = {},
    onCommentVideo: (String) -> Unit = {},
    accessToken: String = "",
    onDirectVerifiedSuccess: ((CampaignEntity, Int) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val progress = if (totalSeconds > 0) {
        ((totalSeconds - remainingSeconds).toFloat() / totalSeconds).coerceIn(0f, 1f)
    } else 0f

    var showCommentDialog by remember { mutableStateOf(false) }
    var localNotEnoughWatchTimeDialog by remember { mutableStateOf(false) }
    var showUpdateDialog by remember { mutableStateOf(false) }
    var showExternalVerificationScreen by remember { mutableStateOf(false) }

    // Direct YouTube Verification Screen (YouTube Data API v3 verification)
    if (showExternalVerificationScreen && currentCampaign != null) {
        val targetChannelId = if (currentCampaign.channelId.startsWith("UC")) currentCampaign.channelId else ""
        YouTubeVerificationScreen(
            channelId = targetChannelId,
            videoUrl = currentCampaign.videoUrl,
            channelName = currentCampaign.channelName,
            accessToken = accessToken,
            coinReward = currentCampaign.rewardCoins,
            onVerifiedSuccess = {
                showExternalVerificationScreen = false
                if (onDirectVerifiedSuccess != null) {
                    onDirectVerifiedSuccess(currentCampaign, currentCampaign.rewardCoins)
                } else {
                    onVerifyAndRewardUser()
                }
            },
            onVerificationFailed = { _ -> },
            onBackPressed = { showExternalVerificationScreen = false }
        )
        return
    }

    // DIALOG 1: "Not enough watching time." (From USub screenshot)
    if (showNotEnoughWatchTimeDialog || localNotEnoughWatchTimeDialog) {
        AlertDialog(
            onDismissRequest = {
                localNotEnoughWatchTimeDialog = false
                onDismissNotEnoughWatchTimeDialog()
            },
            title = {
                Text(
                    text = "Not enough watching time.",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.Black
                )
            },
            text = {
                Text(
                    text = "You need watch video at least 60 second before subscribing. If not YT will remove your subscriber. Please watching video again.",
                    style = androidx.compose.ui.text.TextStyle(
                        fontStyle = FontStyle.Italic,
                        fontSize = 14.sp,
                        color = Color(0xFF424242),
                        lineHeight = 20.sp
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        localNotEnoughWatchTimeDialog = false
                        onDismissNotEnoughWatchTimeDialog()
                        onStartWatching()
                    }
                ) {
                    Text(
                        text = "WATCH AGAIN",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD32F2F),
                        fontStyle = FontStyle.Italic
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        localNotEnoughWatchTimeDialog = false
                        onDismissNotEnoughWatchTimeDialog()
                        onSeeOther()
                    }
                ) {
                    Text(
                        text = "CHANNEL NOT FOUND",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD32F2F),
                        fontStyle = FontStyle.Italic
                    )
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(8.dp)
        )
    }

    // DIALOG 2: Subscribe, Like & Comment verification
    if (showNotSubscribedDialog) {
        AlertDialog(
            onDismissRequest = onDismissNotSubscribedDialog,
            title = {
                Text(
                    text = "Action Required: Subscribe, Like & Comment",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color.Black
                )
            },
            text = {
                Text(
                    text = "You must Subscribe, Like, and Comment on this YouTube video to receive your coins. Please complete all 3 actions on YouTube to get rewarded!",
                    style = androidx.compose.ui.text.TextStyle(
                        fontStyle = FontStyle.Italic,
                        fontSize = 14.sp,
                        color = Color(0xFF424242),
                        lineHeight = 20.sp
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDismissNotSubscribedDialog()
                        onOpenFullWatch()
                    }
                ) {
                    Text(
                        text = "WATCH IN-APP",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD32F2F),
                        fontStyle = FontStyle.Italic
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        onDismissNotSubscribedDialog()
                        onSeeOther()
                    }
                ) {
                    Text(
                        text = "SEE OTHER",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD32F2F),
                        fontStyle = FontStyle.Italic
                    )
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(8.dp)
        )
    }

    // COMMENT DIALOG
    if (showCommentDialog) {
        var commentText by remember { mutableStateOf("") }
        val quickComments = listOf(
            "Awesome video! 👍",
            "Super helpful tutorial 🔥",
            "Subscribed and liked ❤️",
            "Great content, keep going! 🚀"
        )

        AlertDialog(
            onDismissRequest = { showCommentDialog = false },
            title = {
                Text(
                    text = "Comment on Video (+20 Coins)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Post a comment to support this creator and earn +20 bonus coins:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        placeholder = { Text("Write your comment here...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RedPrimary,
                            cursorColor = RedPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Quick Suggestions:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    quickComments.forEach { suggestion ->
                        Text(
                            text = suggestion,
                            fontSize = 12.sp,
                            color = RedPrimary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { commentText = suggestion }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (commentText.isNotBlank()) {
                            onCommentVideo(commentText)
                            showCommentDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                    enabled = commentText.isNotBlank()
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Post & Claim")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCommentDialog = false }) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(12.dp)
        )
    }

    // IF IN FULL WATCH MODE: Display the full YouTube watch view matching Screenshot 2!
    if (isFullWatchMode && currentCampaign != null) {
        if (isUpdateRequired) {
            Box(
                modifier = modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SystemUpdate,
                            contentDescription = null,
                            tint = RedPrimary,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Update Required to Watch Videos",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Admin has released Sub Exchange v${appUpdateConfig.versionName}. Video watching is disabled until you update the app.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { showUpdateDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Update Now", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = onExitFullWatch,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Back to Home")
                        }
                    }
                }
            }
            if (showUpdateDialog) {
                AppUpdateDialog(
                    updateConfig = appUpdateConfig,
                    isMandatory = true,
                    onDismiss = { showUpdateDialog = false },
                    onUpdateVerified = {
                        onSimulateUpdate()
                        showUpdateDialog = false
                    }
                )
            }
            return
        }

        FullYouTubeWatchView(
            campaign = currentCampaign,
            remainingSeconds = remainingSeconds,
            totalSeconds = totalSeconds,
            isTimerFinished = isTimerFinished,
            isVideoPlaying = isVideoPlaying,
            isSubscribed = isSubscribed,
            isLiked = isLiked,
            onVideoStateChanged = onVideoStateChanged,
            onReturnApp = onVerifyAndRewardUser,
            onOpenExternalVerification = { showExternalVerificationScreen = true },
            onMenuClick = {
                if (!isTimerFinished && remainingSeconds > 0) {
                    localNotEnoughWatchTimeDialog = true
                } else {
                    onVerifyAndRewardUser()
                }
            },
            onSubscribeDetected = onSubscribeDetected,
            onLikeDetected = onLikeDetected,
            onCommentDetected = onCommentDetected,
            onSeekAttempted = onSeekAttempted,
            onUnsubscribeDetected = onUnsubscribeDetected,
            onToggleSubscribe = onToggleSubscribe,
            onToggleLike = onToggleLike,
            onBackPressed = {
                if (!isTimerFinished && remainingSeconds > 0) {
                    localNotEnoughWatchTimeDialog = true
                } else {
                    onVerifyAndRewardUser()
                }
            },
            modifier = modifier
        )
        return
    }

    // If no active campaigns are available:
    if (activeCampaigns.isEmpty() || currentCampaign == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(RedPrimary.copy(alpha = 0.12f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Subscriptions,
                            contentDescription = null,
                            tint = RedPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "නැරඹීමට වීඩියෝ නොමැත",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "You have completed all available campaigns, or no new campaigns have been launched yet. Create your own campaign in the Campaign tab to receive views & subscribers!",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }
        }
        return
    }

    // NORMAL USUB SUBSCRIBE DASHBOARD
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (isUpdateRequired) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .clickable { showUpdateDialog = true }
                        .testTag("update_warning_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.SystemUpdate,
                            contentDescription = null,
                            tint = RedPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Mandatory Update Required (v${appUpdateConfig.versionName})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFFC62828)
                            )
                            Text(
                                text = "Video watching is locked until you update. Tap to update now.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = { showUpdateDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Update", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else if (appUpdateConfig.lastAnnouncedTimestamp > 0L && (appUpdateConfig.requiredVersionCode > 1 || appUpdateConfig.updateMessage.isNotBlank())) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .clickable { showUpdateDialog = true }
                        .testTag("announcement_update_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "📢 ${appUpdateConfig.updateTitle.ifBlank { "New App Update (v${appUpdateConfig.versionName})" }}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF1B5E20)
                            )
                            Text(
                                text = appUpdateConfig.updateMessage.ifBlank { "Tap to view update details and download the new release." },
                                fontSize = 11.sp,
                                maxLines = 2,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = { showUpdateDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("View", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            // USub Top Status Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Subscribe & Earn Coins",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Watch video for 60s, subscribe & earn +${currentCampaign?.rewardCoins ?: 50} coins",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Verified Production Badge: 100% In-App & Synced
                Box(
                    modifier = Modifier
                        .background(SuccessGreen.copy(alpha = 0.12f), RoundedCornerShape(20.dp))
                        .border(1.dp, SuccessGreen.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "100% In-App",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SuccessGreen
                        )
                    }
                }
            }
        }

        // USub Main Card with Video Thumbnail Preview & Controls
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_player_card")
            ) {
                Column(
                    modifier = Modifier.padding(12.dp)
                ) {
                    // Admin Priority / Global Mandatory Campaign Header
                    val isAdminCampaign = currentCampaign != null && (
                        currentCampaign.isAdminPriority ||
                        currentCampaign.isGlobal ||
                        currentCampaign.creatorEmail.equals("amilalasantha940703@gmail.com", ignoreCase = true)
                    )
                    if (isAdminCampaign) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color(0xFFB71C1C), Color(0xFFD32F2F))
                                    )
                                )
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "👑 ඇඩ්මින් වීඩියෝව (ADMIN MANDATORY)",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Box(
                                    modifier = Modifier
                                        .background(CoinGold, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "GLOBAL CAMPAIGN",
                                        color = Color.Black,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Video Preview Container
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                            .clickable { onOpenFullWatch() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (currentCampaign != null && currentCampaign.thumbnailUrl.isNotBlank()) {
                            AsyncImage(
                                model = currentCampaign.thumbnailUrl,
                                contentDescription = "Video Thumbnail",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        brush = Brush.verticalGradient(
                                            listOf(Color(0x33000000), Color(0x99000000))
                                        )
                                    )
                            )
                        }

                        // Big Play button that launches full YouTube watch mode
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .background(RedPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play Video",
                                tint = Color.White,
                                modifier = Modifier.size(42.dp)
                            )
                        }

                        // Top Start Badge: Status indicator
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(10.dp)
                                .background(
                                    if (isWatching) RedPrimary else Color(0xCC000000),
                                    RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isWatching) "● READY TO WATCH" else "TAP TO WATCH",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Top End Reward Badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(10.dp)
                                .background(CoinGold, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "+${currentCampaign?.rewardCoins ?: 50} Coins",
                                    color = Color.Black,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    // Linear progress indicator
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .padding(top = 4.dp),
                        color = RedPrimary,
                        trackColor = Color(0xFFE0E0E0)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Video Title & Channel Info
                    Text(
                        text = currentCampaign?.videoTitle ?: "Select a YouTube Campaign",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentCampaign?.channelName ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Live Timer Display (Exact formatting requested by user)
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isTimerFinished) "You can subscribe now!" else if (!isVideoPlaying) "PAUSED: 00:${remainingSeconds.toString().padStart(2, '0')}" else "Time Remaining: 00:${remainingSeconds.toString().padStart(2, '0')}",
                            style = androidx.compose.ui.text.TextStyle(
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isTimerFinished) Color(0xFF2E7D32) else if (!isVideoPlaying) Color(0xFFF57C00) else Color.Red
                            ),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Verification status if checking
                    if (isVerifyingYouTube) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = RedPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = youTubeVerificationStatus ?: "Verifying subscription...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // USub Instruction Box (From screenshot 2)
        item {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                ),
                border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Instruction: Click SUBSCRIBE button below to watch video, subscribe & like on YouTube and return to receive coins. Like & comments are placed directly on the YouTube video.",
                    style = androidx.compose.ui.text.TextStyle(
                        fontStyle = FontStyle.Italic,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 17.sp
                    ),
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        // USub Warning Box (Exact text and italic styling from screenshot)
        item {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "DO NOT unsubscribe any channel. We will block your account and remove all your subscribers if you unsubscribe other channel.",
                    style = androidx.compose.ui.text.TextStyle(
                        fontStyle = FontStyle.Italic,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    ),
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        // Bottom Primary Actions: PREVIEW, SUBSCRIBE, NEXT (Cycle through uncompleted videos)
        item {
            val currentIndex = activeCampaigns.indexOfFirst { it.id == currentCampaign.id }
            Column(modifier = Modifier.fillMaxWidth()) {
                if (activeCampaigns.size > 1) {
                    Text(
                        text = "Video ${if (currentIndex >= 0) currentIndex + 1 else 1} of ${activeCampaigns.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(bottom = 8.dp)
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // PREVIEW Button (Previous video in queue)
                    Button(
                        onClick = onPrevious,
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFEF5350),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("preview_button"),
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Previous",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "PREVIEW",
                            style = androidx.compose.ui.text.TextStyle(
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Italic,
                                fontSize = 12.sp
                            )
                        )
                    }

                    // SUBSCRIBE Button (Red prominent center action)
                    Button(
                        onClick = {
                            if (isUpdateRequired) {
                                showUpdateDialog = true
                            } else {
                                onOpenFullWatch()
                            }
                        },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFD32F2F),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(50.dp)
                            .testTag("subscribe_button"),
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) {
                        Text(
                            text = "SUBSCRIBE",
                            style = androidx.compose.ui.text.TextStyle(
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Italic,
                                fontSize = 15.sp,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }

                    // NEXT Button (Next video in queue)
                    Button(
                        onClick = onNext,
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFEF5350),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("next_button"),
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) {
                        Text(
                            text = "NEXT",
                            style = androidx.compose.ui.text.TextStyle(
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Italic,
                                fontSize = 12.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Next",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Dedicated button to launch official YouTube app & verify via YouTube Data API v3
                OutlinedButton(
                    onClick = { showExternalVerificationScreen = true },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .testTag("open_external_verification_screen_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = null,
                        tint = RedPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Open in YouTube & Verify (Data API v3)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showUpdateDialog) {
        AppUpdateDialog(
            updateConfig = appUpdateConfig,
            isMandatory = isUpdateRequired,
            onDismiss = { showUpdateDialog = false },
            onUpdateVerified = {
                onSimulateUpdate()
                showUpdateDialog = false
            }
        )
    }
}

/**
 * FULL YOUTUBE WATCH SCREEN (Matching Screenshot 2)
 * Loads the real mobile YouTube watch page (m.youtube.com/watch?v=...)
 * During watch countdown: Screen is locked and timer synchronizes with play/pause!
 * When timer ends: Screen unlocks for real Subscribe, Like, and Comments!
 */
/**
 * Safe ActionMode callback that cancels action mode cleanly without desynchronizing DecorView's FloatingActionMode.
 */
private class SafeActionModeCallback(
    private val original: android.view.ActionMode.Callback?
) : android.view.ActionMode.Callback {
    override fun onCreateActionMode(mode: android.view.ActionMode?, menu: android.view.Menu?): Boolean {
        // Return false cleanly so Android framework cancels the action mode gracefully
        return false
    }
    override fun onPrepareActionMode(mode: android.view.ActionMode?, menu: android.view.Menu?): Boolean = false
    override fun onActionItemClicked(mode: android.view.ActionMode?, item: android.view.MenuItem?): Boolean = false
    override fun onDestroyActionMode(mode: android.view.ActionMode?) {
        try { original?.onDestroyActionMode(mode) } catch (_: Exception) {}
    }
}

/**
 * FULL YOUTUBE WATCH SCREEN (Matching Screenshot 2)
 * Loads the real mobile YouTube watch page (m.youtube.com/watch?v=...)
 * During watch countdown: Screen is locked and timer synchronizes with play/pause!
 * When timer ends: Screen unlocks for real Subscribe, Like, and Comments!
 */
@Composable
fun FullYouTubeWatchView(
    campaign: CampaignEntity,
    remainingSeconds: Int,
    totalSeconds: Int,
    isTimerFinished: Boolean,
    isVideoPlaying: Boolean,
    isSubscribed: Boolean,
    isLiked: Boolean,
    onVideoStateChanged: (Boolean) -> Unit,
    onReturnApp: () -> Unit,
    onMenuClick: () -> Unit,
    onSubscribeDetected: () -> Unit,
    onLikeDetected: () -> Unit,
    onCommentDetected: () -> Unit,
    onSeekAttempted: () -> Unit = {},
    onUnsubscribeDetected: () -> Unit = {},
    onToggleSubscribe: () -> Unit,
    onToggleLike: () -> Unit,
    onBackPressed: () -> Unit,
    onOpenExternalVerification: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val videoId = remember(campaign.videoUrl) { YouTubeApiService.extractVideoId(campaign.videoUrl) }
    val youtubeMobileUrl = remember(videoId) { "https://m.youtube.com/watch?v=$videoId" }
    val youtubeEmbedUrl = remember(videoId) { "https://www.youtube-nocookie.com/embed/$videoId?autoplay=1&enablejsapi=1&playsinline=1&rel=0&controls=1" }
    var useLiteEmbedPlayer by remember { mutableStateOf(false) }
    var renderProcessCrashed by remember { mutableStateOf(false) }
    var reloadKey by remember { mutableStateOf(0) }

    BackHandler {
        onBackPressed()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Anti-Fast-Forward / Seeking Lock Notice during countdown & Player Mode Switcher
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (!isTimerFinished) Color(0xFFB71C1C) else Color(0xFF212121))
                .padding(vertical = 5.dp, horizontal = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (!isTimerFinished) Icons.Default.Lock else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (!isTimerFinished) "🔒 Seeking Blocked • Watch ${remainingSeconds}s" else "✓ Watch Done • Subscribe & Like Below",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Switch between Lite Player and Standard Web Player
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (useLiteEmbedPlayer) SuccessGreen.copy(alpha = 0.85f) else Color(0x33FFFFFF))
                        .clickable {
                            useLiteEmbedPlayer = !useLiteEmbedPlayer
                            renderProcessCrashed = false
                            reloadKey++
                        }
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (useLiteEmbedPlayer) "⚡ Lite Player" else "🌐 Web Player",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Full Mobile YouTube WebView with Screen Lock during countdown
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.Black)
        ) {
            if (renderProcessCrashed) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                        .align(Alignment.Center)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = RedPrimary,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Video Player Recovered",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "The graphics engine was safely reset. Switch to Lite Mode for 100% stable in-app playback, or launch in the YouTube app.",
                            color = Color(0xFFCCCCCC),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    useLiteEmbedPlayer = true
                                    renderProcessCrashed = false
                                    reloadKey++
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RedPrimary)
                            ) {
                                Text("Play in Lite Mode", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = onOpenExternalVerification,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                            ) {
                                Text("YouTube App & Verify", fontSize = 12.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(
                            onClick = {
                                useLiteEmbedPlayer = false
                                renderProcessCrashed = false
                                reloadKey++
                            }
                        ) {
                            Text("Retry Standard Web Player", color = Color(0xFFAAAAAA), fontSize = 11.sp)
                        }
                    }
                }
            } else {
                key(reloadKey) {
                    AndroidView(
                        factory = { ctx ->
                            object : WebView(ctx) {
                                override fun startActionMode(callback: android.view.ActionMode.Callback?): android.view.ActionMode? {
                                    return super.startActionMode(SafeActionModeCallback(callback))
                                }
                                override fun startActionMode(callback: android.view.ActionMode.Callback?, type: Int): android.view.ActionMode? {
                                    return super.startActionMode(SafeActionModeCallback(callback), type)
                                }
                            }.apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                isLongClickable = false
                                setOnLongClickListener { true }
                                isHapticFeedbackEnabled = false

                                // If in Lite Mode or after a crash, force software rendering to prevent MESA/GPU emulator crashes
                                if (useLiteEmbedPlayer) {
                                    try {
                                        setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
                                    } catch (_: Exception) {}
                                }

                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    databaseEnabled = true
                                    mediaPlaybackRequiresUserGesture = false
                                    loadWithOverviewMode = true
                                    useWideViewPort = true
                                    cacheMode = WebSettings.LOAD_DEFAULT
                                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                    userAgentString = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                                    setSupportMultipleWindows(false)
                                    setGeolocationEnabled(false)
                                    allowFileAccess = false
                                    allowContentAccess = false
                                }

                                // Bridge to detect video play/pause, anti-seeking, and interaction on YouTube
                                addJavascriptInterface(object {
                                    @android.webkit.JavascriptInterface
                                    fun onSubscribeClicked() {
                                        onSubscribeDetected()
                                    }
                                    @android.webkit.JavascriptInterface
                                    fun onLikeClicked() {
                                        onLikeDetected()
                                    }
                                    @android.webkit.JavascriptInterface
                                    fun onCommentSubmitted() {
                                        onCommentDetected()
                                    }
                                    @android.webkit.JavascriptInterface
                                    fun onVideoStateChanged(playing: Boolean) {
                                        onVideoStateChanged(playing)
                                    }
                                    @android.webkit.JavascriptInterface
                                    fun onSeekAttempted() {
                                        onSeekAttempted()
                                    }
                                    @android.webkit.JavascriptInterface
                                    fun onUnsubscribeClicked() {
                                        onUnsubscribeDetected()
                                    }
                                }, "AndroidBridge")

                                webViewClient = object : WebViewClient() {
                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        super.onPageFinished(view, url)
                                        if (useLiteEmbedPlayer) {
                                            val liteJs = """
                                                (function() {
                                                    function syncVideo() {
                                                        var v = document.querySelector('video');
                                                        if (v && !v.__liteBound) {
                                                            v.__liteBound = true;
                                                            v.addEventListener('play', function() { if (window.AndroidBridge) window.AndroidBridge.onVideoStateChanged(true); });
                                                            v.addEventListener('playing', function() { if (window.AndroidBridge) window.AndroidBridge.onVideoStateChanged(true); });
                                                            v.addEventListener('pause', function() { if (window.AndroidBridge) window.AndroidBridge.onVideoStateChanged(false); });
                                                            v.addEventListener('ended', function() { if (window.AndroidBridge) window.AndroidBridge.onVideoStateChanged(false); });
                                                            if (window.AndroidBridge) window.AndroidBridge.onVideoStateChanged(!v.paused && !v.ended);
                                                        }
                                                    }
                                                    syncVideo();
                                                    setInterval(syncVideo, 1200);
                                                })();
                                            """.trimIndent()
                                            view?.evaluateJavascript(liteJs, null)
                                        } else {
                                            // Injected listener: Anti-seeking block, play/pause sync, subscribe/like detection, and unsubscribe ban detection
                                            val js = """
                                                (function() {
                                                    window.__timerFinished = ${if (isTimerFinished) "true" else "false"};

                                                    try {
                                                        var style = document.getElementById('usub-opt-style');
                                                        if (!style) {
                                                            style = document.createElement('style');
                                                            style.id = 'usub-opt-style';
                                                            style.innerHTML = 'ytm-item-section-renderer:nth-of-type(n+4), ytm-reel-shelf-renderer, ytm-related-chip-cloud-renderer { display: none !important; } .ytp-progress-bar, .ytp-progress-bar-container, .ytm-progress-bar, .progress-bar-line, .progress-bar-background, .progress-bar-playhead, input[type="range"] { pointer-events: none !important; touch-action: none !important; }';
                                                            document.head.appendChild(style);
                                                        }
                                                    } catch(e) {}

                                                    var lastReportedState = null;
                                                    function reportVideoState(playing) {
                                                        if (playing !== lastReportedState) {
                                                            lastReportedState = playing;
                                                            if (window.AndroidBridge && window.AndroidBridge.onVideoStateChanged) {
                                                                window.AndroidBridge.onVideoStateChanged(playing);
                                                            }
                                                        }
                                                    }

                                                    var maxSeenTime = 0;
                                                    function bindVideo() {
                                                        var v = document.querySelector('video');
                                                        if (v && !v.__usubBound) {
                                                            v.__usubBound = true;
                                                            v.addEventListener('play', function() { reportVideoState(true); });
                                                            v.addEventListener('playing', function() { reportVideoState(true); });
                                                            v.addEventListener('pause', function() { reportVideoState(false); });
                                                            v.addEventListener('ended', function() { reportVideoState(false); });
                                                            v.addEventListener('timeupdate', function() {
                                                                if (!window.__timerFinished) {
                                                                    if (v.currentTime > maxSeenTime + 1.2) {
                                                                        v.currentTime = maxSeenTime;
                                                                        if (window.AndroidBridge && window.AndroidBridge.onSeekAttempted) {
                                                                            window.AndroidBridge.onSeekAttempted();
                                                                        }
                                                                    } else {
                                                                        maxSeenTime = Math.max(maxSeenTime, v.currentTime);
                                                                    }
                                                                }
                                                            });
                                                            v.addEventListener('seeking', function() {
                                                                if (!window.__timerFinished && v.currentTime > maxSeenTime + 0.5) {
                                                                    v.currentTime = maxSeenTime;
                                                                    if (window.AndroidBridge && window.AndroidBridge.onSeekAttempted) {
                                                                        window.AndroidBridge.onSeekAttempted();
                                                                    }
                                                                }
                                                            });
                                                            reportVideoState(!v.paused && !v.ended && v.readyState > 2);
                                                        }
                                                    }

                                                    bindVideo();
                                                    var scanCount = 0;
                                                    var scanTimer = setInterval(function() {
                                                        bindVideo();
                                                        scanCount++;
                                                        var v = document.querySelector('video');
                                                        if (scanCount > 8 && v && v.__usubBound) {
                                                            clearInterval(scanTimer);
                                                            setInterval(bindVideo, 4000);
                                                        }
                                                    }, 1200);

                                                    if (!window.__usubClickBound) {
                                                        window.__usubClickBound = true;
                                                        document.addEventListener('click', function(e) {
                                                            var el = e.target;
                                                            while (el && el !== document) {
                                                                var text = (el.innerText || el.textContent || '').trim().toLowerCase();
                                                                var aria = (el.getAttribute('aria-label') || '').toLowerCase();
                                                                
                                                                if (text.indexOf('unsubscribe') !== -1 || text.indexOf('unsubscribed') !== -1 || aria.indexOf('unsubscribe') !== -1) {
                                                                    if (window.AndroidBridge && window.AndroidBridge.onUnsubscribeClicked) {
                                                                        window.AndroidBridge.onUnsubscribeClicked();
                                                                    }
                                                                }
                                                                
                                                                if (text.indexOf('subscribe') !== -1 || text.indexOf('subscribed') !== -1 || aria.indexOf('subscribe') !== -1) {
                                                                    if (window.AndroidBridge && window.AndroidBridge.onSubscribeClicked) window.AndroidBridge.onSubscribeClicked();
                                                                }
                                                                if ((aria.indexOf('like') !== -1 && aria.indexOf('dislike') === -1) || text.indexOf('like') !== -1) {
                                                                    if (window.AndroidBridge && window.AndroidBridge.onLikeClicked) window.AndroidBridge.onLikeClicked();
                                                                }
                                                                if (text.indexOf('comment') !== -1 || aria.indexOf('comment') !== -1) {
                                                                    if (window.AndroidBridge && window.AndroidBridge.onCommentSubmitted) window.AndroidBridge.onCommentSubmitted();
                                                                }
                                                                el = el.parentElement;
                                                            }
                                                        }, true);
                                                    }
                                                })();
                                            """.trimIndent()
                                            view?.evaluateJavascript(js, null)
                                        }
                                    }

                                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                        return false
                                    }

                                    override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                                        try {
                                            view?.stopLoading()
                                            (view?.parent as? ViewGroup)?.removeView(view)
                                            view?.destroy()
                                        } catch (_: Exception) {}
                                        useLiteEmbedPlayer = true
                                        renderProcessCrashed = true
                                        return true
                                    }
                                }

                                val targetUrl = if (useLiteEmbedPlayer) youtubeEmbedUrl else youtubeMobileUrl
                                loadUrl(targetUrl)
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        // Authentic In-App YouTube Interaction Bar (Original YouTube Style Subscribe & Like)
        Card(
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 0.dp, bottomEnd = 0.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(
                    text = campaign.videoTitle,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Channel Avatar & Title
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(RedPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = campaign.channelName.firstOrNull()?.uppercase() ?: "Y",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = campaign.channelName,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "YouTube Creator",
                                color = Color(0xFFAAAAAA),
                                fontSize = 10.sp
                            )
                        }
                    }

                    // In-App YouTube SUBSCRIBE Button
                    Button(
                        onClick = onToggleSubscribe,
                        enabled = isTimerFinished || isSubscribed,
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSubscribed) Color(0xFF272727) else Color(0xFFCC0000),
                            contentColor = Color.White,
                            disabledContainerColor = Color(0xFF333333),
                            disabledContentColor = Color(0xFF888888)
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("in_app_subscribe_button")
                    ) {
                        if (isSubscribed) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SUBSCRIBED", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else if (!isTimerFinished) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = Color(0xFFAAAAAA),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("LOCK (${remainingSeconds}s)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Text("SUBSCRIBE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // In-App YouTube LIKE Button (Pill Button)
                    Button(
                        onClick = onToggleLike,
                        enabled = isTimerFinished || isLiked,
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isLiked) Color(0xFF333333) else Color(0xFF272727),
                            contentColor = if (isLiked) Color(0xFF3EA6FF) else Color.White,
                            disabledContainerColor = Color(0xFF222222),
                            disabledContentColor = Color(0xFF666666)
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("in_app_like_button")
                    ) {
                        Icon(
                            imageVector = if (isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                            contentDescription = "Like",
                            tint = if (isLiked) Color(0xFF3EA6FF) else if (!isTimerFinished) Color(0xFF666666) else Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isLiked) "Liked" else "Like",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // USub Bottom Bar (Matching Screenshots 1 & 2)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .background(Color.White)
                .border(
                    width = 1.dp,
                    color = Color(0xFFE0E0E0)
                )
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Menu icon on the left
                IconButton(
                    onClick = onMenuClick,
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = Color(0xFF424242),
                        modifier = Modifier.size(24.dp)
                    )
                }

                if (!isTimerFinished && remainingSeconds > 0) {
                    // Synced Timer: Large countdown number when playing, PAUSED when paused
                    Box(
                        modifier = Modifier.weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isVideoPlaying) {
                            Text(
                                text = remainingSeconds.toString(),
                                style = androidx.compose.ui.text.TextStyle(
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontStyle = FontStyle.Italic,
                                    color = Color(0xFF424242),
                                    letterSpacing = 1.sp
                                )
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Pause,
                                    contentDescription = "Paused",
                                    tint = Color(0xFFE65100),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "PAUSED ($remainingSeconds)",
                                    style = androidx.compose.ui.text.TextStyle(
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontStyle = FontStyle.Italic,
                                        color = Color(0xFFE65100)
                                    )
                                )
                            }
                        }
                    }
                    // Spacer for layout balance
                    Spacer(modifier = Modifier.size(40.dp))
                } else {
                    // Timer finished: Prompt to subscribe & like in-app + [RETURN APP]
                    Text(
                        text = if (!isSubscribed || !isLiked) "👉 Tap SUBSCRIBE & LIKE above" else "✅ Verified! Tap Return",
                        style = androidx.compose.ui.text.TextStyle(
                            fontSize = 12.sp,
                            fontStyle = FontStyle.Italic,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF424242)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp)
                    )

                    Button(
                        onClick = onReturnApp,
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF8D6E63) // Brown/gold color from screenshot
                        ),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("return_app_button")
                    ) {
                        Text(
                            text = "RETURN APP",
                            style = androidx.compose.ui.text.TextStyle(
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CampaignListItem(
    campaign: CampaignEntity,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) RedPrimary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("campaign_item_${campaign.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(width = 84.dp, height = 54.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.DarkGray)
            ) {
                if (campaign.thumbnailUrl.isNotBlank()) {
                    AsyncImage(
                        model = campaign.thumbnailUrl,
                        contentDescription = "Thumbnail",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x22000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = campaign.videoTitle,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = campaign.channelName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(RedPrimary.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${campaign.durationSeconds}s",
                            color = RedPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${campaign.currentCount}/${campaign.targetCount} subs",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Box(
                modifier = Modifier
                    .background(CoinGold.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "+${campaign.rewardCoins}",
                    color = Color(0xFFF57F17),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}
