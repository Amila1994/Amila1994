package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AdminTasksConfig
import com.example.ui.theme.CoinGold
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen

@Composable
fun AdminPromoTasksDialog(
    currentConfig: AdminTasksConfig,
    onSave: (AdminTasksConfig) -> Unit,
    onDismiss: () -> Unit
) {
    // Promo Event States
    var isPromoActive by remember { mutableStateOf(currentConfig.promoEvent.isEventActive) }
    var promoTitle by remember { mutableStateOf(currentConfig.promoEvent.title) }
    var promoDesc by remember { mutableStateOf(currentConfig.promoEvent.description) }
    var promoDurationHours by remember { mutableStateOf(currentConfig.promoEvent.durationHours.toString()) }
    var promoTargetCampaigns by remember { mutableStateOf(currentConfig.promoEvent.targetCampaigns.toString()) }
    var promoTargetSubs by remember { mutableStateOf(currentConfig.promoEvent.targetSubscribes.toString()) }
    var promoTargetLikes by remember { mutableStateOf(currentConfig.promoEvent.targetLikes.toString()) }
    var promoRewardCoins by remember { mutableStateOf(currentConfig.promoEvent.rewardCoins.toString()) }

    // Referral Settings
    var referralRewardCoins by remember { mutableStateOf(currentConfig.referralRewardCoins.toString()) }
    var referredWelcomeCoins by remember { mutableStateOf(currentConfig.referredWelcomeCoins.toString()) }
    var apkDownloadUrl by remember { mutableStateOf(currentConfig.apkDownloadUrl) }

    // Task 1: Watch Streak
    var task1Enabled by remember { mutableStateOf(currentConfig.taskWatchStreak.isEnabled) }
    var task1Target by remember { mutableStateOf(currentConfig.taskWatchStreak.targetCount.toString()) }
    var task1Reward by remember { mutableStateOf(currentConfig.taskWatchStreak.rewardCoins.toString()) }

    // Task 2: Daily Login
    var task2Enabled by remember { mutableStateOf(currentConfig.taskDailyLogin.isEnabled) }
    var task2Reward by remember { mutableStateOf(currentConfig.taskDailyLogin.rewardCoins.toString()) }

    // Task 3: Invite Friend
    var task3Enabled by remember { mutableStateOf(currentConfig.taskInviteFriend.isEnabled) }
    var task3Target by remember { mutableStateOf(currentConfig.taskInviteFriend.targetCount.toString()) }
    var task3Reward by remember { mutableStateOf(currentConfig.taskInviteFriend.rewardCoins.toString()) }

    // Task 4: High Watch Time
    var task4Enabled by remember { mutableStateOf(currentConfig.taskHighWatchTime.isEnabled) }
    var task4Target by remember { mutableStateOf(currentConfig.taskHighWatchTime.targetCount.toString()) }
    var task4Reward by remember { mutableStateOf(currentConfig.taskHighWatchTime.rewardCoins.toString()) }

    // Task 5: Community Desk
    var task5Enabled by remember { mutableStateOf(currentConfig.taskCommunityDesk.isEnabled) }
    var task5Reward by remember { mutableStateOf(currentConfig.taskCommunityDesk.rewardCoins.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("admin_promo_tasks_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(RedPrimary.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null, tint = RedPrimary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Admin: Promo & Tasks Control", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("ප්‍රවර්ධන කාලය සහ කාර්යයන් පාලනය", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // SECTION 1: PROMOTION EVENT
                Text("🔥 LIMITED-TIME PROMOTION EVENT", fontWeight = FontWeight.Black, fontSize = 12.sp, color = RedPrimary)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Promotion Event Active (සක්‍රීය බව):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Switch(
                        checked = isPromoActive,
                        onCheckedChange = { isPromoActive = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = RedPrimary)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                AdminField(label = "Promo Title", value = promoTitle, onValueChange = { promoTitle = it })
                AdminField(label = "Promo Description", value = promoDesc, onValueChange = { promoDesc = it })
                AdminField(label = "Promo Duration (Hours)", value = promoDurationHours, onValueChange = { promoDurationHours = it }, keyboardType = KeyboardType.Number)
                AdminField(label = "Target Campaigns to Create", value = promoTargetCampaigns, onValueChange = { promoTargetCampaigns = it }, keyboardType = KeyboardType.Number)
                AdminField(label = "Target Channels to Subscribe", value = promoTargetSubs, onValueChange = { promoTargetSubs = it }, keyboardType = KeyboardType.Number)
                AdminField(label = "Target Videos to Like", value = promoTargetLikes, onValueChange = { promoTargetLikes = it }, keyboardType = KeyboardType.Number)
                AdminField(label = "Promo Reward Coins (Auto Added)", value = promoRewardCoins, onValueChange = { promoRewardCoins = it }, keyboardType = KeyboardType.Number)

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                Spacer(modifier = Modifier.height(14.dp))

                // SECTION 2: REFERRAL & APK DOWNLOAD
                Text("🎁 REFERRAL & APK DOWNLOAD SETTINGS", fontWeight = FontWeight.Black, fontSize = 12.sp, color = CoinGold)
                Spacer(modifier = Modifier.height(6.dp))
                AdminField(label = "Coins for Inviter per Referral Download", value = referralRewardCoins, onValueChange = { referralRewardCoins = it }, keyboardType = KeyboardType.Number)
                AdminField(label = "Welcome Coins for New Invitee", value = referredWelcomeCoins, onValueChange = { referredWelcomeCoins = it }, keyboardType = KeyboardType.Number)
                AdminField(label = "Android Debug APK Direct Download URL", value = apkDownloadUrl, onValueChange = { apkDownloadUrl = it })

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                Spacer(modifier = Modifier.height(14.dp))

                // SECTION 3: 5 APP-TAILORED ENGAGEMENT TASKS
                Text("🎯 5 ENGAGEMENT TASKS CONTROL", fontWeight = FontWeight.Black, fontSize = 12.sp, color = SuccessGreen)
                Spacer(modifier = Modifier.height(8.dp))

                // Task 1: Watch Streak
                TaskAdminRow(
                    taskName = "1. Watch Streak Task",
                    isEnabled = task1Enabled,
                    onToggle = { task1Enabled = it },
                    target = task1Target,
                    onTargetChange = { task1Target = it },
                    reward = task1Reward,
                    onRewardChange = { task1Reward = it }
                )

                // Task 2: Daily Login
                TaskAdminRow(
                    taskName = "2. Daily Check-In Task",
                    isEnabled = task2Enabled,
                    onToggle = { task2Enabled = it },
                    target = "1",
                    onTargetChange = {},
                    reward = task2Reward,
                    onRewardChange = { task2Reward = it },
                    isTargetFixed = true
                )

                // Task 3: Invite Friend
                TaskAdminRow(
                    taskName = "3. Refer Friend Task",
                    isEnabled = task3Enabled,
                    onToggle = { task3Enabled = it },
                    target = task3Target,
                    onTargetChange = { task3Target = it },
                    reward = task3Reward,
                    onRewardChange = { task3Reward = it }
                )

                // Task 4: High Watch Time
                TaskAdminRow(
                    taskName = "4. Deep Watch (120s+) Task",
                    isEnabled = task4Enabled,
                    onToggle = { task4Enabled = it },
                    target = task4Target,
                    onTargetChange = { task4Target = it },
                    reward = task4Reward,
                    onRewardChange = { task4Reward = it }
                )

                // Task 5: Community & Help Desk
                TaskAdminRow(
                    taskName = "5. Community & Support Task",
                    isEnabled = task5Enabled,
                    onToggle = { task5Enabled = it },
                    target = "1",
                    onTargetChange = {},
                    reward = task5Reward,
                    onRewardChange = { task5Reward = it },
                    isTargetFixed = true
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Save Button
                Button(
                    onClick = {
                        val hours = promoDurationHours.toIntOrNull() ?: 48
                        val updated = currentConfig.copy(
                            promoEvent = currentConfig.promoEvent.copy(
                                isEventActive = isPromoActive,
                                title = promoTitle.trim(),
                                description = promoDesc.trim(),
                                durationHours = hours,
                                endTimestamp = System.currentTimeMillis() + (hours * 3600 * 1000L),
                                targetCampaigns = promoTargetCampaigns.toIntOrNull() ?: 2,
                                targetSubscribes = promoTargetSubs.toIntOrNull() ?: 5,
                                targetLikes = promoTargetLikes.toIntOrNull() ?: 5,
                                rewardCoins = promoRewardCoins.toIntOrNull() ?: 1000
                            ),
                            referralRewardCoins = referralRewardCoins.toIntOrNull() ?: 200,
                            referredWelcomeCoins = referredWelcomeCoins.toIntOrNull() ?: 100,
                            apkDownloadUrl = apkDownloadUrl.trim(),
                            taskWatchStreak = currentConfig.taskWatchStreak.copy(
                                isEnabled = task1Enabled,
                                targetCount = task1Target.toIntOrNull() ?: 5,
                                rewardCoins = task1Reward.toIntOrNull() ?: 150
                            ),
                            taskDailyLogin = currentConfig.taskDailyLogin.copy(
                                isEnabled = task2Enabled,
                                rewardCoins = task2Reward.toIntOrNull() ?: 75
                            ),
                            taskInviteFriend = currentConfig.taskInviteFriend.copy(
                                isEnabled = task3Enabled,
                                targetCount = task3Target.toIntOrNull() ?: 1,
                                rewardCoins = task3Reward.toIntOrNull() ?: 300
                            ),
                            taskHighWatchTime = currentConfig.taskHighWatchTime.copy(
                                isEnabled = task4Enabled,
                                targetCount = task4Target.toIntOrNull() ?: 3,
                                rewardCoins = task4Reward.toIntOrNull() ?: 250
                            ),
                            taskCommunityDesk = currentConfig.taskCommunityDesk.copy(
                                isEnabled = task5Enabled,
                                rewardCoins = task5Reward.toIntOrNull() ?: 100
                            )
                        )
                        onSave(updated)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save All Settings (සුරකින්න)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AdminField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(label, fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.height(2.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = RedPrimary,
                unfocusedBorderColor = Color.DarkGray
            )
        )
    }
}

@Composable
private fun TaskAdminRow(
    taskName: String,
    isEnabled: Boolean,
    onToggle: (Boolean) -> Unit,
    target: String,
    onTargetChange: (String) -> Unit,
    reward: String,
    onRewardChange: (String) -> Unit,
    isTargetFixed: Boolean = false
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(taskName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Switch(
                    checked = isEnabled,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(checkedThumbColor = SuccessGreen)
                )
            }
            if (isEnabled) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    if (!isTargetFixed) {
                        OutlinedTextField(
                            value = target,
                            onValueChange = onTargetChange,
                            label = { Text("Target", fontSize = 10.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    OutlinedTextField(
                        value = reward,
                        onValueChange = onRewardChange,
                        label = { Text("Reward Coins", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
        }
    }
}
