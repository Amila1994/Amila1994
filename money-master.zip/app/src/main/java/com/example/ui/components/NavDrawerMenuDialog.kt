package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.UserEntity
import com.example.ui.theme.CoinGoldDark
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen

@Composable
fun NavDrawerMenuDialog(
    user: UserEntity?,
    email: String,
    isAdmin: Boolean,
    pendingReloadCount: Int,
    onDismiss: () -> Unit,
    onOpenReload: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenReferral: () -> Unit = {},
    onOpenPromoTasks: () -> Unit = {},
    onOpenAppUpdates: () -> Unit = {},
    onOpenHelp: () -> Unit,
    onOpenAdminReloadManagement: () -> Unit,
    onOpenAdminManageUsers: () -> Unit,
    onOpenAdminEconomy: () -> Unit,
    onOpenAdminUpdateSettings: () -> Unit,
    onOpenAdminPromoTasks: () -> Unit = {},
    onLogout: () -> Unit
) {
    val isPrimaryAdmin = com.example.data.firebase.FirebaseService.isAppAdmin(email) || user?.isAdmin == true

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .wrapContentHeight()
                .padding(vertical = 24.dp)
                .testTag("nav_drawer_menu_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .padding(18.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(RedPrimary.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPrimaryAdmin) Icons.Default.Shield else Icons.Default.Person,
                                contentDescription = null,
                                tint = RedPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = email,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = CoinGoldDark, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "${user?.coins ?: 0} Coins",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = CoinGoldDark
                                )
                            }
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(10.dp))

                // PRIMARY HIGHLIGHT ITEM: Mobile Reload
                DrawerMenuItem(
                    icon = Icons.Default.PhoneAndroid,
                    title = "📱 Mobile Reload (රිලෝඩ් ලබාගන්න)",
                    subtitle = "උපයාගත් කොයින් වලින් Dialog, Mobitel, Airtel, Hutch රිලෝඩ්",
                    badge = if (user?.eligibleReloadCoins ?: 0 > 0 || isPrimaryAdmin) "Available" else null,
                    badgeColor = SuccessGreen,
                    onClick = {
                        onDismiss()
                        onOpenReload()
                    }
                )

                // REFERRAL & APK DOWNLOAD
                DrawerMenuItem(
                    icon = Icons.Default.CardGiftcard,
                    title = "🎁 Referral (මිතුරන්ට ආරාධනා කර කාසි ලබන්න)",
                    subtitle = "Android Debug APK Direct Download & Referral link",
                    badge = "+Coins",
                    badgeColor = CoinGoldDark,
                    testTag = "drawer_item_referral",
                    onClick = {
                        onDismiss()
                        onOpenReferral()
                    }
                )

                // PROMO EVENTS & TASKS
                DrawerMenuItem(
                    icon = Icons.Default.EmojiEvents,
                    title = "🏆 Tasks & Promo Events (ප්‍රවර්ධන ඉලක්ක)",
                    subtitle = "නියමිත කාලය තුළ ඉලක්ක සම්පූර්ණ කර කාසි ලබාගන්න",
                    badge = "Hot",
                    badgeColor = RedPrimary,
                    testTag = "drawer_item_promo_tasks",
                    onClick = {
                        onDismiss()
                        onOpenPromoTasks()
                    }
                )

                DrawerMenuItem(
                    icon = Icons.Default.Person,
                    title = "👤 Profile & Dashboard",
                    subtitle = "View user stats & account details",
                    onClick = {
                        onDismiss()
                        onOpenProfile()
                    }
                )

                DrawerMenuItem(
                    icon = Icons.Default.History,
                    title = "📜 Activity History",
                    subtitle = "Watch history & transactions",
                    onClick = {
                        onDismiss()
                        onOpenHistory()
                    }
                )


                // Help & Support Chat (Direct contact with Admin)
                DrawerMenuItem(
                    icon = Icons.Default.SupportAgent,
                    title = "🎧 Help (උදව් සහ ගැටලු)",
                    subtitle = "Chat directly with Admin & upload screenshots",
                    badge = if (isPrimaryAdmin) "Admin Desk" else null,
                    badgeColor = RedPrimary,
                    testTag = "drawer_item_help",
                    onClick = {
                        onDismiss()
                        onOpenHelp()
                    }
                )

                // Admin Special Items
                if (isPrimaryAdmin) {
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "ADMIN CONTROLS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = RedPrimary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    DrawerMenuItem(
                        icon = Icons.Default.PhoneAndroid,
                        title = "📱 Admin: Reload Requests",
                        subtitle = "Approve or reject pending reload orders",
                        badge = if (pendingReloadCount > 0) "$pendingReloadCount Pending" else null,
                        badgeColor = RedPrimary,
                        onClick = {
                            onDismiss()
                            onOpenAdminReloadManagement()
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.People,
                        title = "👥 Admin: Manage Users & Coins",
                        subtitle = "Edit user coins, ban / unban users",
                        onClick = {
                            onDismiss()
                            onOpenAdminManageUsers()
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.MonetizationOn,
                        title = "⚙️ Admin: Rewards & Costs",
                        subtitle = "Configure coin economy & ad limits",
                        onClick = {
                            onDismiss()
                            onOpenAdminEconomy()
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.AdminPanelSettings,
                        title = "📢 Admin: App Update Config",
                        subtitle = "Announce update, video & direct APK",
                        onClick = {
                            onDismiss()
                            onOpenAdminUpdateSettings()
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.Tune,
                        title = "🎯 Admin: Promo Events & Tasks",
                        subtitle = "ප්‍රවර්ධන කාලය, Tasks 5 සහ Referral Coins පාලනය",
                        badge = "Control",
                        badgeColor = RedPrimary,
                        onClick = {
                            onDismiss()
                            onOpenAdminPromoTasks()
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(6.dp))

                // Logout
                DrawerMenuItem(
                    icon = Icons.Default.Logout,
                    title = "Logout",
                    subtitle = "Sign out from this device",
                    iconTint = RedPrimary,
                    onClick = {
                        onDismiss()
                        onLogout()
                    }
                )
            }
        }
    }
}

@Composable
private fun DrawerMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    badge: String? = null,
    badgeColor: Color = SuccessGreen,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    testTag: String? = null,
    onClick: () -> Unit
) {
    val rowModifier = Modifier
        .fillMaxWidth()
        .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
        .clickable(onClick = onClick)
        .padding(vertical = 8.dp, horizontal = 4.dp)

    Row(
        modifier = rowModifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(iconTint.copy(alpha = 0.12f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (badge != null) {
            Box(
                modifier = Modifier
                    .background(badgeColor, RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = badge,
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
