package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AdminEconomyConfig
import com.example.ui.theme.CoinGold
import com.example.ui.theme.RedPrimary

@Composable
fun AdminEconomySettingsDialog(
    currentConfig: AdminEconomyConfig,
    onDismiss: () -> Unit,
    onSave: (AdminEconomyConfig) -> Unit
) {
    var rewardSub by remember { mutableStateOf(currentConfig.rewardPerSubscribe.toString()) }
    var rewardLike by remember { mutableStateOf(currentConfig.rewardPerLike.toString()) }
    var rewardComment by remember { mutableStateOf(currentConfig.rewardPerComment.toString()) }
    var rewardWatchMin by remember { mutableStateOf(currentConfig.rewardPerWatchMinute.toString()) }

    var costSub by remember { mutableStateOf(currentConfig.costPerSubscribe.toString()) }
    var costLike by remember { mutableStateOf(currentConfig.costPerLike.toString()) }
    var costWatchMin by remember { mutableStateOf(currentConfig.costPerWatchMinute.toString()) }

    var rewardAd by remember { mutableStateOf(currentConfig.rewardPerAd.toString()) }
    var maxDailyAds by remember { mutableStateOf(currentConfig.maxDailyAds.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("admin_economy_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(CoinGold.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = CoinGold,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Economy & Coin Settings",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Set reward payouts & campaign costs",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // SECTION 1: USER REWARD PAYOUTS (When user subscribes, likes, comments, watches)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Savings,
                        contentDescription = null,
                        tint = RedPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "User Rewards (Coins Payout)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = RedPrimary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                EconomyInputField(
                    label = "Subscribe Reward (Coins)",
                    value = rewardSub,
                    onValueChange = { rewardSub = it.filter { c -> c.isDigit() } },
                    helperText = "Awarded when user subscribes to channel"
                )

                Spacer(modifier = Modifier.height(8.dp))

                EconomyInputField(
                    label = "Like Reward (Coins)",
                    value = rewardLike,
                    onValueChange = { rewardLike = it.filter { c -> c.isDigit() } },
                    helperText = "Awarded when user likes video"
                )

                Spacer(modifier = Modifier.height(8.dp))

                EconomyInputField(
                    label = "Comment Reward (Coins)",
                    value = rewardComment,
                    onValueChange = { rewardComment = it.filter { c -> c.isDigit() } },
                    helperText = "Awarded when user comments on video"
                )

                Spacer(modifier = Modifier.height(8.dp))

                EconomyInputField(
                    label = "Watch Time Reward (Coins / Minute)",
                    value = rewardWatchMin,
                    onValueChange = { rewardWatchMin = it.filter { c -> c.isDigit() } },
                    helperText = "Awarded per full minute of video watched"
                )

                Spacer(modifier = Modifier.height(20.dp))

                // SECTION 2: CAMPAIGN COSTS (Deducted when creator creates campaign)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Campaign Costs (Coins Deducted)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                EconomyInputField(
                    label = "Cost Per Subscriber Campaign (Coins)",
                    value = costSub,
                    onValueChange = { costSub = it.filter { c -> c.isDigit() } },
                    helperText = "Deducted per target subscriber requested"
                )

                Spacer(modifier = Modifier.height(8.dp))

                EconomyInputField(
                    label = "Cost Per Like Campaign (Coins)",
                    value = costLike,
                    onValueChange = { costLike = it.filter { c -> c.isDigit() } },
                    helperText = "Deducted per target like requested"
                )

                Spacer(modifier = Modifier.height(8.dp))

                EconomyInputField(
                    label = "Cost Per Watch Minute Campaign (Coins)",
                    value = costWatchMin,
                    onValueChange = { costWatchMin = it.filter { c -> c.isDigit() } },
                    helperText = "Deducted per target view minute requested"
                )

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(16.dp))

                // Rewarded Ads Section (Admin controlled payout & limits)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(RedPrimary.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = RedPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Rewarded Ads Settings (AdMob)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                EconomyInputField(
                    label = "Coins Paid Per Ad Watched",
                    value = rewardAd,
                    onValueChange = { rewardAd = it.filter { c -> c.isDigit() } },
                    helperText = "Reward coins credited to user per real AdMob ad"
                )

                Spacer(modifier = Modifier.height(8.dp))

                EconomyInputField(
                    label = "Daily Ad Limit (Max ads per day)",
                    value = maxDailyAds,
                    onValueChange = { maxDailyAds = it.filter { c -> c.isDigit() } },
                    helperText = "Default 20 ads per day to prevent ad spam"
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    androidx.compose.material3.OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            val newConfig = AdminEconomyConfig(
                                rewardPerSubscribe = rewardSub.toIntOrNull() ?: currentConfig.rewardPerSubscribe,
                                rewardPerLike = rewardLike.toIntOrNull() ?: currentConfig.rewardPerLike,
                                rewardPerComment = rewardComment.toIntOrNull() ?: currentConfig.rewardPerComment,
                                rewardPerWatchMinute = rewardWatchMin.toIntOrNull() ?: currentConfig.rewardPerWatchMinute,
                                costPerSubscribe = costSub.toIntOrNull() ?: currentConfig.costPerSubscribe,
                                costPerLike = costLike.toIntOrNull() ?: currentConfig.costPerLike,
                                costPerWatchMinute = costWatchMin.toIntOrNull() ?: currentConfig.costPerWatchMinute,
                                rewardPerAd = rewardAd.toIntOrNull() ?: currentConfig.rewardPerAd,
                                maxDailyAds = maxDailyAds.toIntOrNull() ?: currentConfig.maxDailyAds
                            )
                            onSave(newConfig)
                            onDismiss()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_economy_settings_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RedPrimary)
                    ) {
                        Text("Save Economy", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun EconomyInputField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    helperText: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label, fontSize = 12.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = RedPrimary,
                focusedLabelColor = RedPrimary
            )
        )
        Text(
            text = helperText,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, top = 2.dp)
        )
    }
}
