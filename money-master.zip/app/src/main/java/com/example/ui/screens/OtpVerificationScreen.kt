package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay

private val BackgroundBlack = Color(0xFF000000)
private val RedAccent = Color(0xFFFF5252)
private val Red700 = Color(0xFFD32F2F)
private val TextWhite70 = Color(0xB3FFFFFF)
private val TextGrey = Color(0xFF9E9E9E)
private val GreenVerified = Color(0xFF4CAF50)

@Composable
fun OtpVerificationScreen(
    email: String,
    latestDispatchedOtp: String? = null,
    isVerifying: Boolean,
    errorMessage: String?,
    onVerifyOtp: (enteredOtp: String) -> Unit = {},
    onResendOtp: () -> Unit,
    onCancel: () -> Unit,
    onSendVerificationLink: () -> Unit = {},
    onCheckLinkVerified: () -> Unit = {},
    onCheckLinkVerifiedSilent: () -> Unit = onCheckLinkVerified,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val lifecycleOwner = LocalLifecycleOwner.current
    var resendCountdown by remember { mutableIntStateOf(60) }

    // Pulse animation for waiting indicator
    val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Scale"
    )

    // Resend countdown timer
    LaunchedEffect(Unit) {
        while (true) {
            if (resendCountdown > 0) {
                delay(1000L)
                resendCountdown -= 1
            } else {
                delay(500L)
            }
        }
    }

    // 1. Auto-Check on App Resume (When user returns from Gmail app after clicking verify link)
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                onCheckLinkVerifiedSilent()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // 2. Periodic background verification check every 3 seconds
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000L)
            onCheckLinkVerifiedSilent()
        }
    }

    androidx.activity.compose.BackHandler {
        onCancel()
    }

    Scaffold(
        containerColor = BackgroundBlack,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Top Navigation bar with Back action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onCancel,
                        modifier = Modifier.testTag("otp_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Login",
                            tint = Color.White
                        )
                    }
                    Text(
                        text = "Security Verification",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Security Shield Icon with Glowing Aura
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(88.dp)
                        .scale(pulseScale)
                        .background(
                            brush = Brush.radialGradient(listOf(RedAccent.copy(alpha = 0.35f), Color.Transparent)),
                            shape = CircleShape
                        )
                        .border(2.dp, RedAccent, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.MarkEmailRead,
                        contentDescription = "Verify Email",
                        tint = RedAccent,
                        modifier = Modifier.size(46.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Verify Your Email",
                    style = androidx.compose.ui.text.TextStyle(
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("otp_title")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "A verification link has been sent to:",
                    color = TextGrey,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Recipient Email Card
                Surface(
                    color = Color(0xFF1C1C1E),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = null,
                            tint = RedAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = email,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Real Verification Link Instructions Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF142416)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GreenVerified.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("live_email_sent_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = GreenVerified,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Verification Link Sent to Gmail",
                                color = GreenVerified,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "අදාල Gmail එකට Verification Link එකක් යවා ඇත. කරුණාකර ඔබගේ Gmail ඇප් එක විවෘත කර එම ලින්ක් එක click කරන්න. ලින්ක් එක click කළ සැනින් නැවත මෙම ඇප් එක open කරද්දී ඔබව ස්වයංක්‍රීයව ඇප් එක ඇතුලට රැගෙන යනු ඇත.",
                            color = Color.White,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "💡 Tip: Primary inbox හි නොමැති නම් Spam හෝ Promotions folder එකද පරීක්ෂා කරන්න.",
                            color = TextGrey,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Open Gmail Button
                        Button(
                            onClick = {
                                try {
                                    val emailIntent = Intent(Intent.ACTION_MAIN).apply {
                                        addCategory(Intent.CATEGORY_APP_EMAIL)
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    context.startActivity(Intent.createChooser(emailIntent, "Open Gmail"))
                                } catch (_: Exception) {
                                    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://mail.google.com/")).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    context.startActivity(webIntent)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GreenVerified,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("open_gmail_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Open Gmail App (Gmail විවෘත කරන්න)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Check Verified Button (btnCheckVerified)
                        Button(
                            onClick = onCheckLinkVerified,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF1E1E22),
                                contentColor = Color.White
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GreenVerified),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btnCheckVerified")
                        ) {
                            if (isVerifying) {
                                CircularProgressIndicator(
                                    color = GreenVerified,
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Checking verification...",
                                    fontSize = 12.sp,
                                    color = GreenVerified,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = null,
                                    tint = GreenVerified,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Check Verified (ලින්ක් එක click කළ පසු තහවුරු කරන්න)",
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Auto detection animated status indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                ) {
                    CircularProgressIndicator(
                        color = RedAccent,
                        modifier = Modifier.size(14.dp),
                        strokeWidth = 1.8.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Auto-detecting: ඇප් එක නැවත open කරද්දී ස්වයංක්‍රීයව ලොග් වේ...",
                        color = Color(0xFFFFB4B4),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Error message display if any
                if (!errorMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF261010)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, RedAccent),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = errorMessage,
                            color = RedAccent,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Resend Link Button (btnSendVerifyLink)
                if (resendCountdown > 0) {
                    Text(
                        text = "Resend link in ${resendCountdown}s",
                        color = TextGrey,
                        fontSize = 13.sp
                    )
                } else {
                    Button(
                        onClick = {
                            resendCountdown = 60
                            onSendVerificationLink()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF242426),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(42.dp)
                            .testTag("btnSendVerifyLink")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = RedAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Resend Verification Link",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Bottom Back Action
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                TextButton(
                    onClick = onCancel,
                    colors = ButtonDefaults.textButtonColors(contentColor = TextGrey),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "← වෙනත් ඊමේල් එකකින් ඇතුළු වන්න (Back to Sign In)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
