package com.example.ui.screens

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.firebase.FirebaseService
import com.example.ui.theme.RedPrimary

private val BackgroundBlack = Color(0xFF000000)
private val RedAccent = Color(0xFFFF5252)
private val Red700 = Color(0xFFD32F2F)
private val TextGrey = Color(0xFF9E9E9E)

@Composable
fun LoginScreen(
    isAuthenticating: Boolean,
    onLoginWithGoogle: (context: Context, email: String?) -> Unit,
    onDirectSignIn: (context: Context, email: String) -> Unit = { ctx, email -> onLoginWithGoogle(ctx, email) },
    onResetFreshState: (context: Context) -> Unit = {},
    bannedNotice: String? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Native Google Sign-In Plugin Launcher
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val capturedEmail = FirebaseService.extractEmailFromGoogleResult(result.data, context)
            ?: FirebaseService.parseGoogleSignInResult(result.data)?.email
            ?: FirebaseService.getLastSignedInAccount(context)?.email

        if (!capturedEmail.isNullOrBlank()) {
            onLoginWithGoogle(context, capturedEmail.trim().lowercase())
        }
    }

    Scaffold(
        containerColor = BackgroundBlack,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // App Icon / Logo Box
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .background(
                        brush = Brush.radialGradient(
                            listOf(RedAccent.copy(alpha = 0.35f), Color.Transparent)
                        ),
                        shape = CircleShape
                    )
                    .border(2.dp, RedAccent, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.VideoLibrary,
                    contentDescription = "Logo",
                    tint = RedAccent,
                    modifier = Modifier.size(42.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Title: SubExchange
            Text(
                text = "SubExchange",
                style = androidx.compose.ui.text.TextStyle(
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("login_title")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Get Real Subscribers, Views & Likes for your YouTube Channel",
                textAlign = TextAlign.Center,
                style = androidx.compose.ui.text.TextStyle(
                    color = TextGrey,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                ),
                modifier = Modifier.fillMaxWidth(0.9f)
            )

            if (!bannedNotice.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(18.dp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF330A0A)),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, RedPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("login_banned_notice")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = RedPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ගිණුම තහනම් කර ඇත (Account Banned)",
                                color = RedPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "හේතුව (Reason): $bannedNotice",
                            color = Color(0xFFFF8080),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Main Google Sign-In Card (Clean: only standard Sign in with Google button)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C2C)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Sign in to continue",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Connect with your Google account to sync coins and campaigns securely.",
                        color = TextGrey,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Single, Clean Official Google Sign-In Button triggering native Google Sign-in Sheet
                    Button(
                        onClick = {
                            if (!isAuthenticating) {
                                try {
                                    val client = FirebaseService.getGoogleSignInClient(context)
                                    googleSignInLauncher.launch(client.signInIntent)
                                } catch (e: Exception) {
                                    // Fallback to system Google account picker
                                    try {
                                        val chooseIntent = android.accounts.AccountManager.newChooseAccountIntent(
                                            null, null, arrayOf("com.google"), null, null, null, null
                                        )
                                        googleSignInLauncher.launch(chooseIntent)
                                    } catch (_: Exception) {
                                        val lastAccount = FirebaseService.getLastSignedInAccount(context)
                                        if (lastAccount != null && lastAccount.email.isNotBlank()) {
                                            onLoginWithGoogle(context, lastAccount.email.trim().lowercase())
                                        } else {
                                            onLoginWithGoogle(context, null)
                                        }
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("google_sign_in_button")
                    ) {
                        if (isAuthenticating) {
                            CircularProgressIndicator(
                                color = Color.Black,
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Signing In...",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccountCircle,
                                    contentDescription = null,
                                    tint = Red700,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Sign in with Google",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Safety Highlights
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FeatureItemRow(
                    icon = Icons.Default.Security,
                    text = "Official Google Identity & Firebase Authentication"
                )
                FeatureItemRow(
                    icon = Icons.Default.Subscriptions,
                    text = "Real YouTube engagement: Subscriptions, Likes & Comments"
                )
                FeatureItemRow(
                    icon = Icons.Default.CheckCircle,
                    text = "Strict Anti-cheat & Sub-loss prevention guarantee"
                )
            }
        }
    }
}

@Composable
private fun FeatureItemRow(icon: ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .background(Color(0xFF1E1E1E), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = RedAccent,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = text,
            color = Color(0xFFB0B0B0),
            fontSize = 13.sp
        )
    }
}
