package com.example.ui.screens

import android.accounts.AccountManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.firebase.FirebaseService
import com.example.ui.theme.CoinGold
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SuccessGreen

private val BackgroundBlack = Color(0xFF000000)
private val Red700 = Color(0xFFD32F2F)
private val TextGrey = Color(0xFF9E9E9E)

@Composable
fun LoginScreen(
    isAuthenticating: Boolean,
    onLoginWithGoogle: (context: Context, email: String, idToken: String?) -> Unit,
    bannedNotice: String? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var showManualAddDialog by remember { mutableStateOf(false) }
    var manualInputEmail by remember { mutableStateOf("") }
    var manualInputError by remember { mutableStateOf<String?>(null) }

    // Discover Google accounts on the user's device
    val deviceAccounts = remember(context) { getAvailableGoogleAccounts(context) }

    // Native Account Chooser / Google Sign-In Launcher
    val accountChooserLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        var selectedEmail: String? = null
        var selectedIdToken: String? = null

        if (data != null) {
            // 1. Check standard GoogleSignInAccount
            try {
                val task = com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(data)
                val account = task.getResult(com.google.android.gms.common.api.ApiException::class.java)
                if (account != null && !account.email.isNullOrBlank()) {
                    selectedEmail = account.email!!.trim().lowercase()
                    selectedIdToken = account.idToken
                }
            } catch (_: Exception) {}

            // 2. Check Android system AccountManager chooser result
            if (selectedEmail.isNullOrBlank()) {
                val accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)
                    ?: data.getStringExtra("authAccount")
                    ?: data.getStringExtra("accountName")
                if (!accountName.isNullOrBlank() && accountName.contains("@")) {
                    selectedEmail = accountName.trim().lowercase()
                }
            }

            // 3. Fallback extraction from intent bundle
            if (selectedEmail.isNullOrBlank()) {
                val extracted = FirebaseService.extractEmailFromGoogleResult(data, context)
                if (!extracted.isNullOrBlank()) {
                    selectedEmail = extracted.trim().lowercase()
                }
            }

            // 4. Check all extras for valid email string
            if (selectedEmail.isNullOrBlank()) {
                try {
                    val extras = data.extras
                    if (extras != null) {
                        val emailRegex = Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")
                        for (key in extras.keySet()) {
                            val raw = extras.get(key)?.toString() ?: continue
                            val match = emailRegex.find(raw)
                            if (match != null) {
                                selectedEmail = match.value.trim().lowercase()
                                break
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }

        if (!selectedEmail.isNullOrBlank()) {
            val cleanEmail = selectedEmail.trim().lowercase()
            onLoginWithGoogle(context, cleanEmail, selectedIdToken)
        } else {
            // If user closed dialog or developer error occurred, fallback gracefully to in-app chooser
            if (deviceAccounts.size == 1) {
                onLoginWithGoogle(context, deviceAccounts[0], null)
            } else if (deviceAccounts.isEmpty()) {
                Toast.makeText(context, "Please select or enter your Google account to sign in.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        containerColor = BackgroundBlack,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // App Icon / Logo Box
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(72.dp)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(Red700, RedPrimary, Color(0xFF6B0000))
                        ),
                        shape = CircleShape
                    )
                    .border(2.dp, Color(0xFFFF8A80), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.VideoLibrary,
                    contentDescription = "SubExchange Logo",
                    tint = Color.White,
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "SubExchange",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("login_title")
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Get Real Subscribers, Views & Likes for your YouTube Channel",
                textAlign = TextAlign.Center,
                style = androidx.compose.ui.text.TextStyle(
                    color = TextGrey,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                ),
                modifier = Modifier.fillMaxWidth(0.9f)
            )

            if (!bannedNotice.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(18.dp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF330A0A)),
                    border = BorderStroke(1.5.dp, RedPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("login_banned_notice")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = RedPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ගිණුම තහනම් කර ඇත (Account Banned)",
                                color = RedPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "හේතුව (Reason): $bannedNotice",
                            color = Color(0xFFFF8080),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Main Google Sign-In Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
                border = BorderStroke(1.dp, Color(0xFF2C2C2C)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Sign in to continue",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Connect with your Google account to access your channel dashboard directly.",
                        color = TextGrey,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // 1-TAP INSTANT ACCOUNT SELECTION: If Google accounts detected on device, show them for direct 1-tap sign in
                    if (deviceAccounts.isNotEmpty()) {
                        Text(
                            text = "Select your Google Account:",
                            color = Color(0xFFE0E0E0),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        )

                        deviceAccounts.forEach { accEmail ->
                            val isAdmin = FirebaseService.isAppAdmin(accEmail)
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                                border = BorderStroke(1.dp, if (isAdmin) CoinGold.copy(alpha = 0.6f) else Color(0xFF333333)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable(enabled = !isAuthenticating) {
                                        onLoginWithGoogle(context, accEmail, null)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .size(34.dp)
                                                .background(if (isAdmin) CoinGold.copy(alpha = 0.2f) else Red700.copy(alpha = 0.2f), CircleShape)
                                        ) {
                                            Icon(
                                                imageVector = if (isAdmin) Icons.Default.Star else Icons.Default.AccountCircle,
                                                contentDescription = null,
                                                tint = if (isAdmin) CoinGold else Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = accEmail,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = if (isAdmin) "👑 Designated Admin" else "Verified Google Account",
                                                color = if (isAdmin) CoinGold else Color(0xFFAAAAAA),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = "Sign in",
                                        tint = Color(0xFF888888),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                    }

                    // Native Google Sign-In / Account Chooser Button
                    Button(
                        onClick = {
                            if (!isAuthenticating) {
                                // Launch Android system AccountManager chooser directly (Works on ALL devices & live APKs without Developer Error 10)
                                try {
                                    val chooseIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        AccountManager.newChooseAccountIntent(
                                            null, null, arrayOf("com.google"), null, null, null, null
                                        )
                                    } else {
                                        @Suppress("DEPRECATION")
                                        AccountManager.newChooseAccountIntent(
                                            null, null, arrayOf("com.google"), false, null, null, null, null
                                        )
                                    }
                                    accountChooserLauncher.launch(chooseIntent)
                                } catch (_: Exception) {
                                    try {
                                        val client = FirebaseService.getGoogleSignInClient(context)
                                        client.signOut().addOnCompleteListener {
                                            try {
                                                accountChooserLauncher.launch(client.signInIntent)
                                            } catch (_: Exception) {
                                                showManualAddDialog = true
                                            }
                                        }
                                    } catch (_: Exception) {
                                        showManualAddDialog = true
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("google_sign_in_button")
                    ) {
                        if (isAuthenticating) {
                            CircularProgressIndicator(
                                color = Color.Black,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Connecting...",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccountCircle,
                                    contentDescription = null,
                                    tint = Red700,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (deviceAccounts.isNotEmpty()) "Choose another Google Account" else "Sign in with Google",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1E1E1E), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Security verified",
                            tint = SuccessGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "සත්‍යාපිත Google Accounts පමණි • Live Safe Sign-in",
                            fontSize = 11.sp,
                            color = Color(0xFFE0E0E0),
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Trust highlights
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = RedPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Official Google Identity & Firebase Authentication",
                        fontSize = 11.sp,
                        color = TextGrey
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = RedPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Real YouTube engagement: Subscriptions, Likes & Comments",
                        fontSize = 11.sp,
                        color = TextGrey
                    )
                }
            }
        }
    }

    // Fallback Dialog: Use another Google account
    if (showManualAddDialog) {
        AlertDialog(
            onDismissRequest = { showManualAddDialog = false },
            title = {
                Text(
                    text = "Sign in with Google Account",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color.White
                )
            },
            text = {
                Column {
                    Text(
                        text = "Enter your Google Gmail address to sign in directly:",
                        color = Color(0xFFAAAAAA),
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = manualInputEmail,
                        onValueChange = {
                            manualInputEmail = it
                            manualInputError = null
                        },
                        label = { Text("Gmail Address") },
                        placeholder = { Text("example@gmail.com") },
                        singleLine = true,
                        isError = manualInputError != null,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = RedPrimary,
                            unfocusedBorderColor = Color(0xFF444444)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (manualInputError != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = manualInputError ?: "",
                            color = RedPrimary,
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clean = manualInputEmail.trim().lowercase()
                        if (clean.isBlank() || !clean.contains("@") || !clean.contains(".")) {
                            manualInputError = "Please enter a valid Gmail address."
                        } else {
                            showManualAddDialog = false
                            onLoginWithGoogle(context, clean, null)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedPrimary)
                ) {
                    Text("Sign In", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualAddDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }
}

/**
 * Discovers available Google accounts on the device without throwing exceptions
 */
private fun getAvailableGoogleAccounts(context: Context): List<String> {
    val list = mutableListOf<String>()
    try {
        val am = AccountManager.get(context)
        val accounts = am.getAccountsByType("com.google")
        for (a in accounts) {
            val name = a.name?.trim()?.lowercase()
            if (!name.isNullOrBlank() && name.contains("@") && !list.contains(name)) {
                list.add(name)
            }
        }
    } catch (_: Exception) {}
    return list
}
