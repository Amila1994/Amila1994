package com.example.ui.screens

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BackgroundBlack = Color(0xFF000000)
private val RedAccent = Color(0xFFFF5252)
private val Red700 = Color(0xFFD32F2F)
private val TextWhite70 = Color(0xB3FFFFFF)
private val TextGrey = Color(0xFF9E9E9E)

@Composable
fun LoginScreen(
    isAuthenticating: Boolean,
    onLoginWithGoogle: (context: Context, email: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    var showManualEmailDialog by remember { mutableStateOf(false) }
    var enteredEmail by remember { mutableStateOf("") }

    // සම්මත GoogleSignIn Plugin ActivityResultLauncher
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val account = com.example.data.firebase.FirebaseService.parseGoogleSignInResult(result.data)
        if (account != null && account.email.isNotBlank()) {
            onLoginWithGoogle(context, account.email)
        } else {
            // Fallback: If device doesn't have Google Play account or canceled,
            // invoke fallback smoothly so that user is not blocked
            onLoginWithGoogle(context, null)
        }
    }

    Scaffold(
        containerColor = BackgroundBlack,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Spacer(modifier = Modifier.height(28.dp))

                // Title: 'SubExchange Login'
                Text(
                    text = "SubExchange Login",
                    style = androidx.compose.ui.text.TextStyle(
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("login_title")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Subtitle: 'Secure Access for Creators & Admin'
                Text(
                    text = "Secure Access for Creators & Admin",
                    style = androidx.compose.ui.text.TextStyle(
                        color = RedAccent,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("login_badge")
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Description
                Text(
                    text = "Login with your real Gmail account to start earning coins and safe promotions.",
                    textAlign = TextAlign.Center,
                    style = androidx.compose.ui.text.TextStyle(
                        color = TextGrey,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    ),
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .testTag("login_subtitle")
                )

                Spacer(modifier = Modifier.height(44.dp))

                // විශේෂාංග ලැයිස්තුව (Feature items)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    FeatureItemRow(
                        icon = Icons.Default.MonetizationOn,
                        text = "Earn Coins per minute watch & subscribe"
                    )
                    FeatureItemRow(
                        icon = Icons.Default.VideoLibrary,
                        text = "Create high-retention campaigns for your channel"
                    )
                    FeatureItemRow(
                        icon = Icons.Default.CardGiftcard,
                        text = "Watch daily bonus ads for fast extra coins"
                    )
                    FeatureItemRow(
                        icon = Icons.Default.Security,
                        text = "100% Anti-cheat verification & safe exchange"
                    )
                    FeatureItemRow(
                        icon = Icons.Default.CloudSync,
                        text = "Firebase Auth & Cloud Firestore Cloud Sync"
                    )
                }
            }

            // Bottom Section: Google Sign-In Action (No pre-set email)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp, bottom = 12.dp)
            ) {
                // සැබෑ Google Sign-In බොත්තම (GoogleSignIn plugin ක්‍රමය)
                Button(
                    onClick = {
                        focusManager.clearFocus()
                        try {
                            val client = com.example.data.firebase.FirebaseService.getGoogleSignInClient(context)
                            client.signOut()
                            googleSignInLauncher.launch(client.signInIntent)
                        } catch (e: Exception) {
                            // Direct fallback to ensure user is never blocked
                            onLoginWithGoogle(context, null)
                        }
                    },
                    enabled = !isAuthenticating,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Red700,
                        disabledContainerColor = Red700.copy(alpha = 0.6f)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("google_sign_in_button")
                ) {
                    if (isAuthenticating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Login,
                                contentDescription = "Login",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Sign in with Google",
                                style = androidx.compose.ui.text.TextStyle(
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Alternative option to enter Gmail if device doesn't have Google Play accounts registered
                TextButton(
                    onClick = { showManualEmailDialog = true },
                    modifier = Modifier.testTag("enter_email_manually_button")
                ) {
                    Text(
                        text = "Or enter Gmail address manually",
                        color = TextGrey,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Secure Google Authentication - Live Mode",
                    style = androidx.compose.ui.text.TextStyle(
                        color = Color.DarkGray,
                        fontSize = 11.sp
                    ),
                    textAlign = TextAlign.Center
                )
            }
        }

        // Dialog for entering real Gmail if Google Play Accounts pop-up is empty on emulator
        if (showManualEmailDialog) {
            AlertDialog(
                onDismissRequest = { showManualEmailDialog = false },
                containerColor = Color(0xFF1E1E1E),
                title = {
                    Text(
                        text = "Enter Your Gmail",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column {
                        Text(
                            text = "Enter your real Gmail address. A 6-digit verification code will be sent to verify your identity.",
                            color = TextWhite70,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        OutlinedTextField(
                            value = enteredEmail,
                            onValueChange = { enteredEmail = it },
                            placeholder = { Text("your.email@gmail.com", color = Color.Gray) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                            leadingIcon = {
                                Icon(Icons.Default.Email, contentDescription = null, tint = RedAccent)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = RedAccent,
                                unfocusedBorderColor = Color.DarkGray,
                                cursorColor = RedAccent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("manual_email_dialog_input")
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Quick Select:",
                            color = TextGrey,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = {
                                enteredEmail = com.example.data.firebase.FirebaseService.designatedAdminEmail
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF2C2C2C),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth().testTag("quick_select_admin_email_chip")
                        ) {
                            Text(
                                text = "amilalasantha940703@gmail.com",
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val emailToUse = enteredEmail.trim()
                            if (emailToUse.isNotBlank() && emailToUse.contains("@")) {
                                showManualEmailDialog = false
                                onLoginWithGoogle(context, emailToUse)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Red700)
                    ) {
                        Text("Continue & Get Code", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showManualEmailDialog = false }) {
                        Text("Cancel", color = TextGrey)
                    }
                }
            )
        }
    }
}

@Composable
private fun FeatureItemRow(
    icon: ImageVector,
    text: String,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = RedAccent,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = text,
            style = androidx.compose.ui.text.TextStyle(
                color = TextWhite70,
                fontSize = 13.sp
            ),
            modifier = Modifier.weight(1f)
        )
    }
}
