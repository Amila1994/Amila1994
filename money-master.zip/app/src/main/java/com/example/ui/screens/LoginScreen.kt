package com.example.ui.screens

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CoinGold

private val BackgroundBlack = Color(0xFF000000)
private val RedAccent = Color(0xFFFF5252)
private val Red700 = Color(0xFFD32F2F)
private val TextWhite70 = Color(0xB3FFFFFF)
private val TextGrey = Color(0xFF9E9E9E)

@Composable
fun LoginScreen(
    isAuthenticating: Boolean,
    onLoginWithGoogle: (context: Context, email: String?) -> Unit,
    onDirectSignIn: (context: Context, email: String) -> Unit = { ctx, email -> onLoginWithGoogle(ctx, email) },
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    var emailInput by remember { mutableStateOf("slamila1994@gmail.com") }

    // Standard GoogleSignIn Plugin Launcher
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val account = com.example.data.firebase.FirebaseService.parseGoogleSignInResult(result.data)
        if (account != null && account.email.isNotBlank()) {
            onDirectSignIn(context, account.email)
        } else {
            // If device doesn't have Google Play Account logged in, smoothly log in with entered email
            onDirectSignIn(context, emailInput.ifBlank { "slamila1994@gmail.com" })
        }
    }

    Scaffold(
        containerColor = BackgroundBlack,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // App Icon / Logo Box
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(68.dp)
                    .background(
                        brush = Brush.radialGradient(
                            listOf(RedAccent.copy(alpha = 0.35f), Color.Transparent)
                        ),
                        shape = CircleShape
                    )
                    .border(2.dp, RedAccent, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.VideoLibrary,
                    contentDescription = "Logo",
                    tint = RedAccent,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title: SubExchange Login
            Text(
                text = "SubExchange Login",
                style = androidx.compose.ui.text.TextStyle(
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("login_title")
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Subtitle
            Text(
                text = "Secure Access for Creators & Admin",
                style = androidx.compose.ui.text.TextStyle(
                    color = RedAccent,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("login_badge")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Login to your account to watch videos, earn coins, and promote your YouTube channel.",
                textAlign = TextAlign.Center,
                style = androidx.compose.ui.text.TextStyle(
                    color = TextGrey,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                ),
                modifier = Modifier.fillMaxWidth(0.95f)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Quick 1-Tap Account Cards
            Text(
                text = "ඉක්මන් ප්‍රවේශය / 1-Tap Fast Login:",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            )

            // Admin Fast Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1711)),
                border = androidx.compose.foundation.BorderStroke(1.dp, CoinGold.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(CoinGold.copy(alpha = 0.15f), CircleShape)
                            .border(1.dp, CoinGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("👑", fontSize = 20.sp)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Admin Account",
                                color = CoinGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(CoinGold.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("FULL ACCESS", color = CoinGold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Text(
                            text = "amilalasantha940703@gmail.com",
                            color = TextWhite70,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            emailInput = "amilalasantha940703@gmail.com"
                            onDirectSignIn(context, "amilalasantha940703@gmail.com")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Red700),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("admin_fast_login_button")
                    ) {
                        Text("Login 👑", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                    }
                }
            }

            // Normal Creator User Fast Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141923)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A3952)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 18.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color(0xFF2196F3).copy(alpha = 0.15f), CircleShape)
                            .border(1.dp, Color(0xFF2196F3), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("👤", fontSize = 20.sp)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Creator Account",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF4CAF50).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("+100 COINS", color = Color(0xFF81C784), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Text(
                            text = "slamila1994@gmail.com",
                            color = TextWhite70,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            emailInput = "slamila1994@gmail.com"
                            onDirectSignIn(context, "slamila1994@gmail.com")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("creator_fast_login_button")
                    ) {
                        Text("Login 👤", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                    }
                }
            }

            // Normal Sign-In Card (Custom Email)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161616)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C2C)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "Or Enter Any Gmail / වෙනත් ඊමේල් ලිපිනයක්",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Email Input Field
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        placeholder = { Text("your.email@gmail.com", color = Color.Gray) },
                        leadingIcon = {
                            Icon(Icons.Default.Email, contentDescription = null, tint = RedAccent)
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                focusManager.clearFocus()
                                val target = emailInput.trim().ifEmpty { "slamila1994@gmail.com" }
                                onDirectSignIn(context, target)
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = RedAccent,
                            unfocusedBorderColor = Color(0xFF444444),
                            cursorColor = RedAccent,
                            focusedContainerColor = Color(0xFF0F0F0F),
                            unfocusedContainerColor = Color(0xFF0F0F0F)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("email_input_field")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Primary Direct Sign-In Button (Instant & Never Stuck)
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            val target = emailInput.trim().ifEmpty { "slamila1994@gmail.com" }
                            onDirectSignIn(context, target)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Red700),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("direct_sign_in_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Login,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Sign In to App / සාමාන්‍ය පිවිසුම",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Secondary Google Sign-In button
                    OutlinedButton(
                        onClick = {
                            focusManager.clearFocus()
                            try {
                                val client = com.example.data.firebase.FirebaseService.getGoogleSignInClient(context)
                                client.signOut()
                                googleSignInLauncher.launch(client.signInIntent)
                            } catch (e: Exception) {
                                onDirectSignIn(context, emailInput.ifBlank { "slamila1994@gmail.com" })
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color.White
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF444444)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("google_sign_in_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = null,
                                tint = RedAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Sign in with Google Account",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Optional OTP verification code button
                    TextButton(
                        onClick = {
                            val target = emailInput.trim().ifEmpty { "slamila1994@gmail.com" }
                            onLoginWithGoogle(context, target)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("otp_code_mode_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = TextGrey,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Or send 6-Digit OTP code to Gmail",
                                color = TextGrey,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // App Highlights list
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FeatureItemRow(
                    icon = Icons.Default.MonetizationOn,
                    text = "Start with 100 starter coins & earn per watch/subscribe"
                )
                FeatureItemRow(
                    icon = Icons.Default.VideoLibrary,
                    text = "Promote YouTube videos & grow real subscribers"
                )
                FeatureItemRow(
                    icon = Icons.Default.CardGiftcard,
                    text = "Daily bonus rewarded ads for fast extra coins"
                )
                FeatureItemRow(
                    icon = Icons.Default.Security,
                    text = "Firebase Auth & Firestore live cloud synchronization"
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun FeatureItemRow(
    icon: ImageVector,
    text: String,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = RedAccent,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = text,
            style = androidx.compose.ui.text.TextStyle(
                color = TextWhite70,
                fontSize = 12.sp
            ),
            modifier = Modifier.weight(1f)
        )
    }
}
