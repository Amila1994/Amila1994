package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = RedPrimary,
    onPrimary = Color.White,
    primaryContainer = RedDark,
    onPrimaryContainer = RedLight,
    secondary = CoinGold,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF423400),
    onSecondaryContainer = CoinGoldLight,
    tertiary = RedAccent,
    background = DarkBackground,
    onBackground = Color(0xFFEEEEEE),
    surface = DarkSurfaceElevated,
    onSurface = Color(0xFFF0F0F0),
    surfaceVariant = DarkSurfaceCard,
    onSurfaceVariant = Color(0xFFCCCCCC)
)

private val LightColorScheme = lightColorScheme(
    primary = RedPrimary,
    onPrimary = Color.White,
    primaryContainer = RedLight,
    onPrimaryContainer = RedDark,
    secondary = CoinGoldDark,
    onSecondary = Color.White,
    secondaryContainer = CoinGoldLight,
    onSecondaryContainer = Color(0xFF553B00),
    tertiary = RedAccent,
    background = LightBackground,
    onBackground = Color(0xFF1E1E1E),
    surface = LightSurface,
    onSurface = Color(0xFF1A1A1A),
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = Color(0xFF444444)
)

@Composable
fun SubExchangeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep branded red/gold aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
