package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RedPrimary = Color(0xFFE53935)
val RedDark = Color(0xFFC62828)
val RedLight = Color(0xFFFFEBEE)
val RedAccent = Color(0xFFFF5252)

val CoinGold = Color(0xFFFFB300)
val CoinGoldLight = Color(0xFFFFF8E1)
val CoinGoldDark = Color(0xFFFFA000)

val DarkSurface = Color(0xFF121212)
val DarkSurfaceElevated = Color(0xFF1E1E1E)
val DarkSurfaceCard = Color(0xFF252525)
val DarkBackground = Color(0xFF0D0D0D)

val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F3F4)

val SuccessGreen = Color(0xFF43A047)
val InfoBlue = Color(0xFF1E88E5)
val WarningOrange = Color(0xFFFB8C00)
