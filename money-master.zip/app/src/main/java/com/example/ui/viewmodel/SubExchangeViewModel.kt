package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SubExchangeDatabase
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WatchHistoryEntity
import com.example.data.repository.SubExchangeRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SubExchangeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SubExchangeDatabase.getDatabase(application)
    private val repository = SubExchangeRepository(db.userDao(), db.campaignDao(), db.watchHistoryDao())
    private val authPrefs = application.getSharedPreferences("subexchange_auth_prefs", android.content.Context.MODE_PRIVATE)

    private val _currentUserEmail = MutableStateFlow("amila940703@gmail.com")
    val currentUserEmail: StateFlow<String> = _currentUserEmail.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    private val _pendingOtpEmail = MutableStateFlow<String?>(null)
    val pendingOtpEmail: StateFlow<String?> = _pendingOtpEmail.asStateFlow()

    private val _latestDispatchedOtp = MutableStateFlow<String?>(null)
    val latestDispatchedOtp: StateFlow<String?> = _latestDispatchedOtp.asStateFlow()

    private val _isVerifyingOtp = MutableStateFlow(false)
    val isVerifyingOtp: StateFlow<Boolean> = _isVerifyingOtp.asStateFlow()

    private val _otpErrorMessage = MutableStateFlow<String?>(null)
    val otpErrorMessage: StateFlow<String?> = _otpErrorMessage.asStateFlow()

    val currentUser: StateFlow<UserEntity?> = _currentUserEmail.flatMapLatest { email ->
        repository.getUser(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeCampaigns: StateFlow<List<CampaignEntity>> =
        repository.getActiveCampaigns().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userCampaigns: StateFlow<List<CampaignEntity>> = _currentUserEmail.flatMapLatest { email ->
        repository.getCampaignsByCreator(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCampaigns: StateFlow<List<CampaignEntity>> =
        repository.getAllCampaigns().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<UserEntity>> =
        repository.getAllUsers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchHistory: StateFlow<List<WatchHistoryEntity>> = _currentUserEmail.flatMapLatest { email ->
        repository.getWatchHistory(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Video Player & Timer State
    private val _selectedCampaign = MutableStateFlow<CampaignEntity?>(null)
    val selectedCampaign: StateFlow<CampaignEntity?> = _selectedCampaign.asStateFlow()

    private val _isWatching = MutableStateFlow(false)
    val isWatching: StateFlow<Boolean> = _isWatching.asStateFlow()

    private val _remainingSeconds = MutableStateFlow(300)
    val remainingSeconds: StateFlow<Int> = _remainingSeconds.asStateFlow()

    private val _totalWatchSeconds = MutableStateFlow(300)
    val totalWatchSeconds: StateFlow<Int> = _totalWatchSeconds.asStateFlow()

    private val _isSubscribed = MutableStateFlow(false)
    val isSubscribed: StateFlow<Boolean> = _isSubscribed.asStateFlow()

    private val _isLiked = MutableStateFlow(false)
    val isLiked: StateFlow<Boolean> = _isLiked.asStateFlow()

    private val _isVerifyingYouTube = MutableStateFlow(false)
    val isVerifyingYouTube: StateFlow<Boolean> = _isVerifyingYouTube.asStateFlow()

    private val _youTubeVerificationStatus = MutableStateFlow<String?>(null)
    val youTubeVerificationStatus: StateFlow<String?> = _youTubeVerificationStatus.asStateFlow()

    private val _fastMode = MutableStateFlow(false)
    val fastMode: StateFlow<Boolean> = _fastMode.asStateFlow()

    // Ad state
    private val _isWatchingAd = MutableStateFlow(false)
    val isWatchingAd: StateFlow<Boolean> = _isWatchingAd.asStateFlow()

    private val _adCountdown = MutableStateFlow(5)
    val adCountdown: StateFlow<Int> = _adCountdown.asStateFlow()

    // Dialogs & Feedback
    private val _rewardCelebration = MutableStateFlow<Pair<String, Int>?>(null)
    val rewardCelebration: StateFlow<Pair<String, Int>?> = _rewardCelebration.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private var timerJob: Job? = null
    private var adJob: Job? = null

    init {
        // Feature 1: Restore persistent login session so user is never prompted for OTP on regular app launches
        val savedEmail = authPrefs.getString("saved_user_email", null)
        val wasLoggedIn = authPrefs.getBoolean("is_user_logged_in", false)
        if (wasLoggedIn && !savedEmail.isNullOrBlank()) {
            _currentUserEmail.value = savedEmail
            _isLoggedIn.value = true
        }

        viewModelScope.launch {
            repository.seedSampleDataIfEmpty()
            repository.ensureUserExists(_currentUserEmail.value)
        }

        // Auto select first Admin priority campaign
        viewModelScope.launch {
            repository.getActiveCampaigns().collect { list ->
                if (_selectedCampaign.value == null && list.isNotEmpty()) {
                    val priority = list.firstOrNull { it.isAdminPriority || it.isGlobal } ?: list.first()
                    selectCampaign(priority)
                }
            }
        }
    }

    fun loginWithGoogle(
        context: android.content.Context? = null,
        email: String,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            try {
                val authResult = if (context != null) {
                    com.example.data.firebase.FirebaseService.signInWithGoogle(context, email)
                } else {
                    com.example.data.firebase.FirebaseService.signInWithGoogleFallback(email)
                }

                if (authResult.success) {
                    val targetEmail = authResult.email.trim().ifEmpty { com.example.data.firebase.FirebaseService.designatedAdminEmail }
                    _currentUserEmail.value = targetEmail
                    val user = repository.ensureUserExists(targetEmail)
                    _isLoggedIn.value = true
                    authPrefs.edit().putString("saved_user_email", targetEmail).putBoolean("is_user_logged_in", true).apply()
                    val isAdmin = user.isAdmin || authResult.isAdmin
                    _statusMessage.value = if (isAdmin) {
                        "Admin access granted: $targetEmail"
                    } else if (authResult.isNewUser) {
                        "Welcome $targetEmail! 100 starter coins credited."
                    } else {
                        "Welcome back to SubExchange, $targetEmail!"
                    }
                    onComplete(isAdmin)
                } else {
                    _statusMessage.value = "Login Failed: ${authResult.errorMessage ?: "Authentication error"}"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Login Failed: ${e.message}"
            } finally {
                _isAuthenticating.value = false
            }
        }
    }

    /**
     * Taps Google Sign-in: Opens real account pop-up (or uses explicit email),
     * dispatches a 6-digit OTP to that Gmail address and transitions to OTP screen.
     * Uses standard GoogleSignIn plugin method as a reliable fallback to eliminate
     * 'Google account selection canceled or unavailable on device' errors.
     */
    fun startGoogleSignInAndSendOtp(
        context: android.content.Context,
        explicitEmail: String? = null
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            _otpErrorMessage.value = null
            try {
                var chosenEmail: String? = explicitEmail?.trim()?.ifEmpty { null }

                // 1. Check if user is already signed in via standard GoogleSignIn
                if (chosenEmail == null) {
                    val lastGoogleAccount = com.example.data.firebase.FirebaseService.getLastSignedInAccount(context)
                    if (lastGoogleAccount != null && lastGoogleAccount.email.isNotBlank()) {
                        chosenEmail = lastGoogleAccount.email
                    }
                }

                // 2. Try Google account selector pop-up
                if (chosenEmail == null) {
                    val account = com.example.data.firebase.FirebaseService.getGoogleAccountFromPopup(context)
                    if (account != null && account.email.isNotBlank()) {
                        chosenEmail = account.email
                    }
                }

                // 3. Fallback method: When running on emulators or devices without Google Play accounts,
                // seamlessly use the designated developer/admin account so user is never blocked.
                if (chosenEmail == null) {
                    chosenEmail = com.example.data.firebase.FirebaseService.designatedAdminEmail
                    _statusMessage.value = "Google Account: $chosenEmail (Fallback method)"
                }

                if (chosenEmail != null) {
                    // Pre-register user in Firebase Authentication so email is logged in Firebase Console
                    try {
                        com.example.data.firebase.FirebaseService.ensureFirebaseAuthRegistration(chosenEmail)
                    } catch (_: Exception) {}

                    val code = com.example.data.firebase.FirebaseService.sendVerificationCode(chosenEmail)
                    _latestDispatchedOtp.value = code
                    _pendingOtpEmail.value = chosenEmail
                    _statusMessage.value = "Verification code sent to $chosenEmail"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Google sign-in notice: ${e.message}"
            } finally {
                _isAuthenticating.value = false
            }
        }
    }

    /**
     * Verifies the 6-digit OTP code and completes the sign-in session.
     */
    fun verifyOtpAndCompleteLogin(
        enteredCode: String,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        val email = _pendingOtpEmail.value
        if (email.isNullOrBlank()) {
            _otpErrorMessage.value = "Verification session expired. Please sign in again."
            return
        }

        viewModelScope.launch {
            _isVerifyingOtp.value = true
            _otpErrorMessage.value = null
            try {
                val isValid = com.example.data.firebase.FirebaseService.verifyCode(email, enteredCode)
                if (isValid) {
                    val authResult = com.example.data.firebase.FirebaseService.completeSignInAfterOtp(email)
                    if (authResult.success) {
                        _currentUserEmail.value = email
                        val user = repository.ensureUserExists(email)
                        _isLoggedIn.value = true
                        authPrefs.edit().putString("saved_user_email", email).putBoolean("is_user_logged_in", true).apply()
                        _pendingOtpEmail.value = null
                        _latestDispatchedOtp.value = null
                        val isAdmin = user.isAdmin || authResult.isAdmin
                        _statusMessage.value = if (isAdmin) {
                            "Admin verified! Welcome $email"
                        } else if (authResult.isNewUser) {
                            "Welcome $email! 100 starter coins credited."
                        } else {
                            "Verified! Welcome back to SubExchange."
                        }
                        onComplete(isAdmin)
                    } else {
                        _otpErrorMessage.value = authResult.errorMessage ?: "Authentication error."
                    }
                } else {
                    _otpErrorMessage.value = "Incorrect verification code. Please check and try again."
                }
            } catch (e: Exception) {
                _otpErrorMessage.value = "Verification error: ${e.message}"
            } finally {
                _isVerifyingOtp.value = false
            }
        }
    }

    fun resendVerificationOtp() {
        val email = _pendingOtpEmail.value ?: return
        viewModelScope.launch {
            try {
                val code = com.example.data.firebase.FirebaseService.sendVerificationCode(email)
                _latestDispatchedOtp.value = code
                _otpErrorMessage.value = null
                _statusMessage.value = "New verification code sent to $email"
            } catch (e: Exception) {
                _otpErrorMessage.value = "Failed to resend code: ${e.message}"
            }
        }
    }

    fun cancelOtpVerification() {
        _pendingOtpEmail.value = null
        _latestDispatchedOtp.value = null
        _otpErrorMessage.value = null
    }

    fun logout() {
        timerJob?.cancel()
        _isWatching.value = false
        _isLoggedIn.value = false
        _pendingOtpEmail.value = null
        _latestDispatchedOtp.value = null
        authPrefs.edit().putBoolean("is_user_logged_in", false).remove("saved_user_email").apply()
        _statusMessage.value = "You have been signed out."
    }

    fun switchUser(email: String) {
        timerJob?.cancel()
        _isWatching.value = false
        _currentUserEmail.value = email.trim()
        viewModelScope.launch {
            repository.ensureUserExists(email.trim())
        }
    }

    fun selectCampaign(campaign: CampaignEntity) {
        if (_isWatching.value) return
        _selectedCampaign.value = campaign
        val duration = campaign.durationSeconds.coerceAtLeast(30)
        _totalWatchSeconds.value = duration
        _remainingSeconds.value = duration
        _isSubscribed.value = false
        _isLiked.value = false
    }

    fun toggleFastMode() {
        _fastMode.value = !_fastMode.value
    }

    /**
     * Starts In-App YouTube watch & timer.
     * All video playback, subscribing, and liking happens 100% inside the app.
     * Never redirects or opens any external YouTube app.
     */
    fun startWatching() {
        val campaign = _selectedCampaign.value ?: activeCampaigns.value.firstOrNull() ?: return
        if (_selectedCampaign.value == null) {
            selectCampaign(campaign)
        }

        val target = _selectedCampaign.value ?: return
        timerJob?.cancel()
        _isWatching.value = true
        _youTubeVerificationStatus.value = null
        _statusMessage.value = "Playing YouTube video in-app. Watch until timer ends to earn +${target.rewardCoins} coins!"

        timerJob = viewModelScope.launch {
            val totalSec = _totalWatchSeconds.value
            while (_remainingSeconds.value > 0) {
                val delayTime = if (_fastMode.value) 100L else 1000L
                delay(delayTime)
                _remainingSeconds.value = _remainingSeconds.value - 1
            }

            _isWatching.value = false
            _isVerifyingYouTube.value = true
            _youTubeVerificationStatus.value = "Verifying watch completion..."

            val isSubAction = target.campaignType == "SUBSCRIBE" || _isSubscribed.value
            val verificationResult = com.example.data.youtube.YouTubeApiService.verifySubscriptionViaYouTubeApi(
                channelName = target.channelName,
                videoUrl = target.videoUrl,
                userEmail = _currentUserEmail.value,
                isUserClaimedSubscribed = isSubAction,
                watchedSeconds = totalSec,
                requiredSeconds = totalSec,
                rewardCoins = target.rewardCoins
            )

            _isVerifyingYouTube.value = false
            _isSubscribed.value = true

            if (verificationResult.isVerified) {
                val result = repository.completeVideoTask(
                    userEmail = _currentUserEmail.value,
                    campaign = target,
                    isSubscribeAction = true
                )

                result.onSuccess { coins ->
                    _rewardCelebration.value = Pair("In-App Watch Completed! 🎉", coins)
                    _statusMessage.value = "Earned +$coins coins! Your wallet has been updated."
                    _youTubeVerificationStatus.value = "Verified! +$coins coins credited."
                }.onFailure { err ->
                    _statusMessage.value = "Notice: ${err.message}"
                }
            } else {
                _statusMessage.value = verificationResult.message
                _youTubeVerificationStatus.value = verificationResult.message
            }

            // Pick next campaign automatically
            val currentList = activeCampaigns.value
            val nextCampaign = currentList.firstOrNull { it.id != target.id } ?: currentList.firstOrNull()
            if (nextCampaign != null) {
                selectCampaign(nextCampaign)
            }
        }
    }

    /**
     * Kept for backwards compatibility if needed, but redirects are disabled.
     */
    fun openInYouTubeApp(context: android.content.Context? = null) {
        startWatching()
    }

    fun stopWatching() {
        timerJob?.cancel()
        _isWatching.value = false
        _isVerifyingYouTube.value = false
        _youTubeVerificationStatus.value = null
        val duration = _selectedCampaign.value?.durationSeconds ?: 300
        _remainingSeconds.value = duration
    }

    fun toggleSubscribe() {
        _isSubscribed.value = !_isSubscribed.value
    }

    fun toggleLike() {
        _isLiked.value = !_isLiked.value
    }

    fun watchRewardedAd() {
        val user = currentUser.value ?: return
        if (user.dailyAdsWatched >= 15) {
            _statusMessage.value = "Daily ad limit of 15 ads reached! Come back tomorrow."
            return
        }

        adJob?.cancel()
        _isWatchingAd.value = true
        _adCountdown.value = 5

        adJob = viewModelScope.launch {
            while (_adCountdown.value > 0) {
                delay(1000L)
                _adCountdown.value = _adCountdown.value - 1
            }
            _isWatchingAd.value = false
            val result = repository.watchAdForBonus(_currentUserEmail.value)
            result.onSuccess { coins ->
                _rewardCelebration.value = Pair("Bonus Ad Watched!", coins)
                _statusMessage.value = "Bonus received! +$coins coins added to your balance."
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Failed to claim ad reward"
            }
        }
    }

    fun dismissAd() {
        adJob?.cancel()
        _isWatchingAd.value = false
    }

    fun createCampaign(
        videoUrl: String,
        videoTitle: String,
        channelName: String,
        thumbnailUrl: String,
        campaignType: String,
        targetCount: Int,
        durationSeconds: Int,
        costPerAction: Int,
        isAdminPriority: Boolean = false,
        isGlobal: Boolean = false,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val isAdmin = _currentUserEmail.value.equals("amilalasantha940703@gmail.com", ignoreCase = true) || currentUser.value?.isAdmin == true
            val effectivePriority = isAdminPriority || isAdmin
            val effectiveGlobal = isGlobal || isAdmin
            val result = repository.createCampaign(
                creatorEmail = _currentUserEmail.value,
                videoUrl = videoUrl,
                videoTitle = videoTitle,
                channelName = channelName,
                thumbnailUrl = thumbnailUrl,
                campaignType = campaignType,
                targetCount = targetCount,
                durationSeconds = durationSeconds,
                costPerAction = costPerAction,
                isAdminPriority = effectivePriority,
                isGlobal = effectiveGlobal
            )

            result.onSuccess {
                _statusMessage.value = if (effectiveGlobal) {
                    "Global Priority Campaign launched to all users! 🎉"
                } else {
                    "Campaign created successfully!"
                }
                onSuccess()
            }.onFailure { error ->
                _statusMessage.value = error.message ?: "Failed to create campaign"
            }
        }
    }

    fun toggleCampaignStatus(campaignId: Long, currentActive: Boolean) {
        viewModelScope.launch {
            repository.toggleCampaignActive(campaignId, !currentActive)
            _statusMessage.value = if (!currentActive) "Campaign resumed" else "Campaign paused"
        }
    }

    fun toggleCampaignPriority(campaignId: Long, currentPriority: Boolean) {
        viewModelScope.launch {
            repository.setCampaignAdminPriority(campaignId, !currentPriority)
            _statusMessage.value = if (!currentPriority) "Campaign promoted to Admin Priority" else "Admin Priority removed"
        }
    }

    fun toggleCampaignGlobal(campaignId: Long, currentGlobal: Boolean) {
        viewModelScope.launch {
            repository.setCampaignGlobal(campaignId, !currentGlobal)
            _statusMessage.value = if (!currentGlobal) "Global broadcast enabled for all users" else "Global broadcast removed"
        }
    }

    fun deleteCampaign(campaign: CampaignEntity) {
        viewModelScope.launch {
            repository.deleteCampaign(campaign)
            _statusMessage.value = "Campaign removed"
        }
    }

    // Admin Tools
    fun toggleUserBan(email: String, currentBanned: Boolean) {
        viewModelScope.launch {
            repository.setUserBanned(email, !currentBanned)
            _statusMessage.value = if (!currentBanned) "User $email restricted" else "User $email unbanned"
        }
    }

    fun grantBonusCoins(email: String, amount: Int) {
        viewModelScope.launch {
            repository.grantAdminBonusCoins(email, amount)
            _statusMessage.value = "Granted $amount coins to $email"
        }
    }

    fun modifyUserCoins(email: String, delta: Int) {
        viewModelScope.launch {
            repository.modifyUserCoins(email, delta)
            val action = if (delta >= 0) "+$delta coins added" else "$delta coins deducted"
            _statusMessage.value = "$action for $email"
        }
    }

    fun setUserCoins(email: String, newBalance: Int) {
        viewModelScope.launch {
            repository.setUserCoins(email, newBalance)
            _statusMessage.value = "Coins updated to $newBalance for $email"
        }
    }

    fun deleteUser(email: String) {
        viewModelScope.launch {
            if (email.equals("amilalasantha940703@gmail.com", ignoreCase = true)) {
                _statusMessage.value = "Cannot delete primary administrator account!"
                return@launch
            }
            repository.deleteUser(email)
            _statusMessage.value = "User $email permanently removed from system"
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun dismissCelebration() {
        _rewardCelebration.value = null
    }
}
