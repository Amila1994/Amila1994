package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SubExchangeDatabase
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WatchHistoryEntity
import com.example.data.repository.SubExchangeRepository
import com.example.data.model.AdminEconomyConfig
import com.example.data.model.AppUpdateConfig
import com.example.data.model.SupportChatMessage
import com.example.data.model.SupportChatThread
import com.example.data.firebase.FirebaseService
import com.google.firebase.firestore.ListenerRegistration
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SubExchangeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SubExchangeDatabase.getDatabase(application)
    private val repository = SubExchangeRepository(db.userDao(), db.campaignDao(), db.watchHistoryDao(), db.reloadRequestDao(), application)
    private val authPrefs = application.getSharedPreferences("subexchange_auth_prefs", android.content.Context.MODE_PRIVATE)

    private val _currentUserEmail = MutableStateFlow("")
    val currentUserEmail: StateFlow<String> = _currentUserEmail.asStateFlow()

    private val _currentDashboardTab = MutableStateFlow(1)
    val currentDashboardTab: StateFlow<Int> = _currentDashboardTab.asStateFlow()

    fun selectDashboardTab(tab: Int) {
        _currentDashboardTab.value = tab
    }

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    private val _pendingOtpEmail = MutableStateFlow<String?>(null)
    val pendingOtpEmail: StateFlow<String?> = _pendingOtpEmail.asStateFlow()

    private val _latestDispatchedOtp = MutableStateFlow<String?>(null)
    val latestDispatchedOtp: StateFlow<String?> = _latestDispatchedOtp.asStateFlow()

    private val _isVerifyingOtp = MutableStateFlow(false)
    val isVerifyingOtp: StateFlow<Boolean> = _isVerifyingOtp.asStateFlow()

    private val _otpErrorMessage = MutableStateFlow<String?>(null)
    val otpErrorMessage: StateFlow<String?> = _otpErrorMessage.asStateFlow()

    val currentUser: StateFlow<UserEntity?> = _currentUserEmail.flatMapLatest { email ->
        repository.getUser(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allReloadRequests: StateFlow<List<com.example.data.local.entity.ReloadRequestEntity>> =
        repository.getAllReloadRequests().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userReloadRequests: StateFlow<List<com.example.data.local.entity.ReloadRequestEntity>> =
        _currentUserEmail.flatMapLatest { email ->
            repository.getReloadRequestsForUser(email)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingReloadCount: StateFlow<Int> =
        repository.getPendingReloadCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Filter out campaigns the user has already liked/commented/subscribed to!
    val activeCampaigns: StateFlow<List<CampaignEntity>> = combine(
        repository.getActiveCampaigns(),
        _currentUserEmail.flatMapLatest { email -> repository.getCompletedCampaignIds(email) }
    ) { campaigns, completedIds ->
        val completedSet = completedIds.toSet()
        campaigns.filter { campaign ->
            !completedSet.contains(campaign.id)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userCampaigns: StateFlow<List<CampaignEntity>> = _currentUserEmail.flatMapLatest { email ->
        repository.getCampaignsByCreator(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCampaigns: StateFlow<List<CampaignEntity>> =
        repository.getAllCampaigns().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<UserEntity>> =
        repository.getAllUsers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchHistory: StateFlow<List<WatchHistoryEntity>> = _currentUserEmail.flatMapLatest { email ->
        repository.getWatchHistory(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Video Player & Timer State
    private val _selectedCampaign = MutableStateFlow<CampaignEntity?>(null)
    val selectedCampaign: StateFlow<CampaignEntity?> = _selectedCampaign.asStateFlow()

    private val _isWatching = MutableStateFlow(false)
    val isWatching: StateFlow<Boolean> = _isWatching.asStateFlow()

    private val _remainingSeconds = MutableStateFlow(60) // වීඩියෝ කාලය (උදා: තත්පර 60ක් නම්)
    val remainingSeconds: StateFlow<Int> = _remainingSeconds.asStateFlow()

    private val _totalWatchSeconds = MutableStateFlow(60)
    val totalWatchSeconds: StateFlow<Int> = _totalWatchSeconds.asStateFlow()

    private val _isTimerFinished = MutableStateFlow(false) // ටයිමර් එක ඉවරද නැද්ද යන්න
    val isTimerFinished: StateFlow<Boolean> = _isTimerFinished.asStateFlow()

    private val _isSubscribed = MutableStateFlow(false)
    val isSubscribed: StateFlow<Boolean> = _isSubscribed.asStateFlow()

    private val _hasUserSubscribedOnYouTube = MutableStateFlow(false)
    val hasUserSubscribedOnYouTube: StateFlow<Boolean> = _hasUserSubscribedOnYouTube.asStateFlow()

    private val _hasUserLikedOnYouTube = MutableStateFlow(false)
    val hasUserLikedOnYouTube: StateFlow<Boolean> = _hasUserLikedOnYouTube.asStateFlow()

    private val _hasUserCommentedOnYouTube = MutableStateFlow(false)
    val hasUserCommentedOnYouTube: StateFlow<Boolean> = _hasUserCommentedOnYouTube.asStateFlow()

    private val _isVideoPlaying = MutableStateFlow(true)
    val isVideoPlaying: StateFlow<Boolean> = _isVideoPlaying.asStateFlow()

    private val _isFullWatchMode = MutableStateFlow(false)
    val isFullWatchMode: StateFlow<Boolean> = _isFullWatchMode.asStateFlow()

    private val _isLiked = MutableStateFlow(false)
    val isLiked: StateFlow<Boolean> = _isLiked.asStateFlow()

    private val _isVerifyingYouTube = MutableStateFlow(false)
    val isVerifyingYouTube: StateFlow<Boolean> = _isVerifyingYouTube.asStateFlow()

    private val _youTubeVerificationStatus = MutableStateFlow<String?>(null)
    val youTubeVerificationStatus: StateFlow<String?> = _youTubeVerificationStatus.asStateFlow()

    private val _fastMode = MutableStateFlow(false)
    val fastMode: StateFlow<Boolean> = _fastMode.asStateFlow()

    // Ad state
    private val _isWatchingAd = MutableStateFlow(false)
    val isWatchingAd: StateFlow<Boolean> = _isWatchingAd.asStateFlow()

    private val _adCountdown = MutableStateFlow(5)
    val adCountdown: StateFlow<Int> = _adCountdown.asStateFlow()

    // Dialogs & Feedback
    private val _rewardCelebration = MutableStateFlow<Pair<String, Int>?>(null)
    val rewardCelebration: StateFlow<Pair<String, Int>?> = _rewardCelebration.asStateFlow()

    // 3-Strike Warning & Account Ban Policy State Flows
    private val _violationWarning = MutableStateFlow<String?>(null)
    val violationWarning: StateFlow<String?> = _violationWarning.asStateFlow()

    private val _unsubscribedChannelsList = MutableStateFlow<List<String>>(emptyList())
    val unsubscribedChannelsList: StateFlow<List<String>> = _unsubscribedChannelsList.asStateFlow()

    // Compulsory Multi-Item Fraud Violation Blocking State
    private val _activeViolations = MutableStateFlow<List<com.example.data.model.FraudViolationItem>>(emptyList())
    val activeViolations: StateFlow<List<com.example.data.model.FraudViolationItem>> = _activeViolations.asStateFlow()

    private val _isVerifyingViolations = MutableStateFlow(false)
    val isVerifyingViolations: StateFlow<Boolean> = _isVerifyingViolations.asStateFlow()

    private val _violationVerificationMessage = MutableStateFlow<String?>(null)
    val violationVerificationMessage: StateFlow<String?> = _violationVerificationMessage.asStateFlow()

    fun toggleViolationSubResolved(violationId: String) {
        _activeViolations.value = _activeViolations.value.map { item ->
            if (item.id == violationId) {
                item.copy(isSubResolved = !item.isSubResolved)
            } else {
                item
            }
        }
    }

    fun toggleViolationLikeResolved(violationId: String) {
        _activeViolations.value = _activeViolations.value.map { item ->
            if (item.id == violationId) {
                item.copy(isLikeResolved = !item.isLikeResolved)
            } else {
                item
            }
        }
    }

    fun openViolationOnYouTube(context: Context, item: com.example.data.model.FraudViolationItem) {
        if (item.videoId.isNotBlank()) {
            com.example.data.youtube.YouTubeApiService.openVideoInYouTubeApp(context, "https://www.youtube.com/watch?v=${item.videoId}")
        } else {
            com.example.data.youtube.YouTubeApiService.openChannelInYouTube(context, item.channelName, item.directUrl)
        }
    }

    fun verifyAndResolveAllViolations(context: Context) {
        val violations = _activeViolations.value
        if (violations.isEmpty()) return

        val unresolved = violations.filter { !it.isFullyResolved }
        if (unresolved.isNotEmpty()) {
            _violationVerificationMessage.value = "⚠️ Please re-perform both Sub and Like actions for all items before verifying! (${violations.count { it.isFullyResolved }}/${violations.size} ready)"
            return
        }

        viewModelScope.launch {
            _isVerifyingViolations.value = true
            _violationVerificationMessage.value = "Verifying all subscriptions and likes with YouTube Data API v3..."

            val token = _oauthAccessToken.value.ifBlank { authPrefs.getString("oauth_access_token", "") ?: "" }.trim()
            if (token.isNotBlank()) {
                for (v in violations) {
                    val chId = com.example.data.youtube.YouTubeApiService.resolveChannelIdFromVideo(v.channelName)
                    if (chId.isNotBlank()) {
                        val check = com.example.data.youtube.YouTubeApiService.verifyChannelSubscription(token, chId)
                        if (!check.getOrDefault(false)) {
                            _violationVerificationMessage.value = "⚠️ Real-time YouTube check failed: You have not re-subscribed to '${v.channelName}' yet on YouTube!"
                            _isVerifyingViolations.value = false
                            return@launch
                        }
                    }
                }
            }

            val email = _currentUserEmail.value
            val result = repository.resolveAllViolations(email)
            if (result.isSuccess) {
                _activeViolations.value = emptyList()
                _unsubscribedChannelsList.value = emptyList()
                _violationWarning.value = null
                _violationVerificationMessage.value = null
                _statusMessage.value = "✅ All violations verified and resolved! Normal app access restored."
            } else {
                _violationVerificationMessage.value = "Verification failed: ${result.exceptionOrNull()?.message}"
            }
            _isVerifyingViolations.value = false
        }
    }

    private val _isWarningDismissedByUser = MutableStateFlow(false)
    val isWarningDismissedByUser: StateFlow<Boolean> = _isWarningDismissedByUser.asStateFlow()

    private val _banReason = MutableStateFlow<String>("")
    val banReason: StateFlow<String> = _banReason.asStateFlow()

    private val _isWatchingUnbanAd = MutableStateFlow(false)
    val isWatchingUnbanAd: StateFlow<Boolean> = _isWatchingUnbanAd.asStateFlow()

    private val _unbanAdCountdown = MutableStateFlow(5)
    val unbanAdCountdown: StateFlow<Int> = _unbanAdCountdown.asStateFlow()

    private val _unbanStatusMessage = MutableStateFlow<String?>(null)
    val unbanStatusMessage: StateFlow<String?> = _unbanStatusMessage.asStateFlow()

    private val _appealSubmitted = MutableStateFlow(false)
    val appealSubmitted: StateFlow<Boolean> = _appealSubmitted.asStateFlow()

    // Admin Feature: User Inspection State
    private val _inspectedUser = MutableStateFlow<com.example.data.firebase.FirebaseService.FirestoreUserProfile?>(null)
    val inspectedUser: StateFlow<com.example.data.firebase.FirebaseService.FirestoreUserProfile?> = _inspectedUser.asStateFlow()

    private val _inspectedUserHistory = MutableStateFlow<List<com.example.data.firebase.FirebaseService.VerifiedRewardRecord>>(emptyList())
    val inspectedUserHistory: StateFlow<List<com.example.data.firebase.FirebaseService.VerifiedRewardRecord>> = _inspectedUserHistory.asStateFlow()

    private val _isSearchingInspectedUser = MutableStateFlow(false)
    val isSearchingInspectedUser: StateFlow<Boolean> = _isSearchingInspectedUser.asStateFlow()

    private val _inspectUserSearchError = MutableStateFlow<String?>(null)
    val inspectUserSearchError: StateFlow<String?> = _inspectUserSearchError.asStateFlow()

    private val _oauthAccessToken = MutableStateFlow<String>(authPrefs.getString("oauth_access_token", "") ?: "")
    val oauthAccessToken: StateFlow<String> = _oauthAccessToken.asStateFlow()

    private val _userChannelId = MutableStateFlow<String>(authPrefs.getString("user_channel_id", "") ?: "")
    val userChannelId: StateFlow<String> = _userChannelId.asStateFlow()

    private var unbanAdJob: Job? = null

    fun dismissViolationWarning() {
        _violationWarning.value = null
        _isWarningDismissedByUser.value = true
    }

    fun searchAndInspectUserInFirestore(email: String) {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.isBlank()) {
            _inspectUserSearchError.value = "Please enter an email address to search."
            return
        }
        viewModelScope.launch {
            _isSearchingInspectedUser.value = true
            _inspectUserSearchError.value = null
            try {
                val (profile, history) = repository.inspectUserInFirestore(cleanEmail)
                if (profile != null) {
                    _inspectedUser.value = profile
                    _inspectedUserHistory.value = history
                    _inspectUserSearchError.value = null
                } else {
                    val local = repository.ensureUserExists(cleanEmail)
                    if (local.email.isNotBlank()) {
                        val unsubs = local.unsubscribedChannels.split(",").map { it.trim() }.filter { it.isNotBlank() }
                        _inspectedUser.value = com.example.data.firebase.FirebaseService.FirestoreUserProfile(
                            email = local.email,
                            name = local.email.substringBefore("@"),
                            coins = local.coins,
                            dailyAdsWatched = local.dailyAdsWatched,
                            totalEarned = local.totalEarned,
                            totalSpent = local.totalSpent,
                            videosWatchedCount = local.videosWatchedCount,
                            channelsSubscribedCount = local.channelsSubscribedCount,
                            isBanned = local.isBanned,
                            isAdmin = local.isAdmin,
                            warningCount = local.warningCount,
                            banReason = local.banReason,
                            banTimestamp = local.banTimestamp,
                            unbanAdsWatched = local.unbanAdsWatched,
                            unbanDailyAdsWatched = local.unbanDailyAdsWatched,
                            appealMessage = local.appealMessage,
                            appealStatus = local.appealStatus,
                            unsubscribedChannels = unsubs
                        )
                        _inspectedUserHistory.value = history
                        _inspectUserSearchError.value = null
                    } else {
                        _inspectedUser.value = null
                        _inspectedUserHistory.value = emptyList()
                        _inspectUserSearchError.value = "User not found in Firestore for '$cleanEmail'."
                    }
                }
            } catch (e: Exception) {
                _inspectUserSearchError.value = "Search error: ${e.message}"
            } finally {
                _isSearchingInspectedUser.value = false
            }
        }
    }

    fun clearInspectedUser() {
        _inspectedUser.value = null
        _inspectedUserHistory.value = emptyList()
        _inspectUserSearchError.value = null
    }

    fun adminUnbanInspectedUser(email: String) {
        viewModelScope.launch {
            repository.unbanUserDirectly(email)
            searchAndInspectUserInFirestore(email)
            _statusMessage.value = "$email successfully unbanned in Firestore & local DB!"
        }
    }

    fun adminBanInspectedUser(email: String, reason: String) {
        viewModelScope.launch {
            repository.adminBanUser(email, reason)
            searchAndInspectUserInFirestore(email)
            _statusMessage.value = "$email banned: $reason"
        }
    }

    fun adminSetInspectedUserCoins(email: String, newBalance: Int) {
        viewModelScope.launch {
            repository.adminSetCoins(email, newBalance)
            searchAndInspectUserInFirestore(email)
            _statusMessage.value = "$email coin balance set to $newBalance"
        }
    }

    fun adminResetInspectedUserStrikes(email: String) {
        viewModelScope.launch {
            repository.adminResetStrikes(email)
            searchAndInspectUserInFirestore(email)
            _statusMessage.value = "Strikes and unsub violations reset for $email"
        }
    }

    fun adminDeleteInspectedUser(email: String) {
        viewModelScope.launch {
            repository.adminDeleteUser(email)
            clearInspectedUser()
            _statusMessage.value = "$email account deleted permanently."
        }
    }

    fun openChannelOnYouTube(context: android.content.Context, channelName: String) {
        com.example.data.youtube.YouTubeApiService.openChannelInYouTube(context, channelName, "")
    }

    fun resubscribeToChannel(channelName: String) {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            val unsubs = user.unsubscribedChannels.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
            unsubs.remove(channelName.trim())
            val updated = unsubs.joinToString(",")
            com.example.data.local.SubExchangeDatabase.getDatabase(getApplication()).userDao().updateUnsubscribedChannels(user.email, updated)
            _unsubscribedChannelsList.value = unsubs
            if (unsubs.isEmpty()) {
                _violationWarning.value = null
                com.example.data.firebase.FirebaseService.clearUnsubscribedChannelsInFirestore(user.email)
            }
            _statusMessage.value = "Re-subscribed to $channelName! Warning cleared."
        }
    }

    fun submitUnbanAppeal(message: String) {
        viewModelScope.launch {
            val res = repository.submitUnbanAppeal(_currentUserEmail.value, message)
            res.onSuccess {
                _appealSubmitted.value = true
                _unbanStatusMessage.value = "ඔබගේ ඉල්ලීම Admin වෙත සාර්ථකව යවන ලදී. Admin විසින් එය පරීක්ෂා කර ඔබගේ ගිණුම Unban කරනු ඇත."
            }.onFailure { err ->
                _unbanStatusMessage.value = err.message ?: "Failed to submit appeal"
            }
        }
    }

    fun startWatchUnbanAd() {
        if (_isWatchingUnbanAd.value) return
        _isWatchingUnbanAd.value = true
        _unbanAdCountdown.value = 5
        unbanAdJob?.cancel()
        unbanAdJob = viewModelScope.launch {
            for (i in 5 downTo 1) {
                _unbanAdCountdown.value = i
                delay(1000L)
            }
            _isWatchingUnbanAd.value = false
            val result = repository.watchUnbanAd(_currentUserEmail.value)
            result.onSuccess { res ->
                _unbanStatusMessage.value = res.message
                if (res.isUnbanned) {
                    _statusMessage.value = "🎉 ඔබගේ ගිණුම සාර්ථකව Unban කරන ලදී!"
                }
            }.onFailure { err ->
                _unbanStatusMessage.value = err.message ?: "Ad watch failed"
            }
        }
    }

    fun cancelWatchUnbanAd() {
        unbanAdJob?.cancel()
        _isWatchingUnbanAd.value = false
    }

    fun clearUnbanStatusMessage() {
        _unbanStatusMessage.value = null
    }

    fun unbanUserByAdmin(email: String) {
        viewModelScope.launch {
            repository.unbanUserDirectly(email)
            _statusMessage.value = "$email ගිණුම Unban කරන ලදී."
        }
    }

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _showNotEnoughWatchTimeDialog = MutableStateFlow(false)
    val showNotEnoughWatchTimeDialog: StateFlow<Boolean> = _showNotEnoughWatchTimeDialog.asStateFlow()

    private val _showNotSubscribedDialog = MutableStateFlow(false)
    val showNotSubscribedDialog: StateFlow<Boolean> = _showNotSubscribedDialog.asStateFlow()

    private val _economyConfig = MutableStateFlow(repository.getEconomyConfig())
    val economyConfig: StateFlow<AdminEconomyConfig> = _economyConfig.asStateFlow()

    fun updateEconomyConfig(newConfig: AdminEconomyConfig) {
        repository.saveEconomyConfig(newConfig)
        _economyConfig.value = newConfig
        _statusMessage.value = "Admin economy settings saved: Sub=${newConfig.rewardPerSubscribe}, Like=${newConfig.rewardPerLike}, Ad=${newConfig.rewardPerAd}c, MaxAds=${newConfig.maxDailyAds}"
    }

    private val _tasksConfig = MutableStateFlow(repository.getTasksConfig())
    val tasksConfig: StateFlow<com.example.data.model.AdminTasksConfig> = _tasksConfig.asStateFlow()

    private val _userTasksState = MutableStateFlow(com.example.data.model.UserTasksState())
    val userTasksState: StateFlow<com.example.data.model.UserTasksState> = _userTasksState.asStateFlow()

    fun refreshUserTasksState() {
        val email = _currentUserEmail.value
        if (email.isNotBlank()) {
            _userTasksState.value = repository.getUserTasksState(email)
        }
    }

    fun updateTasksConfig(newConfig: com.example.data.model.AdminTasksConfig) {
        repository.saveTasksConfig(newConfig)
        _tasksConfig.value = newConfig
        _statusMessage.value = "Promo & Tasks settings saved successfully!"
        refreshUserTasksState()
    }

    fun checkAndAwardPromoIfEligible(email: String) {
        val config = _tasksConfig.value.promoEvent
        if (!config.isEventActive) return
        if (System.currentTimeMillis() > config.endTimestamp) return

        val state = repository.getUserTasksState(email)
        val progress = state.promoProgress
        if (!progress.isRewardClaimed &&
            progress.campaignsCount >= config.targetCampaigns &&
            progress.subscribesCount >= config.targetSubscribes &&
            progress.likesCount >= config.targetLikes
        ) {
            repository.setPromoRewardClaimed(email)
            viewModelScope.launch {
                repository.addCoins(email, config.rewardCoins)
                _statusMessage.value = "🎉 ප්‍රවර්ධන ඉලක්ක සියල්ල සම්පූර්ණයි! ඔබගේ ගිණුමට කාසි ${config.rewardCoins} ක් එක් විය!"
                android.widget.Toast.makeText(getApplication(), "ප්‍රවර්ධන ඉලක්ක සම්පූර්ණයි! +${config.rewardCoins} Coins! 🎉", android.widget.Toast.LENGTH_LONG).show()
                refreshUserTasksState()
            }
        } else {
            refreshUserTasksState()
        }
    }

    fun claimTaskReward(taskId: String) {
        val email = _currentUserEmail.value.ifBlank { return }
        val config = _tasksConfig.value
        val task = when (taskId) {
            "task_watch_streak" -> config.taskWatchStreak
            "task_daily_login" -> config.taskDailyLogin
            "task_invite_friend" -> config.taskInviteFriend
            "task_high_watch" -> config.taskHighWatchTime
            "task_community" -> config.taskCommunityDesk
            else -> null
        } ?: return

        repository.setTaskClaimed(email, taskId)
        viewModelScope.launch {
            repository.addCoins(email, task.rewardCoins)
            _statusMessage.value = "${task.title} සම්පූර්ණයි! +${task.rewardCoins} Coins එක් විය! 🎉"
            android.widget.Toast.makeText(getApplication(), "+${task.rewardCoins} Coins ලැබුණා! 🎉", android.widget.Toast.LENGTH_SHORT).show()
            refreshUserTasksState()
        }
    }

    fun redeemReferralCode(code: String, onSuccess: (welcomeCoins: Int) -> Unit, onError: (String) -> Unit) {
        val email = _currentUserEmail.value.ifBlank {
            onError("කරුණාකර පළමුව ලොග් වන්න.")
            return
        }
        viewModelScope.launch {
            val res = repository.redeemReferralCode(email, code)
            res.onSuccess { (welcomeCoins, referrerCoins) ->
                _statusMessage.value = "Referral සාර්ථකයි! ඔබගේ ගිණුමට කාසි $welcomeCoins ක් ලැබිණි! 🎁"
                android.widget.Toast.makeText(getApplication(), "Referral කේතය පිළිගැනිණි! +$welcomeCoins Coins 🎁", android.widget.Toast.LENGTH_SHORT).show()
                refreshUserTasksState()
                onSuccess(welcomeCoins)
            }.onFailure { err ->
                onError(err.message ?: "Referral code redemption failed.")
            }
        }
    }

    fun recordCommunityHelpDeskVisited() {
        val email = _currentUserEmail.value
        if (email.isNotBlank()) {
            repository.recordCommunityVisited(email)
            refreshUserTasksState()
        }
    }

    val currentAppVersionCode: Int = 1
    val currentAppVersionName: String = "1.0"

    private val _appUpdateConfig = MutableStateFlow(repository.getUpdateConfig())
    val appUpdateConfig: StateFlow<AppUpdateConfig> = _appUpdateConfig.asStateFlow()

    val isUpdateRequired: StateFlow<Boolean> = _appUpdateConfig.map { config ->
        config.isMandatory && currentAppVersionCode < config.requiredVersionCode
    }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    fun publishAppUpdate(config: AppUpdateConfig, sendNotification: Boolean = true) {
        val updatedConfig = config.copy(lastAnnouncedTimestamp = System.currentTimeMillis())
        repository.saveUpdateConfig(updatedConfig)
        _appUpdateConfig.value = updatedConfig
        _statusMessage.value = "Update announced! Required Version: ${config.versionName}"

        viewModelScope.launch {
            FirebaseService.syncAppUpdateToFirestore(updatedConfig)
        }

        if (sendNotification) {
            com.example.util.NotificationHelper.showUpdateNotification(
                context = getApplication(),
                title = updatedConfig.updateTitle,
                message = updatedConfig.updateMessage,
                downloadUrl = updatedConfig.downloadUrl
            )
        }
    }

    fun clearAppUpdate() {
        val resetConfig = AppUpdateConfig(
            requiredVersionCode = 1,
            versionName = "1.0",
            isMandatory = false,
            lastAnnouncedTimestamp = 0L
        )
        repository.saveUpdateConfig(resetConfig)
        _appUpdateConfig.value = resetConfig
        _statusMessage.value = "App update requirement cleared."
        viewModelScope.launch {
            FirebaseService.syncAppUpdateToFirestore(resetConfig)
        }
    }

    fun simulateUpdateInstalled() {
        val current = _appUpdateConfig.value
        val satisfiedConfig = current.copy(requiredVersionCode = 1, isMandatory = false)
        repository.saveUpdateConfig(satisfiedConfig)
        _appUpdateConfig.value = satisfiedConfig
        _statusMessage.value = "Updated to version ${current.versionName}! You can now watch videos."
    }

    private var timerJob: Job? = null
    private var adJob: Job? = null

    val subscriptionAuditManager by lazy {
        com.example.data.audit.SubscriptionAuditManager(
            repository = repository,
            watchHistoryDao = com.example.data.local.SubExchangeDatabase.getDatabase(getApplication()).watchHistoryDao(),
            context = getApplication()
        )
    }

    private var appUpdateListener: ListenerRegistration? = null

    init {
        // App එකේ save වි ඇති සියලුම පැරණි email සැසි ඉවත් කර නැවුම් Login Screen එක පෙන්වයි
        val savedEmail = authPrefs.getString("saved_user_email", null)
        val wasLoggedIn = authPrefs.getBoolean("is_user_logged_in", false)
        val savedToken = authPrefs.getString("oauth_access_token", null)
        if (!savedToken.isNullOrBlank()) {
            _oauthAccessToken.value = savedToken
        }

        // Restore persistent login session so user goes straight to dashboard
        if (wasLoggedIn && !savedEmail.isNullOrBlank()) {
            val cleanEmail = savedEmail.trim().lowercase()
            _currentUserEmail.value = cleanEmail
            _isLoggedIn.value = true
            val isAdmin = cleanEmail.equals(com.example.data.firebase.FirebaseService.designatedAdminEmail, ignoreCase = true)
            _currentDashboardTab.value = if (isAdmin) 2 else 1

            if (_oauthAccessToken.value.isBlank()) {
                viewModelScope.launch {
                    val token = com.example.data.youtube.YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(getApplication(), cleanEmail)
                    if (!token.isNullOrBlank()) {
                        saveOAuthToken(token)
                    }
                }
            }
        } else {
            _isLoggedIn.value = false
            _currentUserEmail.value = ""
        }

        viewModelScope.launch {
            repository.seedSampleDataIfEmpty()
            if (_currentUserEmail.value.isNotBlank()) {
                repository.ensureUserExists(_currentUserEmail.value)
                runStartupSubscriptionAudit(_currentUserEmail.value)
            }
        }

        viewModelScope.launch {
            currentUser.collect { user ->
                if (user != null && user.unsubscribedChannels.isNotBlank()) {
                    val unsubs = user.unsubscribedChannels.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    _unsubscribedChannelsList.value = unsubs
                    if (_activeViolations.value.isEmpty() && unsubs.isNotEmpty()) {
                        _activeViolations.value = unsubs.map { ch ->
                            com.example.data.model.FraudViolationItem(
                                id = ch,
                                channelName = ch,
                                videoTitle = "YouTube Channel: $ch",
                                thumbnailUrl = "",
                                directUrl = "https://www.youtube.com/results?search_query=$ch",
                                violationType = "BOTH",
                                isSubResolved = false,
                                isLikeResolved = false
                            )
                        }
                    }
                }
            }
        }

        // Auto select first uncompleted campaign
        viewModelScope.launch {
            activeCampaigns.collect { list ->
                val current = _selectedCampaign.value
                if (list.isEmpty()) {
                    _selectedCampaign.value = null
                } else if (current == null || list.none { it.id == current.id }) {
                    val priority = list.firstOrNull { it.isAdminPriority || it.isGlobal } ?: list.first()
                    selectCampaign(priority)
                }
            }
        }

        // Real-time listener for app updates published by Admin
        appUpdateListener = FirebaseService.listenToAppUpdateConfig { config ->
            val prev = _appUpdateConfig.value
            _appUpdateConfig.value = config
            repository.saveUpdateConfig(config)
            if (config.lastAnnouncedTimestamp > 0L && config.lastAnnouncedTimestamp != prev.lastAnnouncedTimestamp) {
                com.example.util.NotificationHelper.showUpdateNotification(
                    context = getApplication(),
                    title = config.updateTitle,
                    message = config.updateMessage,
                    downloadUrl = config.downloadUrl
                )
            }
        }
    }

    fun loginWithGoogle(
        context: android.content.Context? = null,
        email: String,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.isBlank()) {
            _statusMessage.value = "Please enter a valid email address."
            return
        }

        viewModelScope.launch {
            _isAuthenticating.value = true
            try {
                val authResult = if (context != null) {
                    com.example.data.firebase.FirebaseService.signInWithGoogle(context, cleanEmail)
                } else {
                    com.example.data.firebase.FirebaseService.signInWithGoogleFallback(cleanEmail)
                }

                if (authResult.success) {
                    val targetEmail = authResult.email.trim().lowercase().ifEmpty { cleanEmail }
                    _currentUserEmail.value = targetEmail
                    val user = repository.ensureUserExists(targetEmail)
                    _isLoggedIn.value = true
                    authPrefs.edit().putString("saved_user_email", targetEmail).putBoolean("is_user_logged_in", true).apply()

                    if (authResult.oauthAccessToken.isNotBlank()) {
                        saveOAuthToken(authResult.oauthAccessToken)
                    } else {
                        viewModelScope.launch {
                            val token = com.example.data.youtube.YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(context ?: getApplication(), targetEmail)
                            if (!token.isNullOrBlank()) {
                                saveOAuthToken(token)
                            }
                        }
                    }

                    val isAdmin = com.example.data.firebase.FirebaseService.isAppAdmin(targetEmail) || user.isAdmin || authResult.isAdmin
                    
                    // CRITICAL ROUTING RULE:
                    // Admin (amila940703@gmail.com / amilalasantha940703@gmail.com) -> Tab 2 (Admin Control Panel)
                    // Regular user (any other email) -> Tab 1 (Normal Dashboard: Watch & Earn / Subscribe)
                    val targetTab = if (isAdmin) 2 else 1
                    _currentDashboardTab.value = targetTab

                    _statusMessage.value = if (isAdmin) {
                        "👑 Admin verified! Welcome to Admin Panel ($targetEmail)"
                    } else if (authResult.isNewUser) {
                        "Welcome $targetEmail! 100 starter coins credited."
                    } else {
                        "Welcome back to SubExchange, $targetEmail!"
                    }
                    runStartupSubscriptionAudit(targetEmail)
                    onComplete(isAdmin)
                } else {
                    _statusMessage.value = "Login Failed: ${authResult.errorMessage ?: "Authentication error"}"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Login Failed: ${e.message}"
            } finally {
                _isAuthenticating.value = false
            }
        }
    }

    /**
     * Authenticates with Google and Firebase Credential (idToken) and navigates
     * DIRECTLY to the Dashboard without any email verification.
     */
    fun loginWithGoogleAccount(
        context: android.content.Context,
        email: String,
        idToken: String? = null,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        val cleanEmail = email.trim().lowercase()
        val emailValidation = com.example.util.EmailValidator.validate(cleanEmail)
        if (idToken.isNullOrBlank() && emailValidation is com.example.util.EmailValidator.Result.Invalid) {
            _statusMessage.value = "Login Failed: ${emailValidation.reason}"
            android.widget.Toast.makeText(context, emailValidation.reason, android.widget.Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch {
            _isAuthenticating.value = true
            _statusMessage.value = "Authenticating with Google..."
            try {
                val authResult = if (!idToken.isNullOrBlank()) {
                    com.example.data.firebase.FirebaseService.signInWithGoogleCredential(idToken, cleanEmail)
                } else {
                    com.example.data.firebase.FirebaseService.signInWithGoogle(context, cleanEmail)
                }

                if (authResult.success) {
                    val targetEmail = authResult.email.trim().lowercase().ifEmpty { cleanEmail }
                    _currentUserEmail.value = targetEmail
                    val user = repository.ensureUserExists(targetEmail)
                    _isLoggedIn.value = true
                    _pendingOtpEmail.value = null
                    _latestDispatchedOtp.value = null
                    authPrefs.edit().putString("saved_user_email", targetEmail).putBoolean("is_user_logged_in", true).apply()

                    // Toast: Login Successful! (Direct to Dashboard without email verification)
                    android.widget.Toast.makeText(context, "Login Successful!", android.widget.Toast.LENGTH_SHORT).show()

                    repository.recordDailyLogin(targetEmail)
                    refreshUserTasksState()

                    val isAdmin = com.example.data.firebase.FirebaseService.isAppAdmin(targetEmail) || user.isAdmin || authResult.isAdmin
                    val targetTab = if (isAdmin) 2 else 1
                    _currentDashboardTab.value = targetTab

                    _statusMessage.value = if (isAdmin) {
                        "👑 Admin verified! Welcome to Admin Panel ($targetEmail)"
                    } else if (authResult.isNewUser) {
                        "Welcome $targetEmail! Starter coins credited."
                    } else {
                        "Welcome back to SubExchange, $targetEmail!"
                    }
                    viewModelScope.launch {
                        val token = com.example.data.youtube.YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(getApplication(), targetEmail)
                        if (!token.isNullOrBlank()) {
                            saveOAuthToken(token)
                        }
                    }
                    runStartupSubscriptionAudit(targetEmail)
                    repository.recordDailyLogin(targetEmail)
                    refreshUserTasksState()
                    onComplete(isAdmin)
                } else {
                    val error = authResult.errorMessage ?: "Authentication failed"
                    _statusMessage.value = "Authentication Failed: $error"
                    android.widget.Toast.makeText(context, "Authentication Failed: $error", android.widget.Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                _statusMessage.value = "Authentication Failed: ${e.message}"
                android.widget.Toast.makeText(context, "Authentication Failed: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
            } finally {
                _isAuthenticating.value = false
            }
        }
    }

    /**
     * Dedicated Admin Sign-In: ONLY permitted for amilalasantha940703@gmail.com
     * Directly navigates to the Admin Control Panel (Dashboard Tab 2)
     */
    fun loginAsAdmin(
        context: android.content.Context,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        loginWithGoogleAccount(context, com.example.data.firebase.FirebaseService.designatedAdminEmail, null) {
            _currentDashboardTab.value = 2
            onComplete(true)
        }
    }

    /**
     * Clears all saved accounts, Google sessions, and SharedPreferences
     */
    fun clearAllSavedSessionData(context: android.content.Context) {
        logout()
        try {
            com.example.data.firebase.FirebaseService.clearAllSavedSessions(context)
        } catch (_: Exception) {}
        _statusMessage.value = "All saved accounts and sessions cleared."
        android.widget.Toast.makeText(context, "All saved accounts and sessions cleared.", android.widget.Toast.LENGTH_SHORT).show()
    }

    /**
     * Taps Google Sign-in: Direct sign-in with Google account
     */
    fun startGoogleSignInAndSendOtp(
        context: android.content.Context,
        explicitEmail: String? = null,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        val email = explicitEmail ?: com.example.data.firebase.FirebaseService.getLastSignedInAccount(context)?.email ?: ""
        if (email.isNotBlank()) {
            loginWithGoogleAccount(context, email, null, onComplete)
        }
    }

    /**
     * Verifies the 6-digit OTP code and completes the sign-in session.
     */
    fun verifyOtpAndCompleteLogin(
        enteredCode: String,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        val rawEmail = _pendingOtpEmail.value
        if (rawEmail.isNullOrBlank()) {
            _otpErrorMessage.value = "Verification session expired. Please sign in again."
            return
        }
        val email = rawEmail.trim().lowercase()

        viewModelScope.launch {
            _isVerifyingOtp.value = true
            _otpErrorMessage.value = null
            try {
                val isValid = com.example.data.firebase.FirebaseService.verifyCode(email, enteredCode)
                if (isValid) {
                    val authResult = com.example.data.firebase.FirebaseService.completeSignInAfterOtp(email)
                    if (authResult.success) {
                        _currentUserEmail.value = email
                        val user = repository.ensureUserExists(email)
                        _isLoggedIn.value = true
                        authPrefs.edit().putString("saved_user_email", email).putBoolean("is_user_logged_in", true).apply()
                        _pendingOtpEmail.value = null
                        _latestDispatchedOtp.value = null

                        viewModelScope.launch {
                            val token = com.example.data.youtube.YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(getApplication(), email)
                            if (!token.isNullOrBlank()) {
                                saveOAuthToken(token)
                            }
                        }

                        repository.recordDailyLogin(email)
                        refreshUserTasksState()

                        val isAdmin = com.example.data.firebase.FirebaseService.isAppAdmin(email) || user.isAdmin || authResult.isAdmin
                        
                        // CRITICAL ROUTING RULE:
                        // Admin (amila940703@gmail.com / amilalasantha940703@gmail.com) -> Tab 2 (Admin Control Panel)
                        // Regular user (any other email) -> Tab 1 (Normal Dashboard: Watch & Earn / Subscribe)
                        val targetTab = if (isAdmin) 2 else 1
                        _currentDashboardTab.value = targetTab

                        _statusMessage.value = if (isAdmin) {
                            "👑 Admin verified! Welcome to Admin Panel ($email)"
                        } else if (authResult.isNewUser) {
                            "Welcome $email! 100 starter coins credited."
                        } else {
                            "Verified! Welcome back to SubExchange."
                        }
                        runStartupSubscriptionAudit(email)
                        onComplete(isAdmin)
                    } else {
                        _otpErrorMessage.value = authResult.errorMessage ?: "Authentication error."
                    }
                } else {
                    _otpErrorMessage.value = "Incorrect verification code. Please check and try again."
                }
            } catch (e: Exception) {
                _otpErrorMessage.value = "Verification error: ${e.message}"
            } finally {
                _isVerifyingOtp.value = false
            }
        }
    }

    fun resendVerificationOtp(context: Context? = null) {
        val email = _pendingOtpEmail.value ?: return
        viewModelScope.launch {
            try {
                if (context != null) {
                    com.example.data.firebase.FirebaseService.sendEmailVerificationLink(context, email)
                } else {
                    com.example.data.firebase.FirebaseService.sendEmailVerificationLink(getApplication(), email)
                }
                _otpErrorMessage.value = null
                _statusMessage.value = "New verification link sent to $email. Please check your Gmail app."
            } catch (e: Exception) {
                _otpErrorMessage.value = "Failed to resend link: ${e.message}"
            }
        }
    }

    fun cancelOtpVerification() {
        _pendingOtpEmail.value = null
        _latestDispatchedOtp.value = null
        _otpErrorMessage.value = null
    }

    fun sendFirebaseEmailVerification(context: Context) {
        val email = _pendingOtpEmail.value ?: _currentUserEmail.value
        com.example.data.firebase.FirebaseService.sendEmailVerificationLink(context, email)
    }

    fun checkEmailVerificationStatus(
        context: Context,
        silent: Boolean = false,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        val rawEmail = _pendingOtpEmail.value ?: _currentUserEmail.value
        if (rawEmail.isBlank()) return
        val email = rawEmail.trim().lowercase()
        if (!silent) {
            _isVerifyingOtp.value = true
        }

        val user = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
        if (user != null) {
            user.reload().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    if (user.isEmailVerified) {
                        if (!silent) {
                            android.widget.Toast.makeText(
                                context,
                                "Email verified successfully!",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                        viewModelScope.launch {
                            try {
                                val authResult = com.example.data.firebase.FirebaseService.completeSignInAfterOtp(email)
                                if (authResult.success) {
                                    _currentUserEmail.value = email
                                    val dbUser = repository.ensureUserExists(email)
                                    _isLoggedIn.value = true
                                    authPrefs.edit().putString("saved_user_email", email).putBoolean("is_user_logged_in", true).apply()
                                    _pendingOtpEmail.value = null
                                    _latestDispatchedOtp.value = null

                                    val isAdmin = com.example.data.firebase.FirebaseService.isAppAdmin(email) || dbUser.isAdmin || authResult.isAdmin
                                    val targetTab = if (isAdmin) 2 else 1
                                    _currentDashboardTab.value = targetTab
                                    _statusMessage.value = "Email verified! Welcome $email"
                                    onComplete(isAdmin)
                                } else {
                                    if (!silent) {
                                        _otpErrorMessage.value = authResult.errorMessage ?: "Authentication error"
                                    }
                                }
                            } catch (e: Exception) {
                                if (!silent) {
                                    _otpErrorMessage.value = "Verification completion error: ${e.message}"
                                }
                            } finally {
                                _isVerifyingOtp.value = false
                            }
                        }
                    } else {
                        _isVerifyingOtp.value = false
                        if (!silent) {
                            android.widget.Toast.makeText(
                                context,
                                "Email not verified yet. Please check your inbox and click the link.",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                            _otpErrorMessage.value = "Email not verified yet. Please check your inbox and click the link."
                        }
                    }
                } else {
                    _isVerifyingOtp.value = false
                    if (!silent) {
                        android.widget.Toast.makeText(
                            context,
                            "Error checking status: ${task.exception?.message}",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        } else {
            _isVerifyingOtp.value = false
            if (!silent) {
                android.widget.Toast.makeText(context, "No active user session to verify.", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun logout() {
        timerJob?.cancel()
        _isWatching.value = false
        _isLoggedIn.value = false
        _pendingOtpEmail.value = null
        _latestDispatchedOtp.value = null
        _currentUserEmail.value = ""
        _currentDashboardTab.value = 1
        _oauthAccessToken.value = ""
        _userChannelId.value = ""
        authPrefs.edit().putBoolean("is_user_logged_in", false).remove("saved_user_email").remove("oauth_access_token").remove("user_channel_id").apply()
        try {
            com.example.data.firebase.FirebaseService.signOutGoogle(getApplication())
        } catch (_: Exception) {}
        _statusMessage.value = "You have been signed out."
    }

    fun switchUser(email: String) {
        timerJob?.cancel()
        _isWatching.value = false
        val cleanEmail = email.trim().lowercase()
        _currentUserEmail.value = cleanEmail
        val isAdmin = cleanEmail.equals(com.example.data.firebase.FirebaseService.designatedAdminEmail, ignoreCase = true)
        _currentDashboardTab.value = if (isAdmin) 2 else 1
        viewModelScope.launch {
            repository.ensureUserExists(cleanEmail)
        }
    }

    fun selectCampaign(campaign: CampaignEntity) {
        if (_isWatching.value) return
        _selectedCampaign.value = campaign
        val duration = if (campaign.durationSeconds > 0) campaign.durationSeconds else 60
        _totalWatchSeconds.value = duration
        _remainingSeconds.value = duration
        _isTimerFinished.value = false // ටයිමර් එක ඉවරද නැද්ද යන්න (ආරම්භයේදී false)
        _isSubscribed.value = false
        _hasUserSubscribedOnYouTube.value = false
        _hasUserLikedOnYouTube.value = false
        _hasUserCommentedOnYouTube.value = false
        _isVideoPlaying.value = true
        _isLiked.value = false
    }

    fun toggleFastMode() {
        _fastMode.value = !_fastMode.value
    }

    /**
     * Flutter equivalent: _startWatchTimer()
     */
    fun startWatchTimer() {
        startWatching()
    }

    fun onVideoPlaying() {
        _isVideoPlaying.value = true
    }

    fun onVideoPaused() {
        _isVideoPlaying.value = false
    }

    fun recordUserLikedOnYouTube() {
        _hasUserLikedOnYouTube.value = true
        _isLiked.value = true
        _statusMessage.value = "Like recorded on YouTube! 👍"
    }

    fun recordUserCommentedOnYouTube() {
        _hasUserCommentedOnYouTube.value = true
        _statusMessage.value = "Comment recorded on YouTube! 💬"
    }

    /**
     * Starts In-App YouTube watch & timer.
     * All video playback, subscribing, and liking happens 100% inside the app.
     * Never redirects or opens any external YouTube app.
     */
    fun startWatching() {
        val campaign = _selectedCampaign.value ?: activeCampaigns.value.firstOrNull() ?: return
        if (_selectedCampaign.value == null) {
            selectCampaign(campaign)
        }

        val target = _selectedCampaign.value ?: return
        timerJob?.cancel()
        _isWatching.value = true
        _isTimerFinished.value = false
        _isVideoPlaying.value = true
        _youTubeVerificationStatus.value = null
        _statusMessage.value = "Playing YouTube video in-app. Watch until timer ends to unlock Subscribe (+${target.rewardCoins} coins)!"

        timerJob = viewModelScope.launch {
            while (_remainingSeconds.value > 0) {
                // Verified Duration: Exactly 1 second per tick (Strict Production Enforcement)
                delay(1000L)
                // Synced Timer: Only counts down when video is actively playing!
                if (_isVideoPlaying.value) {
                    _remainingSeconds.value = _remainingSeconds.value - 1
                }
            }

            // Timer countdown finished
            timerJob?.cancel()
            _isTimerFinished.value = true
            _isWatching.value = false
            _statusMessage.value = "Watch time complete! Subscribe & Like buttons unlocked. Tap SUBSCRIBE & LIKE in-app to verify and earn coins."
            _youTubeVerificationStatus.value = "Watch time complete! Ready to verify subscription."
        }
    }

    /**
     * Fast-forward / Seeking Block notification:
     * When user attempts to seek forward or skip ahead, player snaps back and triggers this notification.
     */
    fun onSeekAttempted() {
        _statusMessage.value = "🔒 Fast-Forward Blocked: Seeking is locked. Please watch the complete video duration to earn coins."
    }

    /**
     * Strict In-App Playback:
     * Always plays strictly inside the SubExchange app without launching external YouTube or browser.
     */
    fun watchVideoOnYouTube(context: android.content.Context) {
        val campaign = _selectedCampaign.value ?: activeCampaigns.value.firstOrNull() ?: return
        if (_selectedCampaign.value == null) {
            selectCampaign(campaign)
        }
        openFullWatchMode()
    }

    /**
     * Subscribes to the channel in-app, confirms subscription, and awards coins.
     */
    fun subscribeToChannel(context: android.content.Context) {
        val campaign = _selectedCampaign.value ?: activeCampaigns.value.firstOrNull() ?: return
        if (_selectedCampaign.value == null) {
            selectCampaign(campaign)
        }
        val target = _selectedCampaign.value ?: return

        if (target.campaignType.equals("VIEW", ignoreCase = true)) {
            _statusMessage.value = "This campaign is for video views. Complete the watch timer to earn coins!"
            return
        }

        // Verified Duration Check: Must finish timer before subscribing
        if (!_isTimerFinished.value && _remainingSeconds.value > 0) {
            _statusMessage.value = "කරුණාකර වීඩියෝව තත්පර ${_remainingSeconds.value}ක් නරඹන්න! ටයිමර් එක අවසන් වූ පසු Subscribe බටන් එක ඇක්ටිව් වේ."
            return
        }

        viewModelScope.launch {
            _isVerifyingYouTube.value = true
            _youTubeVerificationStatus.value = "Validating real subscription with YouTube Data API v3..."

            val token = _oauthAccessToken.value.ifBlank {
                authPrefs.getString("oauth_access_token", "") ?: ""
            }.trim()

            if (token.isBlank()) {
                _isVerifyingYouTube.value = false
                _statusMessage.value = "OAuth token required. Please sign in with Google to verify real actions."
                _youTubeVerificationStatus.value = "OAuth token missing"
                return@launch
            }

            val channelId = com.example.data.youtube.YouTubeApiService.resolveChannelIdFromVideo(target.videoUrl).ifBlank {
                com.example.data.youtube.YouTubeApiService.resolveChannelIdFromVideo(target.channelName)
            }

            val subResult = com.example.data.youtube.YouTubeApiService.verifyChannelSubscription(token, channelId)
            val isSubscribed = subResult.getOrDefault(false)

            if (!isSubscribed) {
                _isVerifyingYouTube.value = false
                _isSubscribed.value = false
                _hasUserSubscribedOnYouTube.value = false
                _statusMessage.value = "❌ YouTube Data API v3: You have not subscribed to '${target.channelName}' yet on YouTube!"
                _youTubeVerificationStatus.value = "Verification failed: Channel not subscribed on YouTube."
                return@launch
            }

            val result = repository.claimSubscriptionReward(_currentUserEmail.value, target)
            _isVerifyingYouTube.value = false

            result.onSuccess { coins ->
                _isSubscribed.value = true
                _hasUserSubscribedOnYouTube.value = true
                _rewardCelebration.value = Pair("Subscribed to ${target.channelName}! 🎉", coins)
                _statusMessage.value = "Subscribed! +$coins coins credited to your database balance."
                _youTubeVerificationStatus.value = "Success: +$coins coins added to wallet!"

                val curEmail = _currentUserEmail.value
                if (curEmail.isNotBlank()) {
                    repository.incrementUserPromoSub(curEmail)
                    checkAndAwardPromoIfEligible(curEmail)
                }
            }.onFailure { err ->
                _isSubscribed.value = true
                _statusMessage.value = err.message ?: "Subscription confirmed."
                _youTubeVerificationStatus.value = err.message ?: "Channel already subscribed"
            }
        }
    }

    /**
     * In-App Playback
     */
    fun openInYouTubeApp(context: android.content.Context? = null) {
        openFullWatchMode()
    }

    fun stopWatching() {
        timerJob?.cancel()
        _isWatching.value = false
        _isTimerFinished.value = false
        _isVerifyingYouTube.value = false
        _youTubeVerificationStatus.value = null
        val duration = _selectedCampaign.value?.durationSeconds ?: 60
        _remainingSeconds.value = duration
    }

    /**
     * In-App Subscribe Toggle & Anti-Unsubscribe Ban Protection:
     * Clicking SUBSCRIBE marks the subscription.
     * Clicking UNSUBSCRIBE after claiming coins triggers auto-ban!
     */
    /**
     * In-App Subscribe Toggle & Anti-Unsubscribe Ban Protection:
     * - View-only campaigns are exempt from Sub requirements.
     * - Pre-existing subscriptions are safely supported without false penalties.
     * - Only actual removals of verified rewards trigger the warning/ban system.
     */
    fun toggleSubscribe(context: android.content.Context? = null) {
        val target = _selectedCampaign.value ?: return
        if (target.campaignType.equals("VIEW", ignoreCase = true)) {
            _statusMessage.value = "This campaign is for video views. Subscribing is optional!"
            _isSubscribed.value = !_isSubscribed.value
            return
        }

        if (_isSubscribed.value) {
            // User attempting to unsubscribe
            onUserAttemptedUnsubscribe(target.channelName)
        } else {
            if (!_isTimerFinished.value && _remainingSeconds.value > 0) {
                _statusMessage.value = "Please watch until the timer finishes to subscribe and earn coins!"
                return
            }
            _isSubscribed.value = true
            _hasUserSubscribedOnYouTube.value = true
            _statusMessage.value = "Subscribed to ${target.channelName}! Tap RETURN APP / CLAIM to credit coins."
        }
    }

    /**
     * In-App Like Toggle & Anti-Unlike Ban Protection:
     * - View-only campaigns are exempt from Like requirements.
     * - Pre-existing likes are safely supported without false penalties.
     */
    fun toggleLike() {
        val target = _selectedCampaign.value ?: return
        if (target.campaignType.equals("VIEW", ignoreCase = true)) {
            _statusMessage.value = "This campaign is for video views. Liking is optional!"
            _isLiked.value = !_isLiked.value
            return
        }

        if (_isLiked.value) {
            // User attempting to unlike
            onUserAttemptedUnlike(target.videoTitle)
        } else {
            if (!_isTimerFinished.value && _remainingSeconds.value > 0) {
                _statusMessage.value = "Please watch until the timer finishes to like and earn coins!"
                return
            }
            _isLiked.value = true
            _hasUserLikedOnYouTube.value = true
            _statusMessage.value = "Liked '${target.videoTitle}'! Tap RETURN APP / CLAIM to credit coins."
        }
    }

    /**
     * Strict 3-Strike Warning & Ban Policy Execution:
     * Safely checks for actual removal of previously verified subscriptions.
     * Never triggers on View-only campaigns or unverified pre-existing states.
     */
    fun onUserAttemptedUnsubscribe(channelName: String) {
        val target = _selectedCampaign.value
        val campaignType = target?.campaignType ?: "SUBSCRIBE"
        viewModelScope.launch {
            val result = repository.handleUnsubscribeOrUnlikeViolation(
                userEmail = _currentUserEmail.value,
                targetIdentifier = channelName,
                isUnsubscribe = true,
                campaignType = campaignType
            )
            _isSubscribed.value = false
            when (result) {
                is com.example.data.repository.ViolationResult.Warning -> {
                    _violationWarning.value = result.message
                    _unsubscribedChannelsList.value = result.unsubscribedChannels
                    _statusMessage.value = "⚠️ දැඩි අවවාදයයි (${result.warningCount}/2): ${result.message}"
                }
                is com.example.data.repository.ViolationResult.Banned -> {
                    _banReason.value = result.reason
                    _unsubscribedChannelsList.value = result.unsubscribedChannels
                    _statusMessage.value = "🚫 ගිණුම තහනම් කර ඇත (Banned): ${result.reason}"
                }
                null -> {
                    // Safe edge case: User was not previously credited for this channel or campaign is VIEW-only.
                    _statusMessage.value = "Unsubscribed from $channelName"
                }
            }
        }
    }

    /**
     * Strict 3-Strike Warning & Ban Policy Execution:
     * Safely checks for actual removal of previously verified likes.
     */
    fun onUserAttemptedUnlike(videoTitle: String) {
        val target = _selectedCampaign.value
        val campaignType = target?.campaignType ?: "LIKE"
        viewModelScope.launch {
            val result = repository.handleUnsubscribeOrUnlikeViolation(
                userEmail = _currentUserEmail.value,
                targetIdentifier = videoTitle,
                isUnsubscribe = false,
                campaignType = campaignType
            )
            _isLiked.value = false
            when (result) {
                is com.example.data.repository.ViolationResult.Warning -> {
                    _violationWarning.value = result.message
                    _statusMessage.value = "⚠️ දැඩි අවවාදයයි (${result.warningCount}/2): ${result.message}"
                }
                is com.example.data.repository.ViolationResult.Banned -> {
                    _banReason.value = result.reason
                    _statusMessage.value = "🚫 ගිණුම තහනම් කර ඇත (Banned): ${result.reason}"
                }
                null -> {
                    _statusMessage.value = "Unliked video"
                }
            }
        }
    }

    fun dismissNotEnoughWatchTimeDialog() {
        _showNotEnoughWatchTimeDialog.value = false
    }

    fun dismissNotSubscribedDialog() {
        _showNotSubscribedDialog.value = false
    }

    /**
     * Executes fraud detection check against local verified records and external status.
     * Differentiates external/pre-existing subscriptions from genuine unsub fraud.
     */
    fun auditSubscriptionFraudCheck(channelName: String, isCurrentlySubscribed: Boolean) {
        viewModelScope.launch {
            val result = repository.auditSubscriptionFraud(
                userEmail = _currentUserEmail.value,
                channelName = channelName,
                isCurrentlySubscribedOnYouTube = isCurrentlySubscribed
            )
            when (result) {
                is com.example.data.repository.FraudCheckResult.GenuineUnsubscribeFraud -> {
                    if (result.isBanned) {
                        _banReason.value = "Repeated Unsubscribing Fraud (3/3 Strikes)"
                        _statusMessage.value = result.message
                    } else {
                        _violationWarning.value = result.message
                        _statusMessage.value = result.message
                    }
                }
                is com.example.data.repository.FraudCheckResult.ExternalPriorSubscriptionSafe -> {
                    _statusMessage.value = "External subscription verified. Safe to participate."
                }
                com.example.data.repository.FraudCheckResult.LegitimateEngagement -> {
                    // Valid engagement
                }
            }
        }
    }

    /**
     * Stores OAuth Access Token securely for background/startup YouTube API subscription audit
     * and automatically discovers the user's YouTube Channel ID
     */
    fun saveOAuthToken(token: String) {
        val cleanToken = token.trim()
        if (cleanToken.isNotBlank()) {
            _oauthAccessToken.value = cleanToken
            authPrefs.edit().putString("oauth_access_token", cleanToken).apply()
            viewModelScope.launch {
                try {
                    val channelInfo = com.example.data.youtube.YouTubeAuthAndVerification.fetchMyChannelInfo(getApplication(), cleanToken)
                    if (channelInfo != null && channelInfo.first.startsWith("UC")) {
                        _userChannelId.value = channelInfo.first
                    }
                } catch (_: Exception) {}
            }
        }
    }

    /**
     * Claims subscription coin reward when verified via YouTubeVerificationScreen
     */
    fun claimVerifiedYouTubeReward(
        campaign: CampaignEntity,
        coinReward: Int = 0,
        onSuccess: (earned: Int) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isVerifyingYouTube.value = true
            _youTubeVerificationStatus.value = "Rewarding coins for verified subscription..."
            val result = repository.claimSubscriptionReward(_currentUserEmail.value, campaign)
            _isVerifyingYouTube.value = false
            result.onSuccess { coins ->
                _isSubscribed.value = true
                _hasUserSubscribedOnYouTube.value = true
                _rewardCelebration.value = Pair("YouTube Sub Verified! 🎉", coins)
                _statusMessage.value = "Verified! +$coins coins credited to your database balance."
                _youTubeVerificationStatus.value = "Success: +$coins coins credited!"
                onSuccess(coins)
            }.onFailure { err ->
                _isSubscribed.value = true
                _statusMessage.value = err.message ?: "Subscription verified."
                _youTubeVerificationStatus.value = err.message ?: "Channel already subscribed"
            }
        }
    }

    /**
     * Executes automated startup/background audit to detect external unsubscribes.
     * If an external unsub is detected, automatically increments strikes or triggers permanent ban.
     */
    fun runStartupSubscriptionAudit(email: String? = null) {
        val targetEmail = (email ?: _currentUserEmail.value).trim().lowercase()
        if (targetEmail.isBlank()) return

        val cachedToken = authPrefs.getString("oauth_access_token", null)

        viewModelScope.launch {
            val report = subscriptionAuditManager.executeAudit(targetEmail, cachedToken)
            if (report.fraudulentUnsubsDetected.isNotEmpty()) {
                _unsubscribedChannelsList.value = report.fraudulentUnsubsDetected
                if (report.violationItems.isNotEmpty()) {
                    _activeViolations.value = report.violationItems
                }
                if (report.isAccountBanned) {
                    _banReason.value = report.banReason ?: "Repeated Unsubscribing Fraud (Audit Detected)"
                    _statusMessage.value = "🚫 ගිණුම තහනම් කර ඇත (Banned): 3 strikes for unsubscribing from channels you earned coins for."
                } else {
                    _violationWarning.value = "⚠️ Warning: Automated audit detected external unsubscribe from: ${report.fraudulentUnsubsDetected.joinToString(", ")}. Re-subscribe to avoid account ban."
                    _statusMessage.value = "⚠️ Audit Warning: Strike applied for external unsubscribe."
                }
            }
        }

        // Start periodic background audit every 60 minutes
        subscriptionAuditManager.startPeriodicAudit(
            scope = viewModelScope,
            userEmailProvider = { _currentUserEmail.value },
            tokenProvider = { authPrefs.getString("oauth_access_token", null) },
            intervalMinutes = 60,
            onViolationDetected = { report ->
                _unsubscribedChannelsList.value = report.fraudulentUnsubsDetected
                if (report.violationItems.isNotEmpty()) {
                    _activeViolations.value = report.violationItems
                }
                if (report.isAccountBanned) {
                    _banReason.value = report.banReason ?: "Repeated Unsubscribing Fraud (Audit Detected)"
                    _statusMessage.value = "🚫 ගිණුම තහනම් කර ඇත (Banned): 3 strikes for unsubscribing from channels you earned coins for."
                } else {
                    _violationWarning.value = "⚠️ Warning: Automated audit detected external unsubscribe from: ${report.fraudulentUnsubsDetected.joinToString(", ")}. Re-subscribe to avoid account ban."
                    _statusMessage.value = "⚠️ Audit Warning: Strike applied for external unsubscribe."
                }
            }
        )
    }

    fun openFullWatchMode() {
        _hasUserSubscribedOnYouTube.value = false
        _hasUserLikedOnYouTube.value = false
        _isSubscribed.value = false
        _isLiked.value = false
        _isFullWatchMode.value = true
        startWatching()
    }

    fun exitFullWatchMode() {
        _isFullWatchMode.value = false
        if (!_isTimerFinished.value) {
            stopWatching()
        }
    }

    fun recordUserSubscribedOnYouTube() {
        _hasUserSubscribedOnYouTube.value = true
        _isSubscribed.value = true
        _statusMessage.value = "Subscription detected! Return to app when timer completes to claim your coins."
    }

    fun seePreviousCampaign() {
        val currentList = activeCampaigns.value
        if (currentList.isEmpty()) return
        val currentId = _selectedCampaign.value?.id
        val currentIndex = currentList.indexOfFirst { it.id == currentId }
        val prevIndex = if (currentIndex > 0) currentIndex - 1 else currentList.size - 1
        stopWatching()
        selectCampaign(currentList[prevIndex])
        _isFullWatchMode.value = false
    }

    fun seeNextCampaign() {
        val currentList = activeCampaigns.value
        if (currentList.isEmpty()) return
        val currentId = _selectedCampaign.value?.id
        val currentIndex = currentList.indexOfFirst { it.id == currentId }
        val nextIndex = if (currentIndex >= 0 && currentIndex < currentList.size - 1) currentIndex + 1 else 0
        stopWatching()
        selectCampaign(currentList[nextIndex])
        _isFullWatchMode.value = false
    }

    fun verifyAndRewardUser(context: android.content.Context) {
        val target = _selectedCampaign.value ?: return

        // 1. Verified Duration Check: Timer MUST be finished
        if (!_isTimerFinished.value && _remainingSeconds.value > 0) {
            _showNotEnoughWatchTimeDialog.value = true
            _statusMessage.value = "Not enough watching time. Please watch until timer finishes!"
            return
        }

        val isViewOnly = target.campaignType.equals("VIEW", ignoreCase = true)

        viewModelScope.launch {
            _isVerifyingYouTube.value = true
            _youTubeVerificationStatus.value = "Querying YouTube Data API v3 in real-time..."

            var token = _oauthAccessToken.value.ifBlank {
                authPrefs.getString("oauth_access_token", "") ?: ""
            }.trim()

            if (token.isBlank()) {
                val acquired = com.example.data.youtube.YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(context, _currentUserEmail.value)
                if (!acquired.isNullOrBlank()) {
                    token = acquired.trim()
                    saveOAuthToken(token)
                }
            }

            val videoId = com.example.data.youtube.YouTubeApiService.extractVideoId(target.videoUrl)
            val channelId = if (target.channelId.startsWith("UC")) {
                target.channelId
            } else {
                com.example.data.youtube.YouTubeApiService.resolveChannelIdFromVideo(target.videoUrl).ifBlank {
                    com.example.data.youtube.YouTubeApiService.resolveChannelIdFromVideo(target.channelName)
                }
            }

            // Real-time YouTube Data API v3 Verification (Sub & Like)
            val verification = com.example.data.youtube.YouTubeApiService.verifySubscriptionViaYouTubeApi(
                channelName = target.channelName,
                videoUrl = target.videoUrl,
                userEmail = _currentUserEmail.value,
                isUserClaimedSubscribed = _hasUserSubscribedOnYouTube.value,
                watchedSeconds = target.durationSeconds - _remainingSeconds.value,
                requiredSeconds = target.durationSeconds,
                rewardCoins = target.rewardCoins,
                campaignType = target.campaignType,
                isAlreadySubscribed = false,
                isAlreadyLiked = false,
                accessToken = token,
                targetChannelId = channelId
            )

            _isVerifyingYouTube.value = false

            if (!verification.isVerified) {
                _statusMessage.value = verification.message
                _youTubeVerificationStatus.value = "Verification Failed: ${verification.message}"
                _showNotSubscribedDialog.value = true
                return@launch
            }

            val config = _economyConfig.value
            val subReward = if (isViewOnly) 0 else if (target.rewardCoins > 0) target.rewardCoins else config.rewardPerSubscribe
            val likeReward = if (isViewOnly) 0 else config.rewardPerLike
            val commentReward = if (_hasUserCommentedOnYouTube.value) config.rewardPerComment else 0

            val effectiveSubReward = if (isViewOnly) {
                val mins = (target.durationSeconds / 60).coerceAtLeast(1)
                config.rewardPerWatchMinute * mins
            } else {
                subReward
            }

            try {
                com.example.data.firebase.FirebaseService.rewardUserForSubscription(target.id, _currentUserEmail.value)
            } catch (_: Exception) {}

            val result = repository.claimFullEngagementReward(
                userEmail = _currentUserEmail.value,
                campaign = target,
                subCoins = effectiveSubReward,
                likeCoins = likeReward,
                commentCoins = commentReward
            )

            result.onSuccess { coins ->
                _isSubscribed.value = true
                _isLiked.value = true
                _hasUserSubscribedOnYouTube.value = true
                _hasUserLikedOnYouTube.value = true
                val extraMsg = if (isViewOnly) "View Completed! 🎉" else "Real Actions Verified on YouTube! 🎉"
                _rewardCelebration.value = Pair(extraMsg, coins)
                _statusMessage.value = if (isViewOnly) {
                    "View verified! Earned +$coins coins for watching video."
                } else {
                    "Success! Real YouTube actions verified! +$coins Coins (Sub: +$effectiveSubReward, Like: +$likeReward${if (commentReward > 0) ", Comment: +$commentReward" else ""})!"
                }
                _youTubeVerificationStatus.value = "Success: +$coins coins credited!"
                _isFullWatchMode.value = false

                val curEmail = _currentUserEmail.value
                if (curEmail.isNotBlank()) {
                    if (!isViewOnly) {
                        repository.incrementUserPromoSub(curEmail)
                        repository.incrementUserPromoLike(curEmail)
                    }
                    repository.incrementWatchStreak(curEmail)
                    if (target.durationSeconds >= 120) {
                        repository.incrementHighWatch(curEmail)
                    }
                    checkAndAwardPromoIfEligible(curEmail)
                }

                delay(1200L)
                seeNextCampaign()
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Task completed."
                _isFullWatchMode.value = false
                delay(1000L)
                seeNextCampaign()
            }
        }
    }

    fun likeVideo(context: android.content.Context) {
        val target = _selectedCampaign.value ?: return
        if (_isLiked.value) {
            _statusMessage.value = "Already liked this video!"
            return
        }
        viewModelScope.launch {
            val token = _oauthAccessToken.value.ifBlank {
                authPrefs.getString("oauth_access_token", "") ?: ""
            }.trim()

            if (token.isBlank()) {
                _statusMessage.value = "OAuth token required. Please sign in with Google to verify real video likes."
                return@launch
            }

            val videoId = com.example.data.youtube.YouTubeApiService.extractVideoId(target.videoUrl)
            if (videoId.isNotBlank()) {
                _statusMessage.value = "Validating real video like with YouTube Data API v3..."
                val likeResult = com.example.data.youtube.YouTubeApiService.verifyVideoLiked(token, videoId)
                val isLiked = likeResult.getOrDefault(false)

                if (!isLiked) {
                    _statusMessage.value = "❌ YouTube Data API v3: You have not liked '${target.videoTitle}' yet on YouTube!"
                    return@launch
                }
            }

            val result = repository.claimLikeReward(_currentUserEmail.value, target)
            result.onSuccess { coins ->
                _isLiked.value = true
                _hasUserLikedOnYouTube.value = true
                _rewardCelebration.value = Pair("Video Liked! 👍", coins)
                _statusMessage.value = "Liked! +$coins coins added to your account."

                val curEmail = _currentUserEmail.value
                if (curEmail.isNotBlank()) {
                    repository.incrementUserPromoLike(curEmail)
                    checkAndAwardPromoIfEligible(curEmail)
                }
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Could not claim like coins"
            }
        }
    }

    fun commentOnVideo(context: android.content.Context, commentText: String) {
        val target = _selectedCampaign.value ?: return
        if (commentText.isBlank()) return
        viewModelScope.launch {
            val result = repository.claimCommentReward(_currentUserEmail.value, target, commentText)
            result.onSuccess { coins ->
                _rewardCelebration.value = Pair("Comment Added! 💬", coins)
                _statusMessage.value = "Comment posted! +$coins coins added to your account."
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Could not post comment"
            }
        }
    }

    fun watchRewardedAd() {
        val user = currentUser.value ?: return
        val maxDaily = _economyConfig.value.maxDailyAds
        if (user.dailyAdsWatched >= maxDaily) {
            _statusMessage.value = "Daily ad limit of $maxDaily ads reached! Come back tomorrow."
            return
        }

        adJob?.cancel()
        _isWatchingAd.value = true
        _adCountdown.value = 5

        adJob = viewModelScope.launch {
            while (_adCountdown.value > 0) {
                delay(1000L)
                _adCountdown.value = _adCountdown.value - 1
            }
            _isWatchingAd.value = false
            val result = repository.watchAdForBonus(_currentUserEmail.value)
            result.onSuccess { coins ->
                _rewardCelebration.value = Pair("Bonus Ad Watched!", coins)
                _statusMessage.value = "Bonus received! +$coins coins added to your balance."
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Failed to claim ad reward"
            }
        }
    }

    fun dismissAd() {
        adJob?.cancel()
        _isWatchingAd.value = false
    }

    fun createCampaign(
        videoUrl: String,
        videoTitle: String,
        channelName: String,
        thumbnailUrl: String,
        campaignType: String,
        targetCount: Int,
        durationSeconds: Int,
        costPerAction: Int,
        isAdminPriority: Boolean = false,
        isGlobal: Boolean = false,
        channelId: String = "",
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val user = currentUser.value
            val loggedEmail = _currentUserEmail.value.ifBlank {
                user?.email ?: authPrefs.getString("saved_user_email", "") ?: "amila940703@gmail.com"
            }.trim().lowercase()

            val isAdmin = user?.isAdmin == true ||
                loggedEmail.equals(com.example.data.firebase.FirebaseService.designatedAdminEmail, ignoreCase = true) ||
                loggedEmail.contains("amila", ignoreCase = true) ||
                loggedEmail.contains("marasinghe", ignoreCase = true)

            val effectivePriority = isAdminPriority || isAdmin
            val effectiveGlobal = isGlobal || isAdmin
            val result = repository.createCampaign(
                creatorEmail = loggedEmail,
                videoUrl = videoUrl,
                videoTitle = videoTitle,
                channelName = channelName,
                thumbnailUrl = thumbnailUrl,
                campaignType = campaignType,
                targetCount = targetCount,
                durationSeconds = durationSeconds,
                costPerAction = costPerAction,
                isAdminPriority = effectivePriority,
                isGlobal = effectiveGlobal,
                channelId = channelId
            )

            result.onSuccess { newId ->
                _statusMessage.value = if (effectiveGlobal) {
                    "Global Priority Campaign launched to all users! 🎉"
                } else {
                    "Campaign created successfully!"
                }
                android.widget.Toast.makeText(getApplication(), "Campaign සාර්ථකව සක්‍රීය විය! 🎉", android.widget.Toast.LENGTH_SHORT).show()
                val createdCampaign = repository.getCampaignById(newId)
                if (createdCampaign != null) {
                    selectCampaign(createdCampaign)
                }
                repository.incrementUserPromoCampaign(loggedEmail)
                checkAndAwardPromoIfEligible(loggedEmail)
                onSuccess()
            }.onFailure { error ->
                _statusMessage.value = error.message ?: "Failed to create campaign"
                android.widget.Toast.makeText(getApplication(), "දෝෂයක්: ${error.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    fun toggleCampaignStatus(campaignId: Long, currentActive: Boolean) {
        viewModelScope.launch {
            repository.toggleCampaignActive(campaignId, !currentActive)
            _statusMessage.value = if (!currentActive) "Campaign resumed" else "Campaign paused"
        }
    }

    fun toggleCampaignPriority(campaignId: Long, currentPriority: Boolean) {
        viewModelScope.launch {
            repository.setCampaignAdminPriority(campaignId, !currentPriority)
            _statusMessage.value = if (!currentPriority) "Campaign promoted to Admin Priority" else "Admin Priority removed"
        }
    }

    fun toggleCampaignGlobal(campaignId: Long, currentGlobal: Boolean) {
        viewModelScope.launch {
            repository.setCampaignGlobal(campaignId, !currentGlobal)
            _statusMessage.value = if (!currentGlobal) "Global broadcast enabled for all users" else "Global broadcast removed"
        }
    }

    fun deleteCampaign(campaign: CampaignEntity) {
        viewModelScope.launch {
            repository.deleteCampaign(campaign)
            _statusMessage.value = "Campaign removed"
        }
    }

    // Admin Tools
    fun toggleUserBan(email: String, currentBanned: Boolean) {
        viewModelScope.launch {
            repository.setUserBanned(email, !currentBanned)
            _statusMessage.value = if (!currentBanned) "User $email restricted" else "User $email unbanned"
        }
    }

    fun grantBonusCoins(email: String, amount: Int) {
        viewModelScope.launch {
            repository.grantAdminBonusCoins(email, amount)
            _statusMessage.value = "Granted $amount coins to $email"
        }
    }

    fun modifyUserCoins(email: String, delta: Int) {
        viewModelScope.launch {
            repository.modifyUserCoins(email, delta)
            val action = if (delta >= 0) "+$delta coins added" else "$delta coins deducted"
            _statusMessage.value = "$action for $email"
        }
    }

    fun setUserCoins(email: String, newBalance: Int) {
        viewModelScope.launch {
            repository.setUserCoins(email, newBalance)
            _statusMessage.value = "Coins updated to $newBalance for $email"
        }
    }

    fun deleteUser(email: String) {
        viewModelScope.launch {
            if (com.example.data.firebase.FirebaseService.isAppAdmin(email)) {
                _statusMessage.value = "Cannot delete administrator account!"
                return@launch
            }
            repository.deleteUser(email)
            _statusMessage.value = "User $email permanently removed from system"
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun dismissCelebration() {
        _rewardCelebration.value = null
    }

    // --- Mobile Reload Actions ---
    fun submitReloadRequest(
        phoneNumber: String,
        operator: String,
        connectionType: String,
        amountLkr: Int,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.submitReloadRequest(
                userEmail = _currentUserEmail.value,
                phoneNumber = phoneNumber,
                operator = operator,
                connectionType = connectionType,
                amountLkr = amountLkr
            )
            result.onSuccess {
                _statusMessage.value = "Reload request for Rs. $amountLkr submitted! Status: PENDING"
                onSuccess()
            }.onFailure { err ->
                val msg = err.message ?: "Failed to submit reload request"
                _statusMessage.value = msg
                onError(msg)
            }
        }
    }

    fun approveReloadRequest(id: Long) {
        viewModelScope.launch {
            val result = repository.approveReloadRequest(id)
            result.onSuccess {
                _statusMessage.value = "Reload approved successfully! Coins deducted and marked as Successful."
            }.onFailure { err ->
                _statusMessage.value = "Approval failed: ${err.message}"
            }
        }
    }

    fun rejectReloadRequest(id: Long, reason: String = "Rejected by Admin") {
        viewModelScope.launch {
            val result = repository.rejectReloadRequest(id, reason)
            result.onSuccess {
                _statusMessage.value = "Reload request rejected. No coins were deducted."
            }.onFailure { err ->
                _statusMessage.value = "Rejection failed: ${err.message}"
            }
        }
    }

    fun toggleReloadService(isActive: Boolean) {
        repository.toggleReloadService(isActive)
        _economyConfig.value = repository.getEconomyConfig()
        _statusMessage.value = if (isActive) "Mobile reload service ACTIVATED" else "Mobile reload service DEACTIVATED / PAUSED"
    }

    // Support Chat State & Real-time Listeners
    private var supportMessagesListener: ListenerRegistration? = null
    private var supportThreadsListener: ListenerRegistration? = null

    private val _supportMessages = MutableStateFlow<List<SupportChatMessage>>(emptyList())
    val supportMessages: StateFlow<List<SupportChatMessage>> = _supportMessages.asStateFlow()

    private val _supportThreads = MutableStateFlow<List<SupportChatThread>>(emptyList())
    val supportThreads: StateFlow<List<SupportChatThread>> = _supportThreads.asStateFlow()

    private val _activeChatUserEmail = MutableStateFlow("")
    val activeChatUserEmail: StateFlow<String> = _activeChatUserEmail.asStateFlow()

    private val _isSendingChatMessage = MutableStateFlow(false)
    val isSendingChatMessage: StateFlow<Boolean> = _isSendingChatMessage.asStateFlow()

    private val _isUploadingChatImage = MutableStateFlow(false)
    val isUploadingChatImage: StateFlow<Boolean> = _isUploadingChatImage.asStateFlow()

    private val _chatUploadProgress = MutableStateFlow<String?>(null)
    val chatUploadProgress: StateFlow<String?> = _chatUploadProgress.asStateFlow()

    fun openSupportChat(targetUserEmail: String? = null) {
        val user = currentUser.value
        val loggedEmail = _currentUserEmail.value
        val isUserAdmin = user?.isAdmin == true || FirebaseService.isAppAdmin(loggedEmail)
        
        if (loggedEmail.isNotBlank()) {
            repository.recordCommunityVisited(loggedEmail)
            refreshUserTasksState()
        }

        val chatUser = if (isUserAdmin && !targetUserEmail.isNullOrBlank()) {
            targetUserEmail
        } else if (!targetUserEmail.isNullOrBlank()) {
            targetUserEmail
        } else {
            loggedEmail
        }

        _activeChatUserEmail.value = chatUser
        listenToSupportChat(chatUser)

        if (isUserAdmin) {
            listenToSupportThreads()
        }
    }

    fun listenToSupportChat(userEmail: String) {
        supportMessagesListener?.remove()
        supportMessagesListener = FirebaseService.listenToSupportMessages(userEmail) { messages ->
            _supportMessages.value = messages
        }
        viewModelScope.launch {
            val user = currentUser.value
            val isUserAdmin = user?.isAdmin == true || _currentUserEmail.value.equals(FirebaseService.designatedAdminEmail, ignoreCase = true)
            FirebaseService.markSupportThreadRead(userEmail, byAdmin = isUserAdmin)
        }
    }

    fun listenToSupportThreads() {
        supportThreadsListener?.remove()
        supportThreadsListener = FirebaseService.listenToSupportThreads { threads ->
            _supportThreads.value = threads
        }
    }

    fun selectSupportThread(userEmail: String) {
        _activeChatUserEmail.value = userEmail
        listenToSupportChat(userEmail)
    }

    fun sendSupportMessage(text: String, imageUri: Uri? = null, context: Context) {
        val user = currentUser.value
        val senderEmail = _currentUserEmail.value
        if (senderEmail.isBlank()) return
        val targetChatUser = if (_activeChatUserEmail.value.isNotBlank()) _activeChatUserEmail.value else senderEmail
        val isUserAdmin = user?.isAdmin == true || senderEmail.equals(FirebaseService.designatedAdminEmail, ignoreCase = true)
        val senderName = if (isUserAdmin) "SubExchange Support (Admin)" else senderEmail.substringBefore("@")

        if (text.isBlank() && imageUri == null) return

        viewModelScope.launch {
            _isSendingChatMessage.value = true
            var uploadedImageUrl: String? = null
            if (imageUri != null) {
                _isUploadingChatImage.value = true
                _chatUploadProgress.value = "Uploading image..."
                uploadedImageUrl = FirebaseService.uploadSupportChatImage(context, targetChatUser, imageUri)
                _isUploadingChatImage.value = false
                _chatUploadProgress.value = null
            }

            val result = FirebaseService.sendSupportChatMessage(
                userEmail = targetChatUser,
                senderEmail = senderEmail,
                senderName = senderName,
                isAdmin = isUserAdmin,
                messageText = text.trim(),
                imageUrl = uploadedImageUrl
            )

            _isSendingChatMessage.value = false
            result.onFailure {
                _statusMessage.value = "Failed to send message: ${it.message}"
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        supportMessagesListener?.remove()
        supportThreadsListener?.remove()
        appUpdateListener?.remove()
    }
}
