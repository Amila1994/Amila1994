package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SubExchangeDatabase
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WatchHistoryEntity
import com.example.data.repository.SubExchangeRepository
import com.example.data.model.AdminEconomyConfig
import com.example.data.model.AppUpdateConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SubExchangeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SubExchangeDatabase.getDatabase(application)
    private val repository = SubExchangeRepository(db.userDao(), db.campaignDao(), db.watchHistoryDao(), db.reloadRequestDao(), application)
    private val authPrefs = application.getSharedPreferences("subexchange_auth_prefs", android.content.Context.MODE_PRIVATE)

    private val _currentUserEmail = MutableStateFlow("amilalasantha940703@gmail.com")
    val currentUserEmail: StateFlow<String> = _currentUserEmail.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    private val _pendingOtpEmail = MutableStateFlow<String?>(null)
    val pendingOtpEmail: StateFlow<String?> = _pendingOtpEmail.asStateFlow()

    private val _latestDispatchedOtp = MutableStateFlow<String?>(null)
    val latestDispatchedOtp: StateFlow<String?> = _latestDispatchedOtp.asStateFlow()

    private val _isVerifyingOtp = MutableStateFlow(false)
    val isVerifyingOtp: StateFlow<Boolean> = _isVerifyingOtp.asStateFlow()

    private val _otpErrorMessage = MutableStateFlow<String?>(null)
    val otpErrorMessage: StateFlow<String?> = _otpErrorMessage.asStateFlow()

    val currentUser: StateFlow<UserEntity?> = _currentUserEmail.flatMapLatest { email ->
        repository.getUser(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allReloadRequests: StateFlow<List<com.example.data.local.entity.ReloadRequestEntity>> =
        repository.getAllReloadRequests().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userReloadRequests: StateFlow<List<com.example.data.local.entity.ReloadRequestEntity>> =
        _currentUserEmail.flatMapLatest { email ->
            repository.getReloadRequestsForUser(email)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingReloadCount: StateFlow<Int> =
        repository.getPendingReloadCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Filter out campaigns the user has already liked/commented/subscribed to!
    val activeCampaigns: StateFlow<List<CampaignEntity>> = combine(
        repository.getActiveCampaigns(),
        _currentUserEmail.flatMapLatest { email -> repository.getCompletedCampaignIds(email) }
    ) { campaigns, completedIds ->
        val completedSet = completedIds.toSet()
        campaigns.filter { campaign ->
            !completedSet.contains(campaign.id)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userCampaigns: StateFlow<List<CampaignEntity>> = _currentUserEmail.flatMapLatest { email ->
        repository.getCampaignsByCreator(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCampaigns: StateFlow<List<CampaignEntity>> =
        repository.getAllCampaigns().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<UserEntity>> =
        repository.getAllUsers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchHistory: StateFlow<List<WatchHistoryEntity>> = _currentUserEmail.flatMapLatest { email ->
        repository.getWatchHistory(email)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Video Player & Timer State
    private val _selectedCampaign = MutableStateFlow<CampaignEntity?>(null)
    val selectedCampaign: StateFlow<CampaignEntity?> = _selectedCampaign.asStateFlow()

    private val _isWatching = MutableStateFlow(false)
    val isWatching: StateFlow<Boolean> = _isWatching.asStateFlow()

    private val _remainingSeconds = MutableStateFlow(60) // වීඩියෝ කාලය (උදා: තත්පර 60ක් නම්)
    val remainingSeconds: StateFlow<Int> = _remainingSeconds.asStateFlow()

    private val _totalWatchSeconds = MutableStateFlow(60)
    val totalWatchSeconds: StateFlow<Int> = _totalWatchSeconds.asStateFlow()

    private val _isTimerFinished = MutableStateFlow(false) // ටයිමර් එක ඉවරද නැද්ද යන්න
    val isTimerFinished: StateFlow<Boolean> = _isTimerFinished.asStateFlow()

    private val _isSubscribed = MutableStateFlow(false)
    val isSubscribed: StateFlow<Boolean> = _isSubscribed.asStateFlow()

    private val _hasUserSubscribedOnYouTube = MutableStateFlow(false)
    val hasUserSubscribedOnYouTube: StateFlow<Boolean> = _hasUserSubscribedOnYouTube.asStateFlow()

    private val _hasUserLikedOnYouTube = MutableStateFlow(false)
    val hasUserLikedOnYouTube: StateFlow<Boolean> = _hasUserLikedOnYouTube.asStateFlow()

    private val _hasUserCommentedOnYouTube = MutableStateFlow(false)
    val hasUserCommentedOnYouTube: StateFlow<Boolean> = _hasUserCommentedOnYouTube.asStateFlow()

    private val _isVideoPlaying = MutableStateFlow(true)
    val isVideoPlaying: StateFlow<Boolean> = _isVideoPlaying.asStateFlow()

    private val _isFullWatchMode = MutableStateFlow(false)
    val isFullWatchMode: StateFlow<Boolean> = _isFullWatchMode.asStateFlow()

    private val _isLiked = MutableStateFlow(false)
    val isLiked: StateFlow<Boolean> = _isLiked.asStateFlow()

    private val _isVerifyingYouTube = MutableStateFlow(false)
    val isVerifyingYouTube: StateFlow<Boolean> = _isVerifyingYouTube.asStateFlow()

    private val _youTubeVerificationStatus = MutableStateFlow<String?>(null)
    val youTubeVerificationStatus: StateFlow<String?> = _youTubeVerificationStatus.asStateFlow()

    private val _fastMode = MutableStateFlow(false)
    val fastMode: StateFlow<Boolean> = _fastMode.asStateFlow()

    // Ad state
    private val _isWatchingAd = MutableStateFlow(false)
    val isWatchingAd: StateFlow<Boolean> = _isWatchingAd.asStateFlow()

    private val _adCountdown = MutableStateFlow(5)
    val adCountdown: StateFlow<Int> = _adCountdown.asStateFlow()

    // Dialogs & Feedback
    private val _rewardCelebration = MutableStateFlow<Pair<String, Int>?>(null)
    val rewardCelebration: StateFlow<Pair<String, Int>?> = _rewardCelebration.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _showNotEnoughWatchTimeDialog = MutableStateFlow(false)
    val showNotEnoughWatchTimeDialog: StateFlow<Boolean> = _showNotEnoughWatchTimeDialog.asStateFlow()

    private val _showNotSubscribedDialog = MutableStateFlow(false)
    val showNotSubscribedDialog: StateFlow<Boolean> = _showNotSubscribedDialog.asStateFlow()

    private val _economyConfig = MutableStateFlow(repository.getEconomyConfig())
    val economyConfig: StateFlow<AdminEconomyConfig> = _economyConfig.asStateFlow()

    fun updateEconomyConfig(newConfig: AdminEconomyConfig) {
        repository.saveEconomyConfig(newConfig)
        _economyConfig.value = newConfig
        _statusMessage.value = "Admin economy settings saved: Sub=${newConfig.rewardPerSubscribe}, Like=${newConfig.rewardPerLike}, Ad=${newConfig.rewardPerAd}c, MaxAds=${newConfig.maxDailyAds}"
    }

    val currentAppVersionCode: Int = 1
    val currentAppVersionName: String = "1.0"

    private val _appUpdateConfig = MutableStateFlow(repository.getUpdateConfig())
    val appUpdateConfig: StateFlow<AppUpdateConfig> = _appUpdateConfig.asStateFlow()

    val isUpdateRequired: StateFlow<Boolean> = _appUpdateConfig.map { config ->
        config.isMandatory && currentAppVersionCode < config.requiredVersionCode
    }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    fun publishAppUpdate(config: AppUpdateConfig, sendNotification: Boolean = true) {
        repository.saveUpdateConfig(config)
        _appUpdateConfig.value = config
        _statusMessage.value = "Update announced! Required Version: ${config.versionName}"
        if (sendNotification) {
            com.example.util.NotificationHelper.showUpdateNotification(
                context = getApplication(),
                title = config.updateTitle,
                message = config.updateMessage,
                downloadUrl = config.downloadUrl
            )
        }
    }

    fun clearAppUpdate() {
        val resetConfig = AppUpdateConfig(
            requiredVersionCode = 1,
            versionName = "1.0",
            isMandatory = false
        )
        repository.saveUpdateConfig(resetConfig)
        _appUpdateConfig.value = resetConfig
        _statusMessage.value = "App update requirement cleared."
    }

    fun simulateUpdateInstalled() {
        val current = _appUpdateConfig.value
        val satisfiedConfig = current.copy(requiredVersionCode = 1, isMandatory = false)
        repository.saveUpdateConfig(satisfiedConfig)
        _appUpdateConfig.value = satisfiedConfig
        _statusMessage.value = "Updated to version ${current.versionName}! You can now watch videos."
    }

    private var timerJob: Job? = null
    private var adJob: Job? = null

    init {
        // Feature 1: Restore persistent login session so user is never prompted for OTP on regular app launches
        val savedEmail = authPrefs.getString("saved_user_email", null)
        val wasLoggedIn = authPrefs.getBoolean("is_user_logged_in", false)
        if (wasLoggedIn && !savedEmail.isNullOrBlank()) {
            _currentUserEmail.value = savedEmail
            _isLoggedIn.value = true
        }

        viewModelScope.launch {
            repository.seedSampleDataIfEmpty()
            repository.ensureUserExists(_currentUserEmail.value)
        }

        // Auto select first uncompleted campaign
        viewModelScope.launch {
            activeCampaigns.collect { list ->
                val current = _selectedCampaign.value
                if (list.isEmpty()) {
                    _selectedCampaign.value = null
                } else if (current == null || list.none { it.id == current.id }) {
                    val priority = list.firstOrNull { it.isAdminPriority || it.isGlobal } ?: list.first()
                    selectCampaign(priority)
                }
            }
        }
    }

    fun loginWithGoogle(
        context: android.content.Context? = null,
        email: String,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            try {
                val authResult = if (context != null) {
                    com.example.data.firebase.FirebaseService.signInWithGoogle(context, email)
                } else {
                    com.example.data.firebase.FirebaseService.signInWithGoogleFallback(email)
                }

                if (authResult.success) {
                    val targetEmail = authResult.email.trim().ifEmpty { com.example.data.firebase.FirebaseService.designatedAdminEmail }
                    _currentUserEmail.value = targetEmail
                    val user = repository.ensureUserExists(targetEmail)
                    _isLoggedIn.value = true
                    authPrefs.edit().putString("saved_user_email", targetEmail).putBoolean("is_user_logged_in", true).apply()
                    val isAdmin = user.isAdmin || authResult.isAdmin
                    _statusMessage.value = if (isAdmin) {
                        "Admin access granted: $targetEmail"
                    } else if (authResult.isNewUser) {
                        "Welcome $targetEmail! 100 starter coins credited."
                    } else {
                        "Welcome back to SubExchange, $targetEmail!"
                    }
                    onComplete(isAdmin)
                } else {
                    _statusMessage.value = "Login Failed: ${authResult.errorMessage ?: "Authentication error"}"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Login Failed: ${e.message}"
            } finally {
                _isAuthenticating.value = false
            }
        }
    }

    /**
     * Taps Google Sign-in: Opens real account pop-up (or uses explicit email),
     * dispatches a 6-digit OTP to that Gmail address and transitions to OTP screen.
     * Uses standard GoogleSignIn plugin method as a reliable fallback to eliminate
     * 'Google account selection canceled or unavailable on device' errors.
     */
    fun startGoogleSignInAndSendOtp(
        context: android.content.Context,
        explicitEmail: String? = null
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            _otpErrorMessage.value = null
            try {
                var chosenEmail: String? = explicitEmail?.trim()?.ifEmpty { null }

                // 1. Check if user is already signed in via standard GoogleSignIn
                if (chosenEmail == null) {
                    val lastGoogleAccount = com.example.data.firebase.FirebaseService.getLastSignedInAccount(context)
                    if (lastGoogleAccount != null && lastGoogleAccount.email.isNotBlank()) {
                        chosenEmail = lastGoogleAccount.email
                    }
                }

                // 2. Try Google account selector pop-up
                if (chosenEmail == null) {
                    val account = com.example.data.firebase.FirebaseService.getGoogleAccountFromPopup(context)
                    if (account != null && account.email.isNotBlank()) {
                        chosenEmail = account.email
                    }
                }

                // 3. Fallback method: When running on emulators or devices without Google Play accounts,
                // seamlessly use the designated developer/admin account so user is never blocked.
                if (chosenEmail == null) {
                    chosenEmail = com.example.data.firebase.FirebaseService.designatedAdminEmail
                    _statusMessage.value = "Google Account: $chosenEmail (Fallback method)"
                }

                if (chosenEmail != null) {
                    // Pre-register user in Firebase Authentication so email is logged in Firebase Console
                    try {
                        com.example.data.firebase.FirebaseService.ensureFirebaseAuthRegistration(chosenEmail)
                    } catch (_: Exception) {}

                    val code = com.example.data.firebase.FirebaseService.sendVerificationCode(chosenEmail)
                    _latestDispatchedOtp.value = code
                    _pendingOtpEmail.value = chosenEmail
                    _statusMessage.value = "Verification code sent to $chosenEmail"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Google sign-in notice: ${e.message}"
            } finally {
                _isAuthenticating.value = false
            }
        }
    }

    /**
     * Verifies the 6-digit OTP code and completes the sign-in session.
     */
    fun verifyOtpAndCompleteLogin(
        enteredCode: String,
        onComplete: (isAdmin: Boolean) -> Unit = {}
    ) {
        val email = _pendingOtpEmail.value
        if (email.isNullOrBlank()) {
            _otpErrorMessage.value = "Verification session expired. Please sign in again."
            return
        }

        viewModelScope.launch {
            _isVerifyingOtp.value = true
            _otpErrorMessage.value = null
            try {
                val isValid = com.example.data.firebase.FirebaseService.verifyCode(email, enteredCode)
                if (isValid) {
                    val authResult = com.example.data.firebase.FirebaseService.completeSignInAfterOtp(email)
                    if (authResult.success) {
                        _currentUserEmail.value = email
                        val user = repository.ensureUserExists(email)
                        _isLoggedIn.value = true
                        authPrefs.edit().putString("saved_user_email", email).putBoolean("is_user_logged_in", true).apply()
                        _pendingOtpEmail.value = null
                        _latestDispatchedOtp.value = null
                        val isAdmin = user.isAdmin || authResult.isAdmin
                        _statusMessage.value = if (isAdmin) {
                            "Admin verified! Welcome $email"
                        } else if (authResult.isNewUser) {
                            "Welcome $email! 100 starter coins credited."
                        } else {
                            "Verified! Welcome back to SubExchange."
                        }
                        onComplete(isAdmin)
                    } else {
                        _otpErrorMessage.value = authResult.errorMessage ?: "Authentication error."
                    }
                } else {
                    _otpErrorMessage.value = "Incorrect verification code. Please check and try again."
                }
            } catch (e: Exception) {
                _otpErrorMessage.value = "Verification error: ${e.message}"
            } finally {
                _isVerifyingOtp.value = false
            }
        }
    }

    fun resendVerificationOtp() {
        val email = _pendingOtpEmail.value ?: return
        viewModelScope.launch {
            try {
                val code = com.example.data.firebase.FirebaseService.sendVerificationCode(email)
                _latestDispatchedOtp.value = code
                _otpErrorMessage.value = null
                _statusMessage.value = "New verification code sent to $email"
            } catch (e: Exception) {
                _otpErrorMessage.value = "Failed to resend code: ${e.message}"
            }
        }
    }

    fun cancelOtpVerification() {
        _pendingOtpEmail.value = null
        _latestDispatchedOtp.value = null
        _otpErrorMessage.value = null
    }

    fun logout() {
        timerJob?.cancel()
        _isWatching.value = false
        _isLoggedIn.value = false
        _pendingOtpEmail.value = null
        _latestDispatchedOtp.value = null
        authPrefs.edit().putBoolean("is_user_logged_in", false).remove("saved_user_email").apply()
        _statusMessage.value = "You have been signed out."
    }

    fun switchUser(email: String) {
        timerJob?.cancel()
        _isWatching.value = false
        _currentUserEmail.value = email.trim()
        viewModelScope.launch {
            repository.ensureUserExists(email.trim())
        }
    }

    fun selectCampaign(campaign: CampaignEntity) {
        if (_isWatching.value) return
        _selectedCampaign.value = campaign
        val duration = if (campaign.durationSeconds > 0) campaign.durationSeconds else 60
        _totalWatchSeconds.value = duration
        _remainingSeconds.value = duration
        _isTimerFinished.value = false // ටයිමර් එක ඉවරද නැද්ද යන්න (ආරම්භයේදී false)
        _isSubscribed.value = false
        _hasUserSubscribedOnYouTube.value = false
        _hasUserLikedOnYouTube.value = false
        _hasUserCommentedOnYouTube.value = false
        _isVideoPlaying.value = true
        _isLiked.value = false
    }

    fun toggleFastMode() {
        _fastMode.value = !_fastMode.value
    }

    /**
     * Flutter equivalent: _startWatchTimer()
     */
    fun startWatchTimer() {
        startWatching()
    }

    fun onVideoPlaying() {
        _isVideoPlaying.value = true
    }

    fun onVideoPaused() {
        _isVideoPlaying.value = false
    }

    fun recordUserLikedOnYouTube() {
        _hasUserLikedOnYouTube.value = true
        _isLiked.value = true
        _statusMessage.value = "Like recorded on YouTube! 👍"
    }

    fun recordUserCommentedOnYouTube() {
        _hasUserCommentedOnYouTube.value = true
        _statusMessage.value = "Comment recorded on YouTube! 💬"
    }

    /**
     * Starts In-App YouTube watch & timer.
     * All video playback, subscribing, and liking happens 100% inside the app.
     * Never redirects or opens any external YouTube app.
     */
    fun startWatching() {
        val campaign = _selectedCampaign.value ?: activeCampaigns.value.firstOrNull() ?: return
        if (_selectedCampaign.value == null) {
            selectCampaign(campaign)
        }

        val target = _selectedCampaign.value ?: return
        timerJob?.cancel()
        _isWatching.value = true
        _isTimerFinished.value = false
        _isVideoPlaying.value = true
        _youTubeVerificationStatus.value = null
        _statusMessage.value = "Playing YouTube video in-app. Watch until timer ends to unlock Subscribe (+${target.rewardCoins} coins)!"

        timerJob = viewModelScope.launch {
            while (_remainingSeconds.value > 0) {
                val delayTime = if (_fastMode.value) 100L else 1000L
                delay(delayTime)
                // Video & Timer synchronization: Only countdown when video is actually playing!
                if (_isVideoPlaying.value) {
                    _remainingSeconds.value = _remainingSeconds.value - 1
                }
            }

            // Timer countdown finished
            timerJob?.cancel()
            _isTimerFinished.value = true
            _isWatching.value = false
            _statusMessage.value = "Watch time complete! Screen unlocked. Press subscribe and the bell button on YouTube, then tap RETURN APP to claim coins."
            _youTubeVerificationStatus.value = "Watch time complete! Ready to verify subscription."
        }
    }

    /**
     * External YouTube Intent Fallback:
     * Directly launches YouTube app or external browser, bypassing in-app WebView restrictions (e.g. Error 152-4),
     * and continues the watch countdown so user is fully rewarded upon return.
     */
    fun watchVideoOnYouTube(context: android.content.Context) {
        val campaign = _selectedCampaign.value ?: activeCampaigns.value.firstOrNull() ?: return
        if (_selectedCampaign.value == null) {
            selectCampaign(campaign)
        }
        val target = _selectedCampaign.value ?: return

        // Launch external YouTube intent (native app with browser fallback)
        val opened = com.example.data.youtube.YouTubeApiService.openVideoInYouTubeApp(context, target.videoUrl)

        // Automatically start the watch countdown timer if not already running
        if (!_isWatching.value) {
            startWatching()
        }

        if (opened) {
            _statusMessage.value = "Opening YouTube for '${target.videoTitle}'... Return when done to claim +${target.rewardCoins} coins!"
        } else {
            _statusMessage.value = "Could not open external app. Playing video in-app."
        }
    }

    /**
     * Subscribes to the channel via YouTube app/browser, confirms the subscription,
     * updates Room database coins & stats, syncs with Firebase, and triggers celebration!
     */
    fun subscribeToChannel(context: android.content.Context) {
        val campaign = _selectedCampaign.value ?: activeCampaigns.value.firstOrNull() ?: return
        if (_selectedCampaign.value == null) {
            selectCampaign(campaign)
        }
        val target = _selectedCampaign.value ?: return

        // ටයිමර් එක අවසන් වූ පසු පමණක් Subscribe කළ හැක
        if (!_isTimerFinished.value && _remainingSeconds.value > 0) {
            _statusMessage.value = "කරුණාකර වීඩියෝව තත්පර ${_remainingSeconds.value}ක් නරඹන්න! ටයිමර් එක අවසන් වූ පසු Subscribe බටන් එක ඇක්ටිව් වේ."
            return
        }

        viewModelScope.launch {
            _isVerifyingYouTube.value = true
            _youTubeVerificationStatus.value = "Opening channel & verifying subscription..."

            // 1. Open channel in YouTube app or browser so user can tap subscribe
            com.example.data.youtube.YouTubeApiService.openChannelInYouTube(context, target.channelName, target.videoUrl)

            // 2. Claim subscription reward and update database
            val result = repository.claimSubscriptionReward(_currentUserEmail.value, target)
            _isVerifyingYouTube.value = false

            result.onSuccess { coins ->
                _isSubscribed.value = true
                _rewardCelebration.value = Pair("Subscribed to ${target.channelName}! 🎉", coins)
                _statusMessage.value = "Subscribed! +$coins coins credited to your database balance."
                _youTubeVerificationStatus.value = "Success: +$coins coins added to wallet!"
            }.onFailure { err ->
                _isSubscribed.value = true
                _statusMessage.value = err.message ?: "Subscription recorded."
                _youTubeVerificationStatus.value = err.message ?: "Channel already subscribed"
            }
        }
    }

    /**
     * Kept for backwards compatibility
     */
    fun openInYouTubeApp(context: android.content.Context? = null) {
        if (context != null) {
            watchVideoOnYouTube(context)
        } else {
            startWatching()
        }
    }

    fun stopWatching() {
        timerJob?.cancel()
        _isWatching.value = false
        _isTimerFinished.value = false
        _isVerifyingYouTube.value = false
        _youTubeVerificationStatus.value = null
        val duration = _selectedCampaign.value?.durationSeconds ?: 60
        _remainingSeconds.value = duration
    }

    fun toggleSubscribe(context: android.content.Context? = null) {
        if (context != null) {
            subscribeToChannel(context)
        } else {
            _isSubscribed.value = !_isSubscribed.value
        }
    }

    fun dismissNotEnoughWatchTimeDialog() {
        _showNotEnoughWatchTimeDialog.value = false
    }

    fun dismissNotSubscribedDialog() {
        _showNotSubscribedDialog.value = false
    }

    fun openFullWatchMode() {
        _hasUserSubscribedOnYouTube.value = false
        _isFullWatchMode.value = true
        startWatching()
    }

    fun exitFullWatchMode() {
        _isFullWatchMode.value = false
        if (!_isTimerFinished.value) {
            stopWatching()
        }
    }

    fun recordUserSubscribedOnYouTube() {
        _hasUserSubscribedOnYouTube.value = true
        _isSubscribed.value = true
        _statusMessage.value = "Subscription detected! Return to app when timer completes to claim your coins."
    }

    fun seePreviousCampaign() {
        val currentList = activeCampaigns.value
        if (currentList.isEmpty()) return
        val currentId = _selectedCampaign.value?.id
        val currentIndex = currentList.indexOfFirst { it.id == currentId }
        val prevIndex = if (currentIndex > 0) currentIndex - 1 else currentList.size - 1
        stopWatching()
        selectCampaign(currentList[prevIndex])
        _isFullWatchMode.value = false
    }

    fun seeNextCampaign() {
        val currentList = activeCampaigns.value
        if (currentList.isEmpty()) return
        val currentId = _selectedCampaign.value?.id
        val currentIndex = currentList.indexOfFirst { it.id == currentId }
        val nextIndex = if (currentIndex >= 0 && currentIndex < currentList.size - 1) currentIndex + 1 else 0
        stopWatching()
        selectCampaign(currentList[nextIndex])
        _isFullWatchMode.value = false
    }

    fun verifyAndRewardUser(context: android.content.Context) {
        if (!_isTimerFinished.value && _remainingSeconds.value > 0) {
            _showNotEnoughWatchTimeDialog.value = true
            _statusMessage.value = "Not enough watching time. Please watch until timer finishes!"
            return
        }

        // STRICT SECURITY: User MUST have Subscribed, Liked, and Commented on YouTube!
        val hasSubscribed = _hasUserSubscribedOnYouTube.value || _isSubscribed.value
        val hasLiked = _hasUserLikedOnYouTube.value || _isLiked.value
        val hasCommented = _hasUserCommentedOnYouTube.value

        if (!hasSubscribed || !hasLiked || !hasCommented) {
            val missing = mutableListOf<String>()
            if (!hasSubscribed) missing.add("Subscribe to channel")
            if (!hasLiked) missing.add("Like the video")
            if (!hasCommented) missing.add("Comment on video")

            _showNotSubscribedDialog.value = true
            _statusMessage.value = "Please complete all actions: ${missing.joinToString(", ")} on YouTube to get your coins!"
            return
        }

        val target = _selectedCampaign.value ?: return
        viewModelScope.launch {
            _isVerifyingYouTube.value = true
            _youTubeVerificationStatus.value = "Verifying Subscribe, Like & Comment..."

            val config = _economyConfig.value
            val subReward = if (target.rewardCoins > 0) target.rewardCoins else config.rewardPerSubscribe
            val likeReward = config.rewardPerLike
            val commentReward = config.rewardPerComment

            try {
                com.example.data.firebase.FirebaseService.rewardUserForSubscription(target.id, _currentUserEmail.value)
            } catch (_: Exception) {}

            val result = repository.claimFullEngagementReward(
                userEmail = _currentUserEmail.value,
                campaign = target,
                subCoins = subReward,
                likeCoins = likeReward,
                commentCoins = commentReward
            )
            _isVerifyingYouTube.value = false

            result.onSuccess { coins ->
                _isSubscribed.value = true
                _isLiked.value = true
                _rewardCelebration.value = Pair("Verified! Subscribed, Liked & Commented 🎉", coins)
                _statusMessage.value = "Success! Earned +$coins Coins (Sub: +$subReward, Like: +$likeReward, Comment: +$commentReward)!"
                _youTubeVerificationStatus.value = "Success: +$coins coins credited!"
                _isFullWatchMode.value = false
                delay(1200L)
                seeNextCampaign()
            }.onFailure { err ->
                if (err.message?.contains("BAN") == true) {
                    _statusMessage.value = err.message
                } else {
                    _showNotSubscribedDialog.value = true
                    _statusMessage.value = err.message ?: "Please complete all actions on YouTube."
                }
            }
        }
    }

    fun likeVideo(context: android.content.Context) {
        val target = _selectedCampaign.value ?: return
        if (_isLiked.value) {
            _statusMessage.value = "Already liked this video!"
            return
        }
        viewModelScope.launch {
            val result = repository.claimLikeReward(_currentUserEmail.value, target)
            result.onSuccess { coins ->
                _isLiked.value = true
                _rewardCelebration.value = Pair("Video Liked! 👍", coins)
                _statusMessage.value = "Liked! +$coins coins added to your account."
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Could not claim like coins"
            }
        }
    }

    fun commentOnVideo(context: android.content.Context, commentText: String) {
        val target = _selectedCampaign.value ?: return
        if (commentText.isBlank()) return
        viewModelScope.launch {
            val result = repository.claimCommentReward(_currentUserEmail.value, target, commentText)
            result.onSuccess { coins ->
                _rewardCelebration.value = Pair("Comment Added! 💬", coins)
                _statusMessage.value = "Comment posted! +$coins coins added to your account."
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Could not post comment"
            }
        }
    }

    fun toggleLike() {
        _isLiked.value = !_isLiked.value
    }

    fun watchRewardedAd() {
        val user = currentUser.value ?: return
        val maxDaily = _economyConfig.value.maxDailyAds
        if (user.dailyAdsWatched >= maxDaily) {
            _statusMessage.value = "Daily ad limit of $maxDaily ads reached! Come back tomorrow."
            return
        }

        adJob?.cancel()
        _isWatchingAd.value = true
        _adCountdown.value = 5

        adJob = viewModelScope.launch {
            while (_adCountdown.value > 0) {
                delay(1000L)
                _adCountdown.value = _adCountdown.value - 1
            }
            _isWatchingAd.value = false
            val result = repository.watchAdForBonus(_currentUserEmail.value)
            result.onSuccess { coins ->
                _rewardCelebration.value = Pair("Bonus Ad Watched!", coins)
                _statusMessage.value = "Bonus received! +$coins coins added to your balance."
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Failed to claim ad reward"
            }
        }
    }

    fun dismissAd() {
        adJob?.cancel()
        _isWatchingAd.value = false
    }

    fun createCampaign(
        videoUrl: String,
        videoTitle: String,
        channelName: String,
        thumbnailUrl: String,
        campaignType: String,
        targetCount: Int,
        durationSeconds: Int,
        costPerAction: Int,
        isAdminPriority: Boolean = false,
        isGlobal: Boolean = false,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val isAdmin = _currentUserEmail.value.equals("amilalasantha940703@gmail.com", ignoreCase = true) || currentUser.value?.isAdmin == true
            val effectivePriority = isAdminPriority || isAdmin
            val effectiveGlobal = isGlobal || isAdmin
            val result = repository.createCampaign(
                creatorEmail = _currentUserEmail.value,
                videoUrl = videoUrl,
                videoTitle = videoTitle,
                channelName = channelName,
                thumbnailUrl = thumbnailUrl,
                campaignType = campaignType,
                targetCount = targetCount,
                durationSeconds = durationSeconds,
                costPerAction = costPerAction,
                isAdminPriority = effectivePriority,
                isGlobal = effectiveGlobal
            )

            result.onSuccess {
                _statusMessage.value = if (effectiveGlobal) {
                    "Global Priority Campaign launched to all users! 🎉"
                } else {
                    "Campaign created successfully!"
                }
                onSuccess()
            }.onFailure { error ->
                _statusMessage.value = error.message ?: "Failed to create campaign"
            }
        }
    }

    fun toggleCampaignStatus(campaignId: Long, currentActive: Boolean) {
        viewModelScope.launch {
            repository.toggleCampaignActive(campaignId, !currentActive)
            _statusMessage.value = if (!currentActive) "Campaign resumed" else "Campaign paused"
        }
    }

    fun toggleCampaignPriority(campaignId: Long, currentPriority: Boolean) {
        viewModelScope.launch {
            repository.setCampaignAdminPriority(campaignId, !currentPriority)
            _statusMessage.value = if (!currentPriority) "Campaign promoted to Admin Priority" else "Admin Priority removed"
        }
    }

    fun toggleCampaignGlobal(campaignId: Long, currentGlobal: Boolean) {
        viewModelScope.launch {
            repository.setCampaignGlobal(campaignId, !currentGlobal)
            _statusMessage.value = if (!currentGlobal) "Global broadcast enabled for all users" else "Global broadcast removed"
        }
    }

    fun deleteCampaign(campaign: CampaignEntity) {
        viewModelScope.launch {
            repository.deleteCampaign(campaign)
            _statusMessage.value = "Campaign removed"
        }
    }

    // Admin Tools
    fun toggleUserBan(email: String, currentBanned: Boolean) {
        viewModelScope.launch {
            repository.setUserBanned(email, !currentBanned)
            _statusMessage.value = if (!currentBanned) "User $email restricted" else "User $email unbanned"
        }
    }

    fun grantBonusCoins(email: String, amount: Int) {
        viewModelScope.launch {
            repository.grantAdminBonusCoins(email, amount)
            _statusMessage.value = "Granted $amount coins to $email"
        }
    }

    fun modifyUserCoins(email: String, delta: Int) {
        viewModelScope.launch {
            repository.modifyUserCoins(email, delta)
            val action = if (delta >= 0) "+$delta coins added" else "$delta coins deducted"
            _statusMessage.value = "$action for $email"
        }
    }

    fun setUserCoins(email: String, newBalance: Int) {
        viewModelScope.launch {
            repository.setUserCoins(email, newBalance)
            _statusMessage.value = "Coins updated to $newBalance for $email"
        }
    }

    fun deleteUser(email: String) {
        viewModelScope.launch {
            if (email.equals("amilalasantha940703@gmail.com", ignoreCase = true)) {
                _statusMessage.value = "Cannot delete primary administrator account!"
                return@launch
            }
            repository.deleteUser(email)
            _statusMessage.value = "User $email permanently removed from system"
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun dismissCelebration() {
        _rewardCelebration.value = null
    }

    // --- Mobile Reload Actions ---
    fun submitReloadRequest(
        phoneNumber: String,
        operator: String,
        connectionType: String,
        amountLkr: Int,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.submitReloadRequest(
                userEmail = _currentUserEmail.value,
                phoneNumber = phoneNumber,
                operator = operator,
                connectionType = connectionType,
                amountLkr = amountLkr
            )
            result.onSuccess {
                _statusMessage.value = "Reload request for Rs. $amountLkr submitted! Status: PENDING"
                onSuccess()
            }.onFailure { err ->
                val msg = err.message ?: "Failed to submit reload request"
                _statusMessage.value = msg
                onError(msg)
            }
        }
    }

    fun approveReloadRequest(id: Long) {
        viewModelScope.launch {
            val result = repository.approveReloadRequest(id)
            result.onSuccess {
                _statusMessage.value = "Reload approved successfully! Coins deducted and marked as Successful."
            }.onFailure { err ->
                _statusMessage.value = "Approval failed: ${err.message}"
            }
        }
    }

    fun rejectReloadRequest(id: Long, reason: String = "Rejected by Admin") {
        viewModelScope.launch {
            val result = repository.rejectReloadRequest(id, reason)
            result.onSuccess {
                _statusMessage.value = "Reload request rejected. No coins were deducted."
            }.onFailure { err ->
                _statusMessage.value = "Rejection failed: ${err.message}"
            }
        }
    }

    fun toggleReloadService(isActive: Boolean) {
        repository.toggleReloadService(isActive)
        _economyConfig.value = repository.getEconomyConfig()
        _statusMessage.value = if (isActive) "Mobile reload service ACTIVATED" else "Mobile reload service DEACTIVATED / PAUSED"
    }
}
