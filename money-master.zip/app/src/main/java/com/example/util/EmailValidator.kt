package com.example.util

import android.util.Patterns

object EmailValidator {

    sealed class Result {
        object Valid : Result()
        data class Invalid(val reason: String) : Result()
    }

    // Known temporary, disposable, throwaway email service domains
    private val DISPOSABLE_DOMAINS = setOf(
        "tempmail.com", "temp-mail.org", "mailinator.com", "10minutemail.com",
        "guerrillamail.com", "guerrillamail.net", "guerrillamail.org", "guerrillamailblock.com",
        "sharklasers.com", "grr.la", "trashmail.com", "trashmail.net", "throwawaymail.com",
        "getairmail.com", "dispostable.com", "yopmail.com", "yopmail.net", "fakemailgenerator.com",
        "maildrop.cc", "generator.email", "inboxkitten.com", "mohmal.com", "crazymailing.com",
        "mytemp.email", "discard.email", "nada.ltd", "getnada.com", "emailondeck.com",
        "tempail.com", "burnermail.io", "dropmail.me", "harakirimail.com", "mailnull.com",
        "mytempemail.com", "spambox.us", "trash-mail.at", "tmail.com", "tempinbox.com",
        "throwaway.email", "tempmailo.com", "pokemail.net", "spam4.me", "bccto.me",
        "0clickemail.com", "disposablemail.com", "chacuo.net", "armyspy.com", "cuvox.de",
        "dayrep.com", "fleckens.hu", "gustr.com", "jourrapide.com", "rhyta.com",
        "superrito.com", "teleworm.us", "einrot.com", "mailnesia.com", "trashmail.org",
        "fakeinbox.com", "inboxalias.com", "tempinbox.xyz", "tempmail.net", "tempmailgen.com",
        "mytempmail.com", "zillamail.com", "mailforspam.com", "binkmail.com", "suremail.info",
        "jetable.org", "spamgourmet.com", "spamfree24.org", "kasmail.com", "emailtemporal.org"
    )

    // Obvious dummy or test domains
    private val DUMMY_DOMAINS = setOf(
        "test.com", "example.com", "fake.com", "dummy.com", "sample.com", "invalid.com",
        "none.com", "temp.com", "xyz.com", "abc.com", "123.com", "aaa.com", "bbb.com",
        "asdf.com", "domain.com", "site.com", "somemail.com", "mymail.com", "email.com",
        "test.org", "test.net", "sample.org", "fake.org", "fakemail.com", "nomail.com",
        "mail.test", "localhost", "a.com", "b.com", "c.com", "qwe.com", "asd.com",
        "test.lk", "fake.lk", "demo.com", "sample.lk", "unknown.com", "mytest.com"
    )

    // Obvious dummy, placeholder or fake usernames
    private val DUMMY_USERNAMES = setOf(
        "test", "fake", "demo", "dummy", "sample", "temp", "temporary", "trash",
        "throwaway", "nobody", "noemail", "asdf", "asdfg", "asdfgh", "qwerty", "zxcv",
        "1234", "12345", "123456", "1234567", "12345678", "anonymous", "tester",
        "user1", "testuser", "null", "undefined", "random", "sampleuser", "bot",
        "spam", "spammer", "fakeuser", "noname", "unknown", "qwertyuiop", "asdfghjkl",
        "testing", "abcdef", "bla", "blabla", "whatever", "someone", "noone", "xyz"
    )

    // Trusted global email providers
    private val TRUSTED_PROVIDERS = setOf(
        "gmail.com", "googlemail.com",
        "yahoo.com", "ymail.com", "rocketmail.com",
        "outlook.com", "hotmail.com", "live.com", "msn.com",
        "icloud.com", "me.com", "mac.com",
        "proton.me", "protonmail.com",
        "zoho.com", "aol.com", "mail.com", "yandex.com",
        "gmx.com", "gmx.net"
    )

    // Recognized top-level domains
    private val VALID_TLDS = setOf(
        "com", "org", "net", "edu", "gov", "mil", "lk", "io", "co", "in", "uk", "us",
        "ca", "au", "de", "fr", "jp", "info", "biz", "me", "app", "dev", "ai", "xyz",
        "online", "site", "tech", "store", "global", "pro", "mobi", "asia", "eu",
        "ac.lk", "gov.lk", "sch.lk", "org.lk", "co.uk", "co.in", "com.au"
    )

    fun validate(rawEmail: String?): Result {
        if (rawEmail.isNullOrBlank()) {
            return Result.Invalid("කරුණාකර ඔබගේ ඊමේල් ලිපිනය ඇතුළත් කරන්න (Please enter an email).")
        }

        val email = rawEmail.trim().lowercase()

        // Admin override: designated admin accounts are always valid
        if (com.example.data.firebase.FirebaseService.isAppAdmin(email)) {
            return Result.Valid
        }

        if (email.length < 6) {
            return Result.Invalid("ඊමේල් ලිපිනය ඉතා කෙටියි (Email is too short).")
        }

        if (email.length > 100) {
            return Result.Invalid("ඊමේල් ලිපිනය ඉතා දිගුයි (Email is too long).")
        }

        val atCount = email.count { it == '@' }
        if (atCount != 1) {
            return Result.Invalid("වලංගු නොවන ඊමේල් ආකෘතියකි (@ ලකුණ එකක් පමණක් තිබිය යුතුය).")
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return Result.Invalid("කරුණාකර නිවැරදි ඊමේල් ආකෘතියක් ඇතුළත් කරන්න (Invalid email syntax).")
        }

        val parts = email.split("@")
        val username = parts[0]
        val domain = parts[1]

        // 1. Validate Username
        if (username.length < 4) {
            return Result.Invalid("ඊමේල් නාමය (username) ඉතා කෙටියි. අවම වශයෙන් අකුරු 4ක් තිබිය යුතුය.")
        }

        if (username.startsWith(".") || username.endsWith(".") ||
            username.startsWith("-") || username.endsWith("-") ||
            username.startsWith("_") || username.endsWith("_") ||
            username.startsWith("+") || username.endsWith("+")
        ) {
            return Result.Invalid("ඊමේල් නාමය ලකුණු වලින් ආරම්භ වීමට හෝ අවසන් වීමට නොහැක.")
        }

        if (username.contains("..") || username.contains("--") || username.contains("__") || username.contains("++")) {
            return Result.Invalid("ඊමේල් නාමයේ අනුක්‍රමික ලකුණු (consecutive dots/hyphens) තිබිය නොහැක.")
        }

        // Check if username contains invalid characters
        val validUsernameRegex = Regex("^[a-z0-9._%+-]+$")
        if (!validUsernameRegex.matches(username)) {
            return Result.Invalid("ඊමේල් නාමයේ වලංගු නොවන අක්ෂර අඩංගු වේ.")
        }

        // Check if username is purely numeric
        if (username.all { it.isDigit() }) {
            return Result.Invalid("ඊමේල් නාමය ඉලක්කම් පමණක් විය නොහැක (Username cannot be numbers only).")
        }

        // Check for repeating characters (e.g. aaaaa, 11111)
        if (username.toSet().size <= 2 && username.length > 4) {
            return Result.Invalid("ව්‍යාජ ඊමේල් ලිපින භාවිත කළ නොහැක (Repeated characters detected).")
        }

        // Check dummy usernames
        val cleanUsername = username.replace(Regex("[^a-z0-9]"), "")
        if (DUMMY_USERNAMES.contains(cleanUsername) || DUMMY_USERNAMES.any { cleanUsername.startsWith(it) && cleanUsername.length <= it.length + 2 }) {
            return Result.Invalid("ව්‍යාජ (dummy/test) ඊමේල් ලිපින භාවිත කළ නොහැක. කරුණාකර සැබෑ ඊමේල් ලිපිනයක් යොදන්න.")
        }

        // 2. Validate Domain
        if (!domain.contains(".")) {
            return Result.Invalid("වලංගු ඩොමේන් නාමයක් නොමැත (Invalid domain name).")
        }

        val domainParts = domain.split(".")
        val tld = domainParts.last()
        val domainName = domainParts.dropLast(1).joinToString(".")

        if (domainName.length < 2) {
            return Result.Invalid("වලංගු නොවන ඩොමේන් නාමයකි (Domain name is too short).")
        }

        if (tld.length < 2 || tld.any { it.isDigit() }) {
            return Result.Invalid("වලංගු නොවන TLD ආකෘතියකි (Invalid domain extension).")
        }

        // Check against disposable / burner domains
        if (DISPOSABLE_DOMAINS.contains(domain) || DISPOSABLE_DOMAINS.any { domain.endsWith(".$it") }) {
            return Result.Invalid("තාවකාලික හෝ ව්‍යාජ (disposable/temp) ඊමේල් තහනම් කර ඇත. කරුණාකර සැබෑ ඊමේල් ලිපිනයක් යොදන්න.")
        }

        // Check against dummy test domains
        if (DUMMY_DOMAINS.contains(domain) || DUMMY_DOMAINS.any { domain.endsWith(".$it") }) {
            return Result.Invalid("ව්‍යාජ හෝ නියැදි ඩොමේන් (dummy/test domain) භාවිත කළ නොහැක.")
        }

        // Special check for Gmail
        if (domain == "gmail.com" || domain == "googlemail.com") {
            if (username.length < 6 || username.length > 30) {
                return Result.Invalid("Gmail නාමය (username) අකුරු 6ත් 30ත් අතර විය යුතුය.")
            }
            if (username.contains("+")) {
                return Result.Invalid("Gmail සඳහා '+' උපසර්ග සහිත ලිපින භාවිත කළ නොහැක.")
            }
        } else if (!TRUSTED_PROVIDERS.contains(domain)) {
            // If domain is not in trusted providers list, check if it has a legitimate TLD and valid structure
            val isKnownTld = VALID_TLDS.contains(tld) || domain.endsWith(".edu") || domain.endsWith(".ac.lk") || domain.endsWith(".gov.lk")
            if (!isKnownTld || domainName.length < 3) {
                return Result.Invalid("කරුණාකර පිළිගත් ඊමේල් සේවාවක් (Gmail, Yahoo, Outlook ආදී) හෝ සැබෑ ඩොමේනයක් යොදන්න.")
            }
        }

        return Result.Valid
    }

    fun isValid(email: String?): Boolean {
        return validate(email) is Result.Valid
    }
}
