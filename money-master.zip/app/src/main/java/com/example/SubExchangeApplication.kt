package com.example

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp

class SubExchangeApplication : Application() {

    companion object {
        private const val TAG = "SubExchangeApp"
        var instance: SubExchangeApplication? = null
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                val processName = getProcessName()
                if (packageName != processName) {
                    android.webkit.WebView.setDataDirectorySuffix(processName)
                }
            }
        } catch (_: Exception) {}

        // Pre-create Chromium WebView Code Cache directories to eliminate Chromium opendir error (2)
        try {
            val baseCache = cacheDir
            val jsCacheDir = java.io.File(baseCache, "WebView/Default/HTTP Cache/Code Cache/js")
            if (!jsCacheDir.exists()) jsCacheDir.mkdirs()
            val wasmCacheDir = java.io.File(baseCache, "WebView/Default/HTTP Cache/Code Cache/wasm")
            if (!wasmCacheDir.exists()) wasmCacheDir.mkdirs()
        } catch (_: Exception) {}

        try {
            FirebaseApp.initializeApp(this)
            Log.d(TAG, "Firebase initialized successfully in SubExchangeApplication")
        } catch (e: Exception) {
            Log.e(TAG, "Firebase initialization error: ${e.message}", e)
        }
    }
}
