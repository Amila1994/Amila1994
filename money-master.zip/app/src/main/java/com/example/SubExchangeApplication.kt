package com.example

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp

class SubExchangeApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            FirebaseApp.initializeApp(this)
            Log.d(TAG, "Firebase initialized successfully in SubExchangeApplication")
        } catch (e: Exception) {
            Log.e(TAG, "Firebase initialization error: ${e.message}", e)
        }
    }

    companion object {
        private const val TAG = "SubExchangeApp"
    }
}
