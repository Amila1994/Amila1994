package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.WatchHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WatchHistoryDao {
    @Query("SELECT * FROM watch_history WHERE userEmail = :email ORDER BY timestamp DESC")
    fun getHistoryForUser(email: String): Flow<List<WatchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: WatchHistoryEntity)

    @Query("SELECT COUNT(*) FROM watch_history WHERE userEmail = :email AND campaignId = :campaignId")
    suspend fun hasCompletedCampaign(email: String, campaignId: Long): Int
}
