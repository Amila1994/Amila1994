package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.WatchHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WatchHistoryDao {
    @Query("SELECT * FROM watch_history WHERE userEmail = :email ORDER BY timestamp DESC")
    fun getHistoryForUser(email: String): Flow<List<WatchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: WatchHistoryEntity)

    @Query("SELECT COUNT(*) FROM watch_history WHERE userEmail = :email AND campaignId = :campaignId")
    suspend fun hasCompletedCampaign(email: String, campaignId: Long): Int

    @Query("SELECT DISTINCT campaignId FROM watch_history WHERE userEmail = :email")
    fun getCompletedCampaignIds(email: String): Flow<List<Long>>

    @Query("SELECT * FROM watch_history WHERE userEmail = :email AND channelName = :channelName AND actionType = 'SUBSCRIBE' AND timestamp >= :sixMonthsAgoMillis LIMIT 1")
    suspend fun getRecentSubscription(email: String, channelName: String, sixMonthsAgoMillis: Long): WatchHistoryEntity?

    @Query("SELECT COUNT(*) FROM watch_history WHERE userEmail = :email AND channelName = :channelName AND (actionType = 'SUBSCRIBE' OR actionType = 'SUB_LIKE_COMMENT')")
    suspend fun countVerifiedSubscriptionsForChannel(email: String, channelName: String): Int

    @Query("SELECT * FROM watch_history WHERE userEmail = :email AND channelName = :channelName AND (actionType = 'SUBSCRIBE' OR actionType = 'SUB_LIKE_COMMENT') LIMIT 1")
    suspend fun getVerifiedSubscriptionForChannel(email: String, channelName: String): WatchHistoryEntity?

    @Query("SELECT * FROM watch_history WHERE userEmail = :email AND (actionType = 'SUBSCRIBE' OR actionType = 'SUB_LIKE_COMMENT')")
    suspend fun getAllVerifiedSubscriptions(email: String): List<WatchHistoryEntity>

    @Query("SELECT COUNT(*) FROM watch_history WHERE userEmail = :email AND videoTitle = :videoTitle AND (actionType = 'LIKE' OR actionType = 'SUB_LIKE_COMMENT')")
    suspend fun countVerifiedLikesForVideo(email: String, videoTitle: String): Int

    @Query("DELETE FROM watch_history WHERE timestamp < :olderThanMillis")
    suspend fun cleanupOldHistory(olderThanMillis: Long)
}
