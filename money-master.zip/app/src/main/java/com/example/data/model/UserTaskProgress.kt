package com.example.data.model

data class PromoUserProgress(
    val campaignsCount: Int = 0,
    val subscribesCount: Int = 0,
    val likesCount: Int = 0,
    val isRewardClaimed: Boolean = false
)

data class UserTasksState(
    val promoProgress: PromoUserProgress = PromoUserProgress(),
    val watchStreakCount: Int = 0,
    val isWatchStreakClaimed: Boolean = false,
    val isDailyLoginClaimed: Boolean = false,
    val referralsCount: Int = 0,
    val isInviteFriendClaimed: Boolean = false,
    val highWatchCount: Int = 0,
    val isHighWatchClaimed: Boolean = false,
    val isCommunityDeskClaimed: Boolean = false,
    val hasRedeemedReferral: Boolean = false
)
