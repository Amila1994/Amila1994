package com.example.data.audit

import android.content.Context
import android.util.Log
import com.example.data.firebase.FirebaseService
import com.example.data.local.dao.WatchHistoryDao
import com.example.data.local.entity.WatchHistoryEntity
import com.example.data.repository.SubExchangeRepository
import com.example.data.repository.ViolationResult
import com.example.data.youtube.YouTubeApiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Automated Background & App-Startup Subscription Audit Manager:
 *
 * 1. Checks all channels the user was previously verified and rewarded for by our app (via Room & Firestore).
 * 2. Queries YouTube Data API for the authenticated user's current subscriptions.
 * 3. If any rewarded channel now returns as `not subscribed` (meaning user unsubscribed externally via YouTube),
 *    automatically applies violation strikes (1/3, 2/3 warnings) or triggers a permanent ban (3/3 strikes)
 *    WITHOUT needing the user to revisit that specific campaign video.
 * 4. Ban state restricts access immediately and directs user to AccountBannedScreen with unban options
 *    (Admin Help message or watching 20 ads over 3 days).
 */
class SubscriptionAuditManager(
    private val repository: SubExchangeRepository,
    private val watchHistoryDao: WatchHistoryDao,
    private val context: Context
) {
    companion object {
        private const val TAG = "SubAuditManager"
    }

    private var periodicJob: Job? = null

    data class AuditReport(
        val totalChecked: Int,
        val fraudulentUnsubsDetected: List<String>,
        val newStrikesApplied: Int,
        val isAccountBanned: Boolean,
        val banReason: String? = null,
        val violationItems: List<com.example.data.model.FraudViolationItem> = emptyList()
    )

    /**
     * Executes an audit of all channels the user was verified and rewarded for by our app.
     * Can be invoked on app startup or periodically in the background.
     */
    suspend fun executeAudit(userEmail: String, oAuthToken: String? = null): AuditReport = withContext(Dispatchers.IO) {
        val cleanEmail = userEmail.trim().lowercase()
        if (cleanEmail.isBlank()) {
            return@withContext AuditReport(0, emptyList(), 0, false)
        }

        // 1. Primary: Fetch lifetime rewarded subscriptions directly from Firebase Firestore
        var cloudRecords = FirebaseService.getVerifiedRewardsFromFirestore(cleanEmail)

        if (cloudRecords.isNotEmpty()) {
            // Keep local Room DB updated as high-speed cache
            cloudRecords.forEach { record ->
                watchHistoryDao.insertHistory(
                    WatchHistoryEntity(
                        userEmail = cleanEmail,
                        campaignId = record.campaignId,
                        videoTitle = record.videoTitle,
                        channelName = record.channelName,
                        actionType = record.actionType,
                        coinsEarned = record.coinsEarned,
                        timestamp = record.timestamp
                    )
                )
            }
        } else {
            // Offline fallback: check local Room database cache
            val localSubs = watchHistoryDao.getAllVerifiedSubscriptions(cleanEmail)
            if (localSubs.isNotEmpty()) {
                cloudRecords = localSubs.map {
                    FirebaseService.VerifiedRewardRecord(
                        userEmail = it.userEmail,
                        campaignId = it.campaignId,
                        channelName = it.channelName,
                        videoTitle = it.videoTitle,
                        actionType = it.actionType,
                        coinsEarned = it.coinsEarned,
                        timestamp = it.timestamp
                    )
                }
            }
        }

        if (cloudRecords.isEmpty()) {
            Log.d(TAG, "No verified subscriptions found in Firestore lifetime records to audit for $cleanEmail")
            return@withContext AuditReport(0, emptyList(), 0, false)
        }

        val uniqueRewardedChannels = cloudRecords.map { it.channelName }.filter { it.isNotBlank() }.distinct()
        val fraudulentUnsubs = mutableListOf<String>()
        var strikesApplied = 0
        var isBanned = false
        var banReason: String? = null

        // 2. Query YouTube Data API if OAuth token is available
        val activeSubscribedChannelNames = mutableSetOf<String>()
        var isApiSuccess = false

        if (!oAuthToken.isNullOrBlank()) {
            val subListResult = YouTubeApiService.getMySubscribedChannels(oAuthToken)
            subListResult.onSuccess { snippets ->
                isApiSuccess = true
                snippets.forEach { snippet ->
                    snippet.title?.let { activeSubscribedChannelNames.add(it.trim().lowercase()) }
                }
            }.onFailure { err ->
                Log.d(TAG, "YouTube API getMySubscribedChannels error: ${err.message}")
            }
        }

        // 3. Evaluate each rewarded channel against live YouTube state
        for (channelName in uniqueRewardedChannels) {
            val isStillSubscribed = if (isApiSuccess) {
                activeSubscribedChannelNames.contains(channelName.trim().lowercase())
            } else {
                // If OAuth token is not configured or in background without live token,
                // do not falsely penalize user on network failure.
                true
            }

            if (!isStillSubscribed) {
                // Fraud Detected! The user earned coins for this channel from our app,
                // but YouTube Data API confirms they unsubscribed externally!
                Log.w(TAG, "🚨 External unsubscribe fraud detected for channel: '$channelName' by user: $cleanEmail")
                fraudulentUnsubs.add(channelName)

                val violationResult = repository.handleUnsubscribeOrUnlikeViolation(
                    userEmail = cleanEmail,
                    targetIdentifier = channelName,
                    isUnsubscribe = true,
                    campaignType = "SUBSCRIBE"
                )

                when (violationResult) {
                    is ViolationResult.Warning -> {
                        strikesApplied++
                    }
                    is ViolationResult.Banned -> {
                        isBanned = true
                        banReason = violationResult.reason
                        break // Account is now banned
                    }
                    null -> {}
                }
            }
        }

        val violationItems = if (fraudulentUnsubs.isNotEmpty()) {
            cloudRecords.filter { fraudulentUnsubs.contains(it.channelName) }.map { rec ->
                com.example.data.model.FraudViolationItem(
                    id = "${rec.channelName}_${rec.campaignId}",
                    campaignId = rec.campaignId,
                    channelName = rec.channelName,
                    channelId = rec.channelId,
                    videoTitle = rec.videoTitle.ifBlank { "YouTube Video for ${rec.channelName}" },
                    videoId = rec.videoId,
                    thumbnailUrl = if (rec.videoId.isNotBlank()) "https://img.youtube.com/vi/${rec.videoId}/hqdefault.jpg" else "",
                    directUrl = if (rec.videoId.isNotBlank()) "https://www.youtube.com/watch?v=${rec.videoId}" else "https://www.youtube.com/results?search_query=${rec.channelName}",
                    violationType = "BOTH",
                    isSubResolved = false,
                    isLikeResolved = false,
                    detectedTimestamp = System.currentTimeMillis()
                )
            }.distinctBy { it.channelName }
        } else {
            emptyList()
        }

        if (fraudulentUnsubs.isNotEmpty()) {
            FirebaseService.recordUnsubscribedChannelsInFirestore(cleanEmail, fraudulentUnsubs)
            FirebaseService.saveActiveViolationsInFirestore(
                userEmail = cleanEmail,
                violations = violationItems,
                strikeCount = strikesApplied.coerceAtLeast(1),
                isBanned = isBanned,
                banReason = banReason ?: ""
            )
        }

        AuditReport(
            totalChecked = uniqueRewardedChannels.size,
            fraudulentUnsubsDetected = fraudulentUnsubs,
            newStrikesApplied = strikesApplied,
            isAccountBanned = isBanned,
            banReason = banReason,
            violationItems = violationItems
        )
    }

    /**
     * Starts a periodic background audit using Kotlin Coroutines
     */
    fun startPeriodicAudit(
        scope: CoroutineScope,
        userEmailProvider: () -> String,
        tokenProvider: () -> String? = { null },
        intervalMinutes: Long = 60,
        onViolationDetected: (report: AuditReport) -> Unit = {}
    ) {
        periodicJob?.cancel()
        periodicJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(intervalMinutes * 60 * 1000L)
                val email = userEmailProvider()
                if (email.isNotBlank()) {
                    val report = executeAudit(email, tokenProvider())
                    if (report.fraudulentUnsubsDetected.isNotEmpty()) {
                        withContext(Dispatchers.Main) {
                            onViolationDetected(report)
                        }
                    }
                }
            }
        }
    }

    fun stopPeriodicAudit() {
        periodicJob?.cancel()
        periodicJob = null
    }
}
