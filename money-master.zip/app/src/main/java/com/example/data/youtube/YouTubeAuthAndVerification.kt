package com.example.data.youtube

import android.accounts.Account
import android.content.Context
import android.util.Log
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class YouTubeAuthAndVerification(private val context: Context) {

    companion object {
        private const val TAG = "YouTubeAuth"
        const val API_KEY = "AIzaSyA0KangLdcJuXYKluF3IC0uMKCF2HTsmpk"
        const val CLIENT_ID = "54062451476-qr8g1aah9amunv2nprnfpcav8lu8iu12.apps.googleusercontent.com"
        const val PACKAGE_NAME = "com.sub4sub.exchangeapp"
        const val YOUTUBE_READONLY_SCOPE = "https://www.googleapis.com/auth/youtube.readonly"
        const val YOUTUBE_FORCE_SSL_SCOPE = "https://www.googleapis.com/auth/youtube.force-ssl"

        private val httpClient: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build()
        }

        /**
         * Automatically requests and acquires the Google OAuth Access Token (ya29...)
         * using GoogleAuthUtil for the authenticated Google user.
         * Ensures that the token doesn't remain blank for YouTube Data API v3 verification.
         */
        suspend fun getOrRequestOAuthAccessToken(
            context: Context,
            userEmail: String? = null
        ): String? = withContext(Dispatchers.IO) {
            try {
                // 1. Identify Google Account
                val lastAccount: GoogleSignInAccount? = try {
                    GoogleSignIn.getLastSignedInAccount(context)
                } catch (_: Exception) { null }

                val email = userEmail?.trim()?.ifBlank { null }
                    ?: lastAccount?.email
                    ?: com.example.data.firebase.FirebaseService.auth?.currentUser?.email
                    ?: return@withContext null

                val scope = "oauth2:$YOUTUBE_READONLY_SCOPE $YOUTUBE_FORCE_SSL_SCOPE"

                // 2. Try with Account object
                try {
                    val account = lastAccount?.account ?: Account(email, "com.google")
                    val token = GoogleAuthUtil.getToken(context, account, scope)
                    if (!token.isNullOrBlank()) {
                        Log.i(TAG, "OAuth access token successfully retrieved via Account: ${token.take(12)}...")
                        return@withContext token
                    }
                } catch (e: Exception) {
                    Log.d(TAG, "GoogleAuthUtil with Account note: ${e.message}")
                }

                // 3. Fallback with email string
                try {
                    @Suppress("DEPRECATION")
                    val token = GoogleAuthUtil.getToken(context, email, scope)
                    if (!token.isNullOrBlank()) {
                        Log.i(TAG, "OAuth access token successfully retrieved via email string: ${token.take(12)}...")
                        return@withContext token
                    }
                } catch (e: Exception) {
                    Log.d(TAG, "GoogleAuthUtil with email note: ${e.message}")
                }

                // 4. Fallback: check cached SharedPreferences
                val prefs = context.getSharedPreferences("subexchange_auth_prefs", Context.MODE_PRIVATE)
                val cached = prefs.getString("oauth_access_token", null)
                if (!cached.isNullOrBlank()) {
                    return@withContext cached
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error acquiring Google OAuth Access Token: ${e.message}", e)
            }
            null
        }

        /**
         * Static helper: YouTube Data API v3 checkUserSubscription
         */
        suspend fun verifySubscription(
            accessToken: String,
            channelId: String
        ): Boolean = withContext(Dispatchers.IO) {
            try {
                val cleanChannelId = channelId.trim()
                if (cleanChannelId.isBlank() || !cleanChannelId.startsWith("UC")) {
                    Log.w(TAG, "Invalid YouTube channel ID provided: '$channelId'. Must be a 24-char UC... ID.")
                    return@withContext false
                }

                val cleanToken = accessToken.trim()
                if (cleanToken.isBlank()) {
                    Log.w(TAG, "OAuth Access Token is blank. Subscription verification requires an active OAuth token.")
                    return@withContext false
                }

                val bearerToken = if (cleanToken.startsWith("Bearer ", ignoreCase = true)) cleanToken else "Bearer $cleanToken"
                val url = "https://www.googleapis.com/youtube/v3/subscriptions?part=snippet&mine=true&forChannelId=$cleanChannelId"

                val request = Request.Builder()
                    .url(url)
                    .addHeader("Authorization", bearerToken)
                    .build()

                val response = httpClient.newCall(request).execute()
                val bodyString = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    val jsonObject = JSONObject(bodyString)
                    val items = jsonObject.optJSONArray("items")
                    return@withContext items != null && items.length() > 0
                }
                false
            } catch (e: Exception) {
                Log.e(TAG, "checkUserSubscription exception: ${e.message}")
                false
            }
        }
    }

    // 1. Google Sign-in Options configuration with YouTube Read-only and Force-SSL scopes
    fun getGoogleSignInOptions(): GoogleSignInOptions {
        return GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .requestIdToken(CLIENT_ID)
            .requestScopes(
                Scope(YOUTUBE_READONLY_SCOPE),
                Scope(YOUTUBE_FORCE_SSL_SCOPE)
            )
            .build()
    }

    fun getGoogleSignInClient(): GoogleSignInClient {
        return GoogleSignIn.getClient(context, getGoogleSignInOptions())
    }

    // 2. YouTube Data API v3 හරහා සබ්ස්ක්‍රප්ෂන් තත්ත්වය පරීක්ෂා කිරීම
    suspend fun checkUserSubscription(accessToken: String, channelId: String): Boolean {
        return verifySubscription(accessToken, channelId)
    }

    // 3. YouTube Data API v3 හරහා වීඩියෝ Like තත්ත්වය පරීක්ෂා කිරීම
    suspend fun checkUserVideoLike(accessToken: String, videoId: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val cleanToken = accessToken.trim()
                if (cleanToken.isBlank()) return@withContext false

                val bearerToken = if (cleanToken.startsWith("Bearer ", ignoreCase = true)) {
                    cleanToken
                } else {
                    "Bearer $cleanToken"
                }

                val url = "https://www.googleapis.com/youtube/v3/videos/getRating?id=${videoId.trim()}"

                val request = Request.Builder()
                    .url(url)
                    .addHeader("Authorization", bearerToken)
                    .build()

                val response = httpClient.newCall(request).execute()
                val bodyString = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    val jsonObject = JSONObject(bodyString)
                    val items = jsonObject.optJSONArray("items")
                    if (items != null && items.length() > 0) {
                        val rating = items.getJSONObject(0).optString("rating", "")
                        return@withContext rating.equals("like", ignoreCase = true)
                    }
                }
                false
            } catch (e: Exception) {
                false
            }
        }
    }
}
