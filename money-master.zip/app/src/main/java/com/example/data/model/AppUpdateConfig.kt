package com.example.data.model

data class AppUpdateConfig(
    val requiredVersionCode: Int = 1,
    val versionName: String = "1.0",
    val updateTitle: String = "Sub Exchange New Version Available!",
    val updateMessage: String = "A new update is available. Please update the app to continue watching videos and earning coins.",
    val downloadUrl: String = "https://play.google.com/store/apps/details?id=com.sub4sub.exchangeapp",
    val directApkDownloadUrl: String = "",
    val tutorialVideoUrl: String = "",
    val announcementImageUrl: String = "",
    val requireVideoWatch: Boolean = false,
    val isMandatory: Boolean = false,
    val lastAnnouncedTimestamp: Long = 0L
)
