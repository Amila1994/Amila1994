package com.example.data.model

import java.util.UUID

data class SupportChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val userEmail: String = "",
    val senderEmail: String = "",
    val senderName: String = "",
    val isAdmin: Boolean = false,
    val message: String = "",
    val imageUrl: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "sent"
)

data class SupportChatThread(
    val userEmail: String = "",
    val userName: String = "",
    val lastMessage: String = "",
    val lastSenderEmail: String = "",
    val lastTimestamp: Long = System.currentTimeMillis(),
    val unreadByAdmin: Boolean = false,
    val unreadByUser: Boolean = false,
    val totalMessages: Int = 0
)
