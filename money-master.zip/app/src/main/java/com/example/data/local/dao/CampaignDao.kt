package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.CampaignEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CampaignDao {
    @Query("SELECT * FROM campaigns WHERE isActive = 1 ORDER BY isAdminPriority DESC, isGlobal DESC, createdAt DESC")
    fun getActiveCampaigns(): Flow<List<CampaignEntity>>

    @Query("SELECT * FROM campaigns ORDER BY createdAt DESC")
    fun getAllCampaigns(): Flow<List<CampaignEntity>>

    @Query("SELECT * FROM campaigns WHERE creatorEmail = :email ORDER BY createdAt DESC")
    fun getCampaignsByCreator(email: String): Flow<List<CampaignEntity>>

    @Query("SELECT * FROM campaigns WHERE id = :id")
    suspend fun getCampaignById(id: Long): CampaignEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCampaign(campaign: CampaignEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCampaigns(campaigns: List<CampaignEntity>)

    @Update
    suspend fun updateCampaign(campaign: CampaignEntity)

    @Delete
    suspend fun deleteCampaign(campaign: CampaignEntity)

    @Query("UPDATE campaigns SET currentCount = currentCount + 1 WHERE id = :id")
    suspend fun incrementProgress(id: Long)

    @Query("UPDATE campaigns SET isActive = :isActive WHERE id = :id")
    suspend fun toggleActive(id: Long, isActive: Boolean)

    @Query("UPDATE campaigns SET isAdminPriority = :isPriority WHERE id = :id")
    suspend fun setAdminPriority(id: Long, isPriority: Boolean)

    @Query("UPDATE campaigns SET isGlobal = :isGlobal WHERE id = :id")
    suspend fun setGlobal(id: Long, isGlobal: Boolean)

    @Query("DELETE FROM campaigns WHERE creatorEmail = :email")
    suspend fun deleteCampaignsByCreator(email: String)
}
