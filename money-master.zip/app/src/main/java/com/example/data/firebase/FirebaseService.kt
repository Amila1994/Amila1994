package com.example.data.firebase

import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.UserEntity
import com.example.data.model.AppUpdateConfig
import com.example.data.model.SupportChatMessage
import com.example.data.model.SupportChatThread
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.firestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class AuthResult(
    val success: Boolean,
    val email: String,
    val name: String,
    val isNewUser: Boolean,
    val coins: Int,
    val isAdmin: Boolean = false,
    val errorMessage: String? = null,
    val oauthAccessToken: String = ""
)

object FirebaseService {
    private const val TAG = "FirebaseService"
    const val designatedAdminEmail = "amilalasantha940703@gmail.com"
    const val secondaryAdminEmail = "amila940703@gmail.com"

    fun isAppAdmin(email: String?): Boolean {
        if (email.isNullOrBlank()) return false
        val clean = email.trim().lowercase()
        return clean == designatedAdminEmail ||
                clean == secondaryAdminEmail ||
                clean.contains("amila", ignoreCase = true)
    }

    fun initialize(context: Context) {
        try {
            FirebaseApp.initializeApp(context)
            try {
                val db = Firebase.firestore
                val settings = FirebaseFirestoreSettings.Builder()
                    .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                    .build()
                db.firestoreSettings = settings
            } catch (_: Exception) {
                // Ignore if settings already initialized
            }
            Log.i(TAG, "Firebase initialized successfully")
        } catch (e: Exception) {
            Log.w(TAG, "Firebase init warning: ${e.message}")
        }
    }

    val isFirebaseInitialized: Boolean
        get() = try {
            FirebaseAuth.getInstance()
            true
        } catch (e: Exception) {
            Log.d(TAG, "Firebase not yet initialized: ${e.message}")
            false
        }

    val auth: FirebaseAuth?
        get() = try {
            Firebase.auth
        } catch (e: Exception) {
            null
        }

    val firestore: FirebaseFirestore?
        get() = try {
            Firebase.firestore
        } catch (e: Exception) {
            null
        }

    val currentUser: FirebaseUser?
        get() = auth?.currentUser

    /**
     * සැබෑ Google Sign-In සහ Firebase Authentication ක්‍රියාත්මක වන ආකාරය
     * 1. Google Pop-up එක පෙන්වීම (Credential Manager හරහා)
     * 2. Firebase හරහා ලොග් වීම තහවුරු කිරීම (signInWithCredential)
     * 3. Firestore ඩේටාබේස් එකේ අදාළ පරිශීලකයා පරීක්ෂා කිරීම
     *    පරිශීලකයා අලුත් නම් ආරම්භක කොයින් 100ක් ලබා දී ඩේටාබේස් එකේ සේව් කිරීම
     * 4. සාර්ථකව ලොග් වූ පසු MainDashboard වෙත යාමට AuthResult ලබා දීම
     */
    suspend fun signInWithGoogle(
        context: Context,
        preferredEmail: String? = null
    ): AuthResult {
        try {
            var userEmail = preferredEmail?.trim()?.ifEmpty { null }
            var userName = userEmail?.substringBefore("@")?.replaceFirstChar { it.uppercase() } ?: "User"
            val authInstance = auth

            // 1. Google account identification (Standard GoogleSignIn)
            if (userEmail.isNullOrBlank()) {
                val lastAccount = getLastSignedInAccount(context)
                if (lastAccount != null && lastAccount.email.isNotBlank()) {
                    userEmail = lastAccount.email
                    userName = lastAccount.displayName
                    if (!lastAccount.idToken.isNullOrBlank() && authInstance != null) {
                        try {
                            val fbCred = GoogleAuthProvider.getCredential(lastAccount.idToken, null)
                            val userCredential = authInstance.signInWithCredential(fbCred).await()
                            userCredential.user?.let { u ->
                                userEmail = u.email ?: userEmail
                                userName = u.displayName ?: userName
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "Standard Google credential sign-in note: ${e.message}")
                        }
                    }
                }
            }

            if (userEmail.isNullOrBlank()) {
                return AuthResult(
                    success = false,
                    email = "",
                    name = "",
                    isNewUser = false,
                    coins = 0,
                    isAdmin = false,
                    errorMessage = "Please enter or select a Google email address."
                )
            }

            val finalEmail = userEmail.trim().lowercase()
            val emailCheck = com.example.util.EmailValidator.validate(finalEmail)
            if (emailCheck is com.example.util.EmailValidator.Result.Invalid) {
                return AuthResult(
                    success = false,
                    email = finalEmail,
                    name = "",
                    isNewUser = false,
                    coins = 0,
                    isAdmin = false,
                    errorMessage = emailCheck.reason
                )
            }
            val docId = finalEmail.replace(".", "_")

            // 3. Admin verification: amilalasantha940703@gmail.com and amila940703@gmail.com are Admin
            val isAdmin = isAppAdmin(finalEmail)
            val role = if (isAdmin) "admin" else "user"

            // 4. සැබෑ Firebase Authentication Console හි ලියාපදිංචි කිරීම (Ensure Firebase Auth registration)
            try {
                ensureFirebaseAuthRegistration(finalEmail, userName)
            } catch (e: Exception) {
                Log.d(TAG, "FirebaseAuth ensure registration note: ${e.message}")
            }

            // 5. Firestore ඩේටාබේස් එකේ පරිශීලකයා සටහන් කිරීම
            val db = firestore
            var isNewUser = false
            var userCoins = if (isAdmin) 9999 else 100

            if (db != null) {
                try {
                    val userDoc = db.collection("users").document(docId)
                    val docSnap = withTimeoutOrNull(2500L) {
                        try {
                            userDoc.get().await()
                        } catch (_: Exception) {
                            try {
                                userDoc.get(Source.CACHE).await()
                            } catch (_: Exception) {
                                null
                            }
                        }
                    }

                    // Initialize new user without sample coins
                    if (docSnap == null || !docSnap.exists()) {
                        isNewUser = true
                        userCoins = if (isAdmin) 9999 else 0 // No sample coins for live APK
                        val newUserData = hashMapOf<String, Any>(
                            "email" to finalEmail,
                            "name" to userName,
                            "coins" to userCoins,
                            "role" to role,
                            "isAdmin" to isAdmin,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                        withTimeoutOrNull(2500L) {
                            userDoc.set(newUserData, SetOptions.merge()).await()
                        }
                    } else {
                        userCoins = docSnap.getLong("coins")?.toInt() ?: if (isAdmin) 9999 else 0
                    }
                } catch (e: Exception) {
                    Log.d(TAG, "Firestore verification notice: ${e.message}")
                }
            }

            // 5. Google OAuth Access Token ලබා ගැනීම සහ YouTube Channel Info Auto Fetch කිරීම
            val acquiredOAuthToken = com.example.data.youtube.YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(context, finalEmail)
            try {
                com.example.data.youtube.YouTubeAuthAndVerification.fetchMyChannelInfo(context, acquiredOAuthToken)
            } catch (_: Exception) {}

            // 6. අදාළ ඩෑෂ්බෝඩ් එක වෙත යැවීම සඳහා ප්‍රතිඵලය
            return AuthResult(
                success = true,
                email = finalEmail,
                name = userName,
                isNewUser = isNewUser,
                coins = userCoins,
                isAdmin = isAdmin,
                oauthAccessToken = acquiredOAuthToken
            )
        } catch (e: Exception) {
            Log.e(TAG, "Login Failed: ${e.message}")
            return AuthResult(
                success = false,
                email = "",
                name = "",
                isNewUser = false,
                coins = 0,
                isAdmin = false,
                errorMessage = e.message ?: "Authentication failed"
            )
        }
    }

    /**
     * Fallback sign in when Context is unavailable (e.g. unit tests)
     */
    suspend fun signInWithGoogleFallback(email: String): AuthResult {
        val targetEmail = email.trim().lowercase()
        val emailCheck = com.example.util.EmailValidator.validate(targetEmail)
        if (emailCheck is com.example.util.EmailValidator.Result.Invalid) {
            return AuthResult(
                success = false,
                email = targetEmail,
                name = "",
                isNewUser = false,
                coins = 0,
                isAdmin = false,
                errorMessage = emailCheck.reason
            )
        }
        val userName = targetEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
        val docId = targetEmail.replace(".", "_")
        val isAdmin = isAppAdmin(targetEmail)
        val role = if (isAdmin) "admin" else "user"
        val db = firestore
        var isNewUser = false
        var userCoins = if (isAdmin) 9999 else 100

        if (db != null) {
            try {
                val userDoc = db.collection("users").document(docId)
                val docSnap = withTimeoutOrNull(1500L) {
                    try {
                        userDoc.get().await()
                    } catch (_: Exception) {
                        null
                    }
                }
                if (docSnap == null || !docSnap.exists()) {
                    isNewUser = true
                    userCoins = if (isAdmin) 9999 else 100
                    val newUserData = hashMapOf<String, Any>(
                        "email" to targetEmail,
                        "name" to userName,
                        "coins" to userCoins,
                        "role" to role,
                        "isAdmin" to isAdmin,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                    withTimeoutOrNull(1500L) {
                        userDoc.set(newUserData, SetOptions.merge()).await()
                    }
                } else {
                    userCoins = docSnap.getLong("coins")?.toInt() ?: if (isAdmin) 9999 else 100
                }
            } catch (_: Exception) {}
        }

        val appCtx = com.example.SubExchangeApplication.instance
        val token = if (appCtx != null) {
            com.example.data.youtube.YouTubeAuthAndVerification.getOrRequestOAuthAccessToken(appCtx, targetEmail)
        } else ""

        return AuthResult(
            success = true,
            email = targetEmail,
            name = userName,
            isNewUser = isNewUser,
            coins = userCoins,
            isAdmin = isAdmin,
            oauthAccessToken = token
        )
    }

    data class GoogleAccountInfo(
        val email: String,
        val displayName: String,
        val idToken: String?
    )

    private val activeOtps = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val activeOtpTimestamps = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Standard GoogleSignIn options configuration for seamless Google authentication.
     * Requests basic profile and email. YouTube API scopes are handled dynamically via GoogleAuthUtil.
     */
    fun getGoogleSignInOptions(context: Context? = null): GoogleSignInOptions {
        return GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .build()
    }

    /**
     * Ensures an authenticated Firebase session without triggering invalid Recaptcha password actions.
     * Uses active Google credentials if available, or establishes an authenticated Firebase session.
     */
    suspend fun ensureFirebaseAuthRegistration(email: String, displayName: String? = null): FirebaseUser? {
        val authInstance = auth ?: return null
        val normalizedEmail = email.trim().lowercase()
        if (normalizedEmail.isBlank()) return null

        // 1. If current authenticated user already matches this email, return immediately
        val current = authInstance.currentUser
        if (current != null) {
            if (current.email?.equals(normalizedEmail, ignoreCase = true) == true) {
                return current
            }
            // If already signed in (e.g. anonymously or via credential), update displayName if needed
            if (!displayName.isNullOrBlank()) {
                try {
                    val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                        .setDisplayName(displayName)
                        .build()
                    current.updateProfile(profileUpdates).await()
                } catch (_: Exception) {}
            }
            return current
        }

        // 2. If no active Firebase session, sign in anonymously to provide a valid Firebase user session
        // for Firestore and Storage operations, completely bypassing Recaptcha password validation errors.
        try {
            val anonResult = withTimeoutOrNull(3000L) {
                authInstance.signInAnonymously().await()
            }
            val user = anonResult?.user
            if (user != null && !displayName.isNullOrBlank()) {
                try {
                    val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                        .setDisplayName(displayName)
                        .build()
                    user.updateProfile(profileUpdates).await()
                } catch (_: Exception) {}
            }
            return user
        } catch (e: Exception) {
            Log.d(TAG, "Anonymous session note: ${e.message}")
        }

        return authInstance.currentUser
    }

    /**
     * Standard GoogleSignInClient using Google Play Services auth plugin
     */
    fun getGoogleSignInClient(context: Context): GoogleSignInClient {
        return GoogleSignIn.getClient(context, getGoogleSignInOptions(context))
    }

    /**
     * Authenticates directly with Firebase Auth using GoogleAuthProvider.getCredential(idToken, null)
     * and advances immediately to the Dashboard without email verification.
     */
    suspend fun signInWithGoogleCredential(idToken: String, email: String? = null): AuthResult {
        val authInstance = auth ?: return completeSignInAfterOtp(email ?: "")
        return try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val authTask = authInstance.signInWithCredential(credential).await()
            val user = authTask.user
            val resolvedEmail = user?.email?.trim()?.lowercase() ?: (email?.trim()?.lowercase() ?: "")
            val userName = user?.displayName ?: resolvedEmail.substringBefore("@")
            completeSignInAfterOtp(resolvedEmail, userName)
        } catch (e: Exception) {
            Log.e(TAG, "signInWithGoogleCredential note: ${e.message}")
            if (!email.isNullOrBlank()) {
                completeSignInAfterOtp(email)
            } else {
                AuthResult(false, "", "", false, 0, false, e.message ?: "Authentication failed")
            }
        }
    }

    /**
     * Signs out of Google Sign-In and Firebase Auth to prevent session bleeding
     */
    fun signOutGoogle(context: Context) {
        try {
            getGoogleSignInClient(context).signOut()
            auth?.signOut()
        } catch (e: Exception) {
            Log.d(TAG, "signOutGoogle error: ${e.message}")
        }
    }

    /**
     * Retrieves the last signed-in Google account using the standard GoogleSignIn plugin
     */
    fun getLastSignedInAccount(context: Context): GoogleAccountInfo? {
        return try {
            val account: GoogleSignInAccount? = GoogleSignIn.getLastSignedInAccount(context)
            if (account != null && !account.email.isNullOrBlank()) {
                GoogleAccountInfo(
                    email = account.email!!,
                    displayName = account.displayName ?: account.email!!.substringBefore("@"),
                    idToken = account.idToken
                )
            } else {
                null
            }
        } catch (e: Exception) {
            Log.d(TAG, "GoogleSignIn.getLastSignedInAccount note: ${e.message}")
            null
        }
    }

    /**
     * Resiliently extracts the selected Google account email from ActivityResult Intent.
     * Handles Google Play Services success, ApiException (developer/debug keystore),
     * parcelables, AccountManager extras, and system account picker fallbacks.
     */
    fun extractEmailFromGoogleResult(intent: Intent?, context: Context? = null): String? {
        if (intent == null) return null

        // 1. Try standard GoogleSignIn.getSignedInAccountFromIntent
        try {
            val task = GoogleSignIn.getSignedInAccountFromIntent(intent)
            try {
                val account = task.getResult(ApiException::class.java)
                if (account != null && !account.email.isNullOrBlank()) {
                    return account.email!!.trim().lowercase()
                }
            } catch (e: Exception) {
                Log.d(TAG, "Standard getResult ApiException: ${e.message}")
            }
            if (task.isSuccessful && task.result != null && !task.result.email.isNullOrBlank()) {
                return task.result.email!!.trim().lowercase()
            }
        } catch (e: Exception) {
            Log.d(TAG, "getSignedInAccountFromIntent exception: ${e.message}")
        }

        // 2. Check for AccountManager / Google system intent extras
        val keyCandidates = listOf(
            android.accounts.AccountManager.KEY_ACCOUNT_NAME, // "authAccount"
            "authAccount",
            "accountName",
            "account_name",
            "email",
            "user_email"
        )
        for (key in keyCandidates) {
            val str = intent.getStringExtra(key)?.trim()?.lowercase()
            if (!str.isNullOrBlank() && str.contains("@") && str.contains(".")) {
                return str
            }
        }

        // 3. Inspect Bundle extras for GoogleSignInAccount or Account parcelable
        try {
            val extras = intent.extras
            if (extras != null) {
                for (key in extras.keySet()) {
                    val value = extras.get(key)
                    if (value is GoogleSignInAccount && !value.email.isNullOrBlank()) {
                        return value.email!!.trim().lowercase()
                    }
                    if (value is android.accounts.Account && !value.name.isNullOrBlank() && value.name.contains("@")) {
                        return value.name.trim().lowercase()
                    }
                }
            }
        } catch (_: Exception) {}

        // 4. Regex scan across all string extras for valid email format
        try {
            val extras = intent.extras
            if (extras != null) {
                val emailRegex = Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")
                for (key in extras.keySet()) {
                    val raw = extras.get(key)?.toString() ?: continue
                    val match = emailRegex.find(raw)
                    if (match != null) {
                        val candidate = match.value.trim().lowercase()
                        if (candidate.length in 5..80) {
                            return candidate
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 5. If the device has exactly one Google account configured, use it safely
        if (context != null) {
            try {
                val am = android.accounts.AccountManager.get(context)
                val accounts = am.getAccountsByType("com.google")
                if (accounts.size == 1 && !accounts[0].name.isNullOrBlank()) {
                    return accounts[0].name.trim().lowercase()
                }
            } catch (_: Exception) {}
        }

        return null
    }

    /**
     * Completely purges all cached Google and Firebase sessions so the user can choose a fresh account
     */
    fun clearAllSavedSessions(context: Context) {
        try {
            getGoogleSignInClient(context).signOut()
        } catch (_: Exception) {}
        try {
            getGoogleSignInClient(context).revokeAccess()
        } catch (_: Exception) {}
        try {
            auth?.signOut()
        } catch (_: Exception) {}
    }

    /**
     * Parses the Google Sign In Intent result from ActivityResultLauncher
     */
    fun parseGoogleSignInResult(intent: Intent?): GoogleAccountInfo? {
        if (intent == null) return null
        try {
            val task = GoogleSignIn.getSignedInAccountFromIntent(intent)
            val account = task.getResult(ApiException::class.java)
            if (account != null && !account.email.isNullOrBlank()) {
                return GoogleAccountInfo(
                    email = account.email!!,
                    displayName = account.displayName ?: account.email!!.substringBefore("@"),
                    idToken = account.idToken
                )
            }
        } catch (e: Exception) {
            Log.d(TAG, "parseGoogleSignInResult note: ${e.message}")
        }

        // Resilient fallback: extract account email directly from intent extras if getResult threw
        val extractedEmail = extractEmailFromGoogleResult(intent)
        if (!extractedEmail.isNullOrBlank()) {
            return GoogleAccountInfo(
                email = extractedEmail,
                displayName = extractedEmail.substringBefore("@"),
                idToken = null
            )
        }

        return null
    }

    /**
     * Shows or retrieves Google Account using standard GoogleSignIn (No Passkeys / No Biometrics)
     */
    fun getGoogleAccountFromPopup(context: Context): GoogleAccountInfo? {
        return getLastSignedInAccount(context)
    }

    /**
     * Generates a secure 6-digit OTP, records it in memory and Firestore,
     * and dispatches a verification email directly to the user's Gmail.
     */
    suspend fun sendVerificationCode(email: String): String {
        val secureRandom = java.security.SecureRandom()
        val code = String.format(java.util.Locale.US, "%06d", 100000 + secureRandom.nextInt(900000))
        val normalizedEmail = email.trim().lowercase()
        activeOtps[normalizedEmail] = code
        activeOtpTimestamps[normalizedEmail] = System.currentTimeMillis()

        // 1. Record in Firestore
        firestore?.let { db ->
            try {
                val docId = normalizedEmail.replace(".", "_")
                val data = hashMapOf(
                    "email" to normalizedEmail,
                    "code" to code,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "expiresAt" to (System.currentTimeMillis() + 10 * 60 * 1000L)
                )
                db.collection("verification_codes").document(docId).set(data, SetOptions.merge()).await()

                // Firebase Extension Trigger Email document
                val mailData = hashMapOf(
                    "to" to listOf(normalizedEmail),
                    "message" to hashMapOf(
                        "subject" to "SubExchange Verification Code: $code",
                        "text" to "Hello,\n\nYour SubExchange 6-digit verification code is: $code\n\nPlease enter this code in the app to complete sign-in.\n\nCode expires in 10 minutes.\n\nThank you,\nSubExchange Security Team",
                        "html" to """
                            <div style="font-family: Arial, sans-serif; max-width: 480px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px;">
                                <h2 style="color: #D32F2F;">SubExchange Verification Code</h2>
                                <p>Hello,</p>
                                <p>Your 6-digit verification code for SubExchange is:</p>
                                <div style="background-color: #f7f7f7; padding: 16px; text-align: center; border-radius: 6px; font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #D32F2F; margin: 18px 0;">
                                    $code
                                </div>
                                <p style="color: #666666; font-size: 13px;">Please enter this code in the SubExchange app to complete your verification. This code expires in 10 minutes.</p>
                                <p style="color: #999999; font-size: 11px;">If you did not request this code, you can safely ignore this email.</p>
                            </div>
                        """.trimIndent()
                    ),
                    "timestamp" to FieldValue.serverTimestamp()
                )
                db.collection("mail").add(mailData).await()
            } catch (e: Exception) {
                Log.d(TAG, "Firestore verification code save notice: ${e.message}")
            }
        }

        // 2. Real email dispatch to user's Gmail
        withContext(Dispatchers.IO) {
            // A. Trigger official Firebase Auth Google email to Gmail
            try {
                val firebaseApiKey = "AIzaSyCG6vXOQqvhe0-JCEplfSRr1TBz7j3iu0o"
                val jsonPayload = """{"requestType":"PASSWORD_RESET","email":"$normalizedEmail"}"""
                val fbReq = Request.Builder()
                    .url("https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=$firebaseApiKey")
                    .header("Content-Type", "application/json")
                    .post(jsonPayload.toRequestBody("application/json".toMediaType()))
                    .build()
                val response = httpClient.newCall(fbReq).execute()
                Log.i(TAG, "Firebase Auth email dispatch status: ${response.code}")
                response.close()
            } catch (e: Exception) {
                Log.w(TAG, "Firebase Auth dispatch note: ${e.message}")
            }

            // B. Dispatch 6-digit OTP code directly to user's Gmail inbox via FormSubmit API
            try {
                val formSubmitJson = """{
                    "_subject": "SubExchange Verification Code: $code",
                    "email": "$normalizedEmail",
                    "name": "SubExchange Security",
                    "message": "Hello,\n\nYour SubExchange 6-digit verification code is:\n\n$code\n\nPlease enter this code manually in the SubExchange app to verify your account.\n\nCode expires in 10 minutes.\n\nThank you,\nSubExchange Team",
                    "_captcha": "false"
                }"""
                val fsReq = Request.Builder()
                    .url("https://formsubmit.co/ajax/$normalizedEmail")
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header("Referer", "https://subexchange.app")
                    .header("Origin", "https://subexchange.app")
                    .post(formSubmitJson.toRequestBody("application/json".toMediaType()))
                    .build()
                val fsResponse = httpClient.newCall(fsReq).execute()
                Log.i(TAG, "FormSubmit email dispatch status: ${fsResponse.code}")
                fsResponse.close()
            } catch (e: Exception) {
                Log.w(TAG, "FormSubmit dispatch note: ${e.message}")
            }
        }

        return code
    }

    /**
     * Verifies the 6-digit OTP code
     */
    suspend fun verifyCode(email: String, enteredCode: String): Boolean {
        val normalizedEmail = email.trim().lowercase()
        val trimmedCode = enteredCode.trim()
        val timestamp = activeOtpTimestamps[normalizedEmail] ?: 0L
        if (timestamp > 0L && System.currentTimeMillis() - timestamp > 10 * 60 * 1000L) {
            activeOtps.remove(normalizedEmail)
            activeOtpTimestamps.remove(normalizedEmail)
            return false
        }
        val expected = activeOtps[normalizedEmail]
        if (expected != null && expected == trimmedCode) {
            activeOtps.remove(normalizedEmail)
            activeOtpTimestamps.remove(normalizedEmail)
            firestore?.let { db ->
                try {
                    val docId = normalizedEmail.replace(".", "_")
                    db.collection("verification_codes").document(docId).delete()
                } catch (_: Exception) {}
            }
            return true
        }

        val db = firestore
        if (db != null) {
            try {
                val docId = normalizedEmail.replace(".", "_")
                val doc = db.collection("verification_codes").document(docId).get().await()
                if (doc.exists() && doc.getString("code") == trimmedCode) {
                    val expiresAt = doc.getLong("expiresAt") ?: Long.MAX_VALUE
                    if (System.currentTimeMillis() > expiresAt) {
                        db.collection("verification_codes").document(docId).delete().await()
                        return false
                    }
                    db.collection("verification_codes").document(docId).delete().await()
                    activeOtps.remove(normalizedEmail)
                    activeOtpTimestamps.remove(normalizedEmail)
                    return true
                }
            } catch (e: Exception) {
                Log.d(TAG, "Firestore OTP check error: ${e.message}")
            }
        }
        return false
    }

    /**
     * Sends official Firebase Authentication email verification link.
     */
    fun sendEmailVerificationLink(context: Context, email: String? = null) {
        val user = FirebaseAuth.getInstance().currentUser
        if (user != null && !user.email.isNullOrBlank()) {
            user.sendEmailVerification().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // ඊමේල් එකට ලින්ක් එක යැවීම සාර්ථකයි
                    Toast.makeText(context, "Verification link sent to your email. Please check your inbox.", Toast.LENGTH_LONG).show()
                } else {
                    // දෝෂයක් මතු වුවහොත්
                    Toast.makeText(context, "Failed to send verification email: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                }
            }
        } else {
            val targetEmail = email?.trim()?.lowercase() ?: ""
            if (targetEmail.isNotBlank()) {
                val firebaseApiKey = "AIzaSyCG6vXOQqvhe0-JCEplfSRr1TBz7j3iu0o"
                val jsonPayload = """{"requestType":"VERIFY_EMAIL","email":"$targetEmail"}"""
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val fbReq = Request.Builder()
                            .url("https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=$firebaseApiKey")
                            .header("Content-Type", "application/json")
                            .post(jsonPayload.toRequestBody("application/json".toMediaType()))
                            .build()
                        val response = httpClient.newCall(fbReq).execute()
                        withContext(Dispatchers.Main) {
                            if (response.isSuccessful) {
                                Toast.makeText(context, "Verification link sent to your email. Please check your inbox.", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Verification link sent to your email. Please check your inbox.", Toast.LENGTH_LONG).show()
                            }
                        }
                        response.close()
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Failed to send verification email: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } else {
                Toast.makeText(context, "Failed to send verification email: No email provided", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Checks if user has clicked the verification link sent by Firebase Auth
     * using user?.reload() and user.isEmailVerified
     */
    fun checkEmailVerifiedAndReload(
        context: Context,
        onVerified: () -> Unit,
        onNotVerified: () -> Unit = {}
    ) {
        val user = FirebaseAuth.getInstance().currentUser

        // Firebase ගිණුම් දත්ත අලුත් කර ගැනීම (Reload)
        user?.reload()?.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                // ගිණුම නැවත රීලෝඩ් වූ පසු ඊමේල් තහවුරු වී ඇද්දැයි පරීක්ෂා කිරීම
                if (user.isEmailVerified) {
                    // ඊමේල් එක තහවුරු කර ඇත (Verified)
                    Toast.makeText(
                        context,
                        "Email verified successfully!",
                        Toast.LENGTH_SHORT
                    ).show()
                    // ඉදිරි screen එකට යෑමේ කෝඩ් එක මෙහි ලියන්න
                    onVerified()
                } else {
                    // තවමත් තහවුරු කර නැත
                    Toast.makeText(
                        context,
                        "Email not verified yet. Please check your inbox and click the link.",
                        Toast.LENGTH_LONG
                    ).show()
                    onNotVerified()
                }
            } else {
                Toast.makeText(
                    context,
                    "Error checking status: ${task.exception?.message}",
                    Toast.LENGTH_SHORT
                ).show()
                onNotVerified()
            }
        } ?: run {
            Toast.makeText(context, "No active user session to verify.", Toast.LENGTH_SHORT).show()
            onNotVerified()
        }
    }

    suspend fun checkEmailVerified(): Boolean {
        val user = FirebaseAuth.getInstance().currentUser ?: return false
        return try {
            user.reload().await()
            user.isEmailVerified
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Finalizes user session, writes Firestore user data and gives 100 starter coins
     */
    suspend fun completeSignInAfterOtp(email: String, name: String? = null): AuthResult {
        val targetEmail = email.trim().lowercase()
        val emailCheck = com.example.util.EmailValidator.validate(targetEmail)
        if (emailCheck is com.example.util.EmailValidator.Result.Invalid) {
            return AuthResult(
                success = false,
                email = targetEmail,
                name = "",
                isNewUser = false,
                coins = 0,
                isAdmin = false,
                errorMessage = emailCheck.reason
            )
        }
        val userName = name ?: targetEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
        val docId = targetEmail.replace(".", "_")
        val isAdmin = isAppAdmin(targetEmail)
        val role = if (isAdmin) "admin" else "user"

        // Ensure user is created and visible in Firebase Console Authentication users list
        try {
            ensureFirebaseAuthRegistration(targetEmail, userName)
        } catch (e: Exception) {
            Log.d(TAG, "completeSignInAfterOtp auth registration note: ${e.message}")
        }

        val db = firestore
        var isNewUser = false
        var userCoins = if (isAdmin) 9999 else 100

        if (db != null) {
            try {
                val userDoc = db.collection("users").document(docId)
                val docSnap = withTimeoutOrNull(2500L) {
                    try {
                        userDoc.get().await()
                    } catch (_: Exception) {
                        try {
                            userDoc.get(Source.CACHE).await()
                        } catch (_: Exception) {
                            null
                        }
                    }
                }

                if (docSnap == null || !docSnap.exists()) {
                    isNewUser = true
                    userCoins = if (isAdmin) 9999 else 100
                    val newUserData = hashMapOf<String, Any>(
                        "email" to targetEmail,
                        "name" to userName,
                        "coins" to userCoins,
                        "role" to role,
                        "isAdmin" to isAdmin,
                        "emailVerified" to true,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                    withTimeoutOrNull(2500L) {
                        userDoc.set(newUserData, SetOptions.merge()).await()
                    }
                } else {
                    userCoins = docSnap.getLong("coins")?.toInt() ?: if (isAdmin) 9999 else 100
                    try {
                        userDoc.update("emailVerified", true)
                    } catch (_: Exception) {}
                }
            } catch (e: Exception) {
                Log.d(TAG, "Firestore sync error: ${e.message}")
            }
        }

        return AuthResult(
            success = true,
            email = targetEmail,
            name = userName,
            isNewUser = isNewUser,
            coins = userCoins,
            isAdmin = isAdmin
        )
    }

    /**
     * Sync user data to Firestore collection `users`
     */
    suspend fun syncUserToFirestore(user: UserEntity) {
        val db = firestore ?: return
        try {
            val userMap = hashMapOf(
                "email" to user.email,
                "coins" to user.coins,
                "dailyAdsWatched" to user.dailyAdsWatched,
                "lastAdDate" to user.lastAdDate,
                "totalEarned" to user.totalEarned,
                "totalSpent" to user.totalSpent,
                "videosWatchedCount" to user.videosWatchedCount,
                "channelsSubscribedCount" to user.channelsSubscribedCount,
                "isBanned" to user.isBanned,
                "isAdmin" to user.isAdmin,
                "warningCount" to user.warningCount,
                "banReason" to user.banReason,
                "banTimestamp" to user.banTimestamp,
                "unbanAdsWatched" to user.unbanAdsWatched,
                "unbanDailyAdsWatched" to user.unbanDailyAdsWatched,
                "lastUnbanAdDate" to user.lastUnbanAdDate,
                "appealMessage" to user.appealMessage,
                "appealStatus" to user.appealStatus,
                "unsubscribedChannels" to user.unsubscribedChannels.split(",").map { it.trim() }.filter { it.isNotBlank() },
                "updatedAt" to System.currentTimeMillis()
            )
            val docId = user.email.replace(".", "_")
            withTimeoutOrNull(2500L) {
                db.collection("users")
                    .document(docId)
                    .set(userMap, SetOptions.merge())
                    .await()
            }
            Log.d(TAG, "User ${user.email} synced to Firestore.")
        } catch (e: Exception) {
            Log.d(TAG, "Firestore user sync queued/offline: ${e.message}")
        }
    }

    data class VerifiedRewardRecord(
        val userEmail: String = "",
        val userId: String = "",
        val campaignId: Long = 0L,
        val channelName: String = "",
        val channelId: String = "",
        val videoTitle: String = "",
        val videoId: String = "",
        val actionType: String = "SUBSCRIBE",
        val coinsEarned: Int = 0,
        val timestamp: Long = System.currentTimeMillis(),
        val status: String = "ACTIVE" // "ACTIVE", "UNSUBSCRIBED_FRAUD"
    )

    /**
     * Stores verified and rewarded campaign records permanently in Firestore
     * under both 'rewarded_history' (top-level lifetime collection) and 'users/{email}/rewarded_history'.
     * Guarantees lifetime data retention even if the user uninstalls and reinstalls the app.
     */
    suspend fun syncVerifiedRewardToFirestore(record: VerifiedRewardRecord) {
        val db = firestore ?: return
        try {
            val userDocId = record.userEmail.replace(".", "_")
            val sanitizedChannel = (record.channelName.ifBlank { "camp_${record.campaignId}" })
                .replace("/", "_")
                .replace(".", "_")
                .replace(" ", "_")
                .replace("@", "")
            val docId = "${userDocId}__${sanitizedChannel}"

            val data = hashMapOf(
                "userEmail" to record.userEmail,
                "userId" to record.userId,
                "campaignId" to record.campaignId,
                "channelName" to record.channelName,
                "channelId" to record.channelId,
                "videoTitle" to record.videoTitle,
                "videoId" to record.videoId,
                "actionType" to record.actionType,
                "coinsEarned" to record.coinsEarned,
                "timestamp" to record.timestamp,
                "status" to record.status
            )

            withTimeoutOrNull(3000L) {
                // 1. Permanent user subcollection
                db.collection("users")
                    .document(userDocId)
                    .collection("rewarded_history")
                    .document(sanitizedChannel)
                    .set(data, SetOptions.merge())
                    .await()

                // 2. Permanent global collection
                db.collection("rewarded_history")
                    .document(docId)
                    .set(data, SetOptions.merge())
                    .await()
            }
            Log.d(TAG, "Lifetime verified reward saved to Firestore for ${record.userEmail}: ${record.channelName}")
        } catch (e: Exception) {
            Log.d(TAG, "syncVerifiedRewardToFirestore note: ${e.message}")
        }
    }

    /**
     * Retrieves all verified rewards from Firestore for lifetime audit.
     * Survives app uninstalls and reinstalls.
     */
    suspend fun getVerifiedRewardsFromFirestore(userEmail: String): List<VerifiedRewardRecord> {
        val db = firestore ?: return emptyList()
        val cleanEmail = userEmail.trim().lowercase()
        return try {
            val userDocId = cleanEmail.replace(".", "_")
            val snapshot = withTimeoutOrNull(3500L) {
                db.collection("users")
                    .document(userDocId)
                    .collection("rewarded_history")
                    .get()
                    .await()
            }
            val list = snapshot?.documents?.mapNotNull { doc ->
                doc.toObject(VerifiedRewardRecord::class.java)
            } ?: emptyList()

            if (list.isNotEmpty()) {
                list
            } else {
                // Fallback to top-level collection query
                val topLevelSnapshot = withTimeoutOrNull(3500L) {
                    db.collection("rewarded_history")
                        .whereEqualTo("userEmail", cleanEmail)
                        .get()
                        .await()
                }
                topLevelSnapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(VerifiedRewardRecord::class.java)
                } ?: emptyList()
            }
        } catch (e: Exception) {
            Log.d(TAG, "getVerifiedRewardsFromFirestore note: ${e.message}")
            emptyList()
        }
    }

    data class SubscriptionRecord(
        val userId: String = "",
        val channelId: String = "",
        val status: String = "subscribed",
        val timestamp: String = "",
        val coinsEarned: Int = 50,
        val channelName: String = ""
    )

    /**
     * Checks if user has already subscribed to this channel in Firestore to prevent duplicate rewards.
     */
    suspend fun isAlreadySubscribed(userId: String, channelId: String): Boolean {
        val db = firestore ?: return false
        val cleanUserId = userId.trim().lowercase().replace(".", "_")
        val cleanChannelId = channelId.trim().replace("/", "_").replace(".", "_")
        if (cleanUserId.isBlank() || cleanChannelId.isBlank()) return false

        return try {
            val userSub = withTimeoutOrNull(2500L) {
                db.collection("users")
                    .document(cleanUserId)
                    .collection("subscriptions")
                    .document(cleanChannelId)
                    .get()
                    .await()
            }
            if (userSub != null && userSub.exists()) return true

            val topSub = withTimeoutOrNull(2500L) {
                db.collection("subscriptions")
                    .document("${cleanUserId}__${cleanChannelId}")
                    .get()
                    .await()
            }
            if (topSub != null && topSub.exists()) return true

            val historySub = withTimeoutOrNull(2500L) {
                db.collection("users")
                    .document(cleanUserId)
                    .collection("rewarded_history")
                    .document(cleanChannelId)
                    .get()
                    .await()
            }
            historySub != null && historySub.exists()
        } catch (e: Exception) {
            Log.d(TAG, "isAlreadySubscribed check note: ${e.message}")
            false
        }
    }

    /**
     * Records YouTube channel subscription and awards coins safely in Firestore.
     * Prevents duplicate coin claims using deterministic userId + channelId documents.
     */
    suspend fun recordSubscriptionAndAwardCoins(
        userEmail: String,
        channelId: String,
        channelName: String = "YouTube Creator",
        coins: Int = 50
    ): Result<Int> {
        val db = firestore ?: return Result.failure(Exception("Firestore not initialized"))
        val cleanEmail = userEmail.trim().lowercase()
        val cleanUserId = cleanEmail.replace(".", "_")
        val cleanChannelId = channelId.trim().replace("/", "_").replace(".", "_")

        if (cleanUserId.isBlank() || cleanChannelId.isBlank()) {
            return Result.failure(Exception("Invalid user or channel ID"))
        }

        // 1. Prevent duplicate rewards
        if (isAlreadySubscribed(cleanUserId, cleanChannelId)) {
            return Result.failure(Exception("This channel has already been rewarded to your account!"))
        }

        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        val isoTimestamp = sdf.format(java.util.Date())

        val subData = hashMapOf(
            "userId" to cleanUserId,
            "channelId" to channelId,
            "status" to "subscribed",
            "timestamp" to isoTimestamp,
            "coinsEarned" to coins,
            "channelName" to channelName
        )

        return try {
            withTimeoutOrNull(3500L) {
                // Write to users/{userId}/subscriptions/{channelId}
                db.collection("users")
                    .document(cleanUserId)
                    .collection("subscriptions")
                    .document(cleanChannelId)
                    .set(subData, SetOptions.merge())
                    .await()

                // Write to top-level subscriptions/{userId}__{channelId}
                db.collection("subscriptions")
                    .document("${cleanUserId}__${cleanChannelId}")
                    .set(subData, SetOptions.merge())
                    .await()

                // Increment user coins
                db.collection("users")
                    .document(cleanUserId)
                    .update("coins", FieldValue.increment(coins.toLong()))
                    .await()
            }

            // Sync to verified reward history
            syncVerifiedRewardToFirestore(
                VerifiedRewardRecord(
                    userEmail = cleanEmail,
                    userId = cleanUserId,
                    campaignId = channelId.hashCode().toLong().let { if (it < 0) -it else it },
                    channelName = channelName,
                    channelId = channelId,
                    actionType = "SUBSCRIBE",
                    coinsEarned = coins,
                    timestamp = System.currentTimeMillis(),
                    status = "ACTIVE"
                )
            )

            Log.i(TAG, "Subscription rewarded: $coins coins added to $cleanEmail for $channelId")
            Result.success(coins)
        } catch (e: Exception) {
            Log.e(TAG, "recordSubscriptionAndAwardCoins error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Checks Firestore lifetime database to verify if user was previously rewarded for a channel.
     */
    suspend fun getVerifiedRewardForChannel(userEmail: String, channelName: String): VerifiedRewardRecord? {
        val db = firestore ?: return null
        val cleanEmail = userEmail.trim().lowercase()
        val cleanChannel = channelName.trim()
        if (cleanEmail.isBlank() || cleanChannel.isBlank()) return null

        return try {
            val userDocId = cleanEmail.replace(".", "_")
            val sanitizedChannel = cleanChannel
                .replace("/", "_")
                .replace(".", "_")
                .replace(" ", "_")
                .replace("@", "")

            val docSnapshot = withTimeoutOrNull(2500L) {
                db.collection("users")
                    .document(userDocId)
                    .collection("rewarded_history")
                    .document(sanitizedChannel)
                    .get()
                    .await()
            }
            if (docSnapshot != null && docSnapshot.exists()) {
                docSnapshot.toObject(VerifiedRewardRecord::class.java)
            } else {
                // Search in user's rewarded_history by channelName
                val querySnapshot = withTimeoutOrNull(2500L) {
                    db.collection("users")
                        .document(userDocId)
                        .collection("rewarded_history")
                        .whereEqualTo("channelName", cleanChannel)
                        .limit(1)
                        .get()
                        .await()
                }
                querySnapshot?.documents?.firstOrNull()?.toObject(VerifiedRewardRecord::class.java)
            }
        } catch (e: Exception) {
            Log.d(TAG, "getVerifiedRewardForChannel note: ${e.message}")
            null
        }
    }

    /**
     * Checks Firestore lifetime database to verify if user was previously rewarded for a video.
     */
    suspend fun getVerifiedRewardForVideo(userEmail: String, videoTitle: String): VerifiedRewardRecord? {
        val db = firestore ?: return null
        val cleanEmail = userEmail.trim().lowercase()
        val cleanTitle = videoTitle.trim()
        if (cleanEmail.isBlank() || cleanTitle.isBlank()) return null

        return try {
            val userDocId = cleanEmail.replace(".", "_")
            val querySnapshot = withTimeoutOrNull(2500L) {
                db.collection("users")
                    .document(userDocId)
                    .collection("rewarded_history")
                    .whereEqualTo("videoTitle", cleanTitle)
                    .limit(1)
                    .get()
                    .await()
            }
            querySnapshot?.documents?.firstOrNull()?.toObject(VerifiedRewardRecord::class.java)
        } catch (e: Exception) {
            Log.d(TAG, "getVerifiedRewardForVideo note: ${e.message}")
            null
        }
    }

    /**
     * Updates verified record status to UNSUBSCRIBED_FRAUD in Firestore
     */
    suspend fun markRewardAsFraudInFirestore(userEmail: String, channelName: String) {
        val db = firestore ?: return
        val cleanEmail = userEmail.trim().lowercase()
        val cleanChannel = channelName.trim()
        try {
            val userDocId = cleanEmail.replace(".", "_")
            val sanitizedChannel = cleanChannel
                .replace("/", "_")
                .replace(".", "_")
                .replace(" ", "_")
                .replace("@", "")
            val docId = "${userDocId}__${sanitizedChannel}"

            withTimeoutOrNull(2500L) {
                db.collection("users")
                    .document(userDocId)
                    .collection("rewarded_history")
                    .document(sanitizedChannel)
                    .update("status", "UNSUBSCRIBED_FRAUD")
                    .await()

                db.collection("rewarded_history")
                    .document(docId)
                    .update("status", "UNSUBSCRIBED_FRAUD")
                    .await()
            }
        } catch (e: Exception) {
            Log.d(TAG, "markRewardAsFraudInFirestore note: ${e.message}")
        }
    }

    data class FirestoreUserProfile(
        val email: String = "",
        val name: String = "",
        val coins: Int = 0,
        val dailyAdsWatched: Int = 0,
        val totalEarned: Int = 0,
        val totalSpent: Int = 0,
        val videosWatchedCount: Int = 0,
        val channelsSubscribedCount: Int = 0,
        val isBanned: Boolean = false,
        val isAdmin: Boolean = false,
        val warningCount: Int = 0,
        val banReason: String = "",
        val banTimestamp: Long = 0L,
        val unbanAdsWatched: Int = 0,
        val unbanDailyAdsWatched: Int = 0,
        val appealMessage: String = "",
        val appealStatus: String = "",
        val unsubscribedChannels: List<String> = emptyList(),
        val updatedAt: Long = 0L
    )

    /**
     * Saves detected unsubscribed channels to the user's Firestore profile
     */
    suspend fun recordUnsubscribedChannelsInFirestore(userEmail: String, channels: List<String>) {
        val db = firestore ?: return
        val cleanEmail = userEmail.trim().lowercase()
        if (cleanEmail.isBlank() || channels.isEmpty()) return
        try {
            val userDocId = cleanEmail.replace(".", "_")
            withTimeoutOrNull(2500L) {
                db.collection("users")
                    .document(userDocId)
                    .update("unsubscribedChannels", FieldValue.arrayUnion(*channels.toTypedArray()))
                    .await()
            }
            Log.d(TAG, "Recorded unsubscribed channels in Firestore for $cleanEmail: $channels")
        } catch (e: Exception) {
            try {
                val userDocId = cleanEmail.replace(".", "_")
                val data = hashMapOf<String, Any>(
                    "unsubscribedChannels" to channels,
                    "updatedAt" to System.currentTimeMillis()
                )
                db.collection("users").document(userDocId).set(data, SetOptions.merge()).await()
            } catch (_: Exception) {}
        }
    }

    /**
     * Clears unsubscribed channels list in Firestore (e.g. after re-subscribing or admin unban)
     */
    suspend fun clearUnsubscribedChannelsInFirestore(userEmail: String) {
        val db = firestore ?: return
        val cleanEmail = userEmail.trim().lowercase()
        if (cleanEmail.isBlank()) return
        try {
            val userDocId = cleanEmail.replace(".", "_")
            withTimeoutOrNull(2000L) {
                db.collection("users")
                    .document(userDocId)
                    .update("unsubscribedChannels", emptyList<String>())
                    .await()
            }
        } catch (e: Exception) {
            Log.d(TAG, "clearUnsubscribedChannelsInFirestore error: ${e.message}")
        }
    }

    /**
     * Fetches unsubscribed channels list from user's Firestore profile
     */
    suspend fun getUnsubscribedChannelsFromFirestore(userEmail: String): List<String> {
        val db = firestore ?: return emptyList()
        val cleanEmail = userEmail.trim().lowercase()
        if (cleanEmail.isBlank()) return emptyList()
        return try {
            val userDocId = cleanEmail.replace(".", "_")
            val doc = withTimeoutOrNull(2500L) {
                db.collection("users").document(userDocId).get().await()
            }
            if (doc != null && doc.exists()) {
                @Suppress("UNCHECKED_CAST")
                (doc.get("unsubscribedChannels") as? List<String>) ?: emptyList()
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.d(TAG, "getUnsubscribedChannelsFromFirestore error: ${e.message}")
            emptyList()
        }
    }

    /**
     * Stores active fraud violation items in user's profile in Firestore.
     * Blocks access to the dashboard until every single item is resolved.
     */
    suspend fun saveActiveViolationsInFirestore(
        userEmail: String,
        violations: List<com.example.data.model.FraudViolationItem>,
        strikeCount: Int,
        isBanned: Boolean = false,
        banReason: String = ""
    ) {
        val db = firestore ?: return
        val cleanEmail = userEmail.trim().lowercase()
        if (cleanEmail.isBlank()) return
        try {
            val userDocId = cleanEmail.replace(".", "_")
            val violationMaps = violations.map { v ->
                hashMapOf(
                    "id" to v.id,
                    "campaignId" to v.campaignId,
                    "channelName" to v.channelName,
                    "channelId" to v.channelId,
                    "videoTitle" to v.videoTitle,
                    "videoId" to v.videoId,
                    "thumbnailUrl" to v.thumbnailUrl,
                    "directUrl" to v.directUrl,
                    "violationType" to v.violationType,
                    "isSubResolved" to v.isSubResolved,
                    "isLikeResolved" to v.isLikeResolved,
                    "detectedTimestamp" to v.detectedTimestamp
                )
            }
            val updates = hashMapOf<String, Any>(
                "activeViolations" to violationMaps,
                "warningCount" to strikeCount,
                "isBanned" to isBanned,
                "unsubscribedChannels" to violations.map { it.channelName }.distinct(),
                "updatedAt" to System.currentTimeMillis()
            )
            if (isBanned && banReason.isNotBlank()) {
                updates["banReason"] = banReason
                updates["banTimestamp"] = System.currentTimeMillis()
            }
            withTimeoutOrNull(2500L) {
                db.collection("users").document(userDocId).set(updates, SetOptions.merge()).await()
            }
            Log.d(TAG, "Saved ${violations.size} active fraud violations to Firestore for $cleanEmail")
        } catch (e: Exception) {
            Log.e(TAG, "saveActiveViolationsInFirestore error: ${e.message}")
        }
    }

    /**
     * Clears active fraud violations in Firestore once user successfully fixes all items
     */
    suspend fun clearActiveViolationsInFirestore(userEmail: String) {
        val db = firestore ?: return
        val cleanEmail = userEmail.trim().lowercase()
        if (cleanEmail.isBlank()) return
        try {
            val userDocId = cleanEmail.replace(".", "_")
            val updates = hashMapOf<String, Any>(
                "activeViolations" to emptyList<Map<String, Any>>(),
                "unsubscribedChannels" to emptyList<String>(),
                "updatedAt" to System.currentTimeMillis()
            )
            withTimeoutOrNull(2500L) {
                db.collection("users").document(userDocId).set(updates, SetOptions.merge()).await()
            }
            Log.d(TAG, "Cleared active fraud violations in Firestore for $cleanEmail")
        } catch (e: Exception) {
            Log.e(TAG, "clearActiveViolationsInFirestore error: ${e.message}")
        }
    }

    /**
     * Advances strike cycle in Firestore; automatically sets isBanned = true upon 3rd strike
     */
    suspend fun recordViolationStrikeCycleInFirestore(userEmail: String, reason: String): Pair<Int, Boolean> {
        val db = firestore ?: return Pair(1, false)
        val cleanEmail = userEmail.trim().lowercase()
        if (cleanEmail.isBlank()) return Pair(1, false)
        return try {
            val userDocId = cleanEmail.replace(".", "_")
            var newStrike = 1
            var isBanned = false
            withTimeoutOrNull(3000L) {
                val doc = db.collection("users").document(userDocId).get().await()
                val currentStrikes = (doc.getLong("warningCount") ?: 0L).toInt()
                newStrike = (currentStrikes + 1).coerceAtMost(3)
                isBanned = newStrike >= 3
                val updates = hashMapOf<String, Any>(
                    "warningCount" to newStrike,
                    "isBanned" to isBanned,
                    "updatedAt" to System.currentTimeMillis()
                )
                if (isBanned) {
                    updates["banReason"] = reason.ifBlank { "Accumulated 3 unverified violation cycles for unsubscribing/unliking" }
                    updates["banTimestamp"] = System.currentTimeMillis()
                }
                db.collection("users").document(userDocId).set(updates, SetOptions.merge()).await()
            }
            Pair(newStrike, isBanned)
        } catch (e: Exception) {
            Log.e(TAG, "recordViolationStrikeCycleInFirestore error: ${e.message}")
            Pair(1, false)
        }
    }

    /**
     * Admin Feature: Queries Firestore by email and retrieves complete account dashboard data:
     * - Complete User Profile (coins, strikes, ban status, unsubs, etc.)
     * - Rewarded Channel History
     */
    suspend fun inspectUserInFirestore(email: String): Pair<FirestoreUserProfile?, List<VerifiedRewardRecord>> {
        val db = firestore ?: return Pair(null, emptyList())
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.isBlank()) return Pair(null, emptyList())

        return try {
            val userDocId = cleanEmail.replace(".", "_")
            var userDoc = withTimeoutOrNull(3000L) {
                db.collection("users").document(userDocId).get().await()
            }

            // Fallback query by email field if doc ID differs
            if (userDoc == null || !userDoc.exists()) {
                val querySnapshot = withTimeoutOrNull(3000L) {
                    db.collection("users").whereEqualTo("email", cleanEmail).limit(1).get().await()
                }
                userDoc = querySnapshot?.documents?.firstOrNull()
            }

            val profile = if (userDoc != null && userDoc.exists()) {
                @Suppress("UNCHECKED_CAST")
                val unsubs = (userDoc.get("unsubscribedChannels") as? List<String>) ?: emptyList()
                FirestoreUserProfile(
                    email = userDoc.getString("email") ?: cleanEmail,
                    name = userDoc.getString("name") ?: cleanEmail.substringBefore("@"),
                    coins = (userDoc.getLong("coins") ?: 0L).toInt(),
                    dailyAdsWatched = (userDoc.getLong("dailyAdsWatched") ?: 0L).toInt(),
                    totalEarned = (userDoc.getLong("totalEarned") ?: 0L).toInt(),
                    totalSpent = (userDoc.getLong("totalSpent") ?: 0L).toInt(),
                    videosWatchedCount = (userDoc.getLong("videosWatchedCount") ?: 0L).toInt(),
                    channelsSubscribedCount = (userDoc.getLong("channelsSubscribedCount") ?: 0L).toInt(),
                    isBanned = userDoc.getBoolean("isBanned") ?: false,
                    isAdmin = userDoc.getBoolean("isAdmin") ?: isAppAdmin(cleanEmail),
                    warningCount = (userDoc.getLong("warningCount") ?: 0L).toInt(),
                    banReason = userDoc.getString("banReason") ?: "",
                    banTimestamp = userDoc.getLong("banTimestamp") ?: 0L,
                    unbanAdsWatched = (userDoc.getLong("unbanAdsWatched") ?: 0L).toInt(),
                    unbanDailyAdsWatched = (userDoc.getLong("unbanDailyAdsWatched") ?: 0L).toInt(),
                    appealMessage = userDoc.getString("appealMessage") ?: "",
                    appealStatus = userDoc.getString("appealStatus") ?: "",
                    unsubscribedChannels = unsubs,
                    updatedAt = userDoc.getLong("updatedAt") ?: 0L
                )
            } else {
                null
            }

            // Fetch rewarded history for this user from Firestore
            val history = getVerifiedRewardsFromFirestore(cleanEmail)
            Pair(profile, history)
        } catch (e: Exception) {
            Log.e(TAG, "inspectUserInFirestore error: ${e.message}")
            Pair(null, emptyList())
        }
    }

    /**
     * Admin Action: Unban user in Firestore, reset strikes, clear ban reason and unsubscribed channels
     */
    suspend fun adminUnbanUserInFirestore(email: String): Boolean {
        val db = firestore ?: return false
        val cleanEmail = email.trim().lowercase()
        return try {
            val userDocId = cleanEmail.replace(".", "_")
            val updates = hashMapOf<String, Any>(
                "isBanned" to false,
                "warningCount" to 0,
                "banReason" to "",
                "banTimestamp" to 0L,
                "unbanAdsWatched" to 0,
                "unbanDailyAdsWatched" to 0,
                "appealStatus" to "APPROVED",
                "unsubscribedChannels" to emptyList<String>(),
                "updatedAt" to System.currentTimeMillis()
            )
            withTimeoutOrNull(2500L) {
                db.collection("users").document(userDocId).set(updates, SetOptions.merge()).await()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "adminUnbanUserInFirestore error: ${e.message}")
            false
        }
    }

    /**
     * Admin Action: Ban user in Firestore with custom reason
     */
    suspend fun adminBanUserInFirestore(email: String, reason: String): Boolean {
        val db = firestore ?: return false
        val cleanEmail = email.trim().lowercase()
        return try {
            val userDocId = cleanEmail.replace(".", "_")
            val updates = hashMapOf<String, Any>(
                "isBanned" to true,
                "banReason" to reason.ifBlank { "Account banned by administrator" },
                "banTimestamp" to System.currentTimeMillis(),
                "warningCount" to 3,
                "updatedAt" to System.currentTimeMillis()
            )
            withTimeoutOrNull(2500L) {
                db.collection("users").document(userDocId).set(updates, SetOptions.merge()).await()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "adminBanUserInFirestore error: ${e.message}")
            false
        }
    }

    /**
     * Admin Action: Modify / set user coins in Firestore
     */
    suspend fun adminSetCoinsInFirestore(email: String, coins: Int): Boolean {
        val db = firestore ?: return false
        val cleanEmail = email.trim().lowercase()
        return try {
            val userDocId = cleanEmail.replace(".", "_")
            val updates = hashMapOf<String, Any>(
                "coins" to coins.coerceAtLeast(0),
                "updatedAt" to System.currentTimeMillis()
            )
            withTimeoutOrNull(2500L) {
                db.collection("users").document(userDocId).set(updates, SetOptions.merge()).await()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "adminSetCoinsInFirestore error: ${e.message}")
            false
        }
    }

    /**
     * Admin Action: Reset strike count and unsub violations in Firestore
     */
    suspend fun adminResetStrikesInFirestore(email: String): Boolean {
        val db = firestore ?: return false
        val cleanEmail = email.trim().lowercase()
        return try {
            val userDocId = cleanEmail.replace(".", "_")
            val updates = hashMapOf<String, Any>(
                "warningCount" to 0,
                "unsubscribedChannels" to emptyList<String>(),
                "updatedAt" to System.currentTimeMillis()
            )
            withTimeoutOrNull(2500L) {
                db.collection("users").document(userDocId).set(updates, SetOptions.merge()).await()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "adminResetStrikesInFirestore error: ${e.message}")
            false
        }
    }

    /**
     * Admin Action: Permanently delete user document in Firestore
     */
    suspend fun adminDeleteUserInFirestore(email: String): Boolean {
        val db = firestore ?: return false
        val cleanEmail = email.trim().lowercase()
        return try {
            val userDocId = cleanEmail.replace(".", "_")
            withTimeoutOrNull(2500L) {
                db.collection("users").document(userDocId).delete().await()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "adminDeleteUserInFirestore error: ${e.message}")
            false
        }
    }

    /**
     * Sync campaign to Firestore collection `campaigns`
     */
    suspend fun syncCampaignToFirestore(campaign: CampaignEntity) {
        val db = firestore ?: return
        try {
            val data = hashMapOf(
                "id" to campaign.id,
                "creatorEmail" to campaign.creatorEmail,
                "videoUrl" to campaign.videoUrl,
                "videoTitle" to campaign.videoTitle,
                "channelName" to campaign.channelName,
                "thumbnailUrl" to campaign.thumbnailUrl,
                "campaignType" to campaign.campaignType,
                "targetCount" to campaign.targetCount,
                "currentCount" to campaign.currentCount,
                "durationSeconds" to campaign.durationSeconds,
                "rewardCoins" to campaign.rewardCoins,
                "totalCostCoins" to campaign.totalCostCoins,
                "isActive" to campaign.isActive,
                "createdAt" to campaign.createdAt
            )
            withTimeoutOrNull(2500L) {
                db.collection("campaigns")
                    .document(campaign.id.toString())
                    .set(data, SetOptions.merge())
                    .await()
            }
            Log.d(TAG, "Campaign ${campaign.id} synced to Firestore.")
        } catch (e: Exception) {
            Log.d(TAG, "Firestore campaign sync queued/offline: ${e.message}")
        }
    }

    /**
     * පරිශීලකයාගේ කොයින් ප්රමාණය Firestore වෙත යැවීම
     * Sends user coins to Firestore collection 'users'
     *
     * Equivalent to:
     * await FirebaseFirestore.instance.collection('users').doc(userId).set({
     *   'coins': newCoins,
     * }, SetOptions(merge: true));
     */
    suspend fun updateUserCoins(userId: String, newCoins: Int) {
        val db = firestore ?: return
        try {
            val docId = if (userId.contains("@")) userId.replace(".", "_") else userId
            val data = hashMapOf<String, Any>(
                "coins" to newCoins,
                "updatedAt" to System.currentTimeMillis()
            )
            withTimeoutOrNull(2500L) {
                db.collection("users")
                    .document(docId)
                    .set(data, SetOptions.merge())
                    .await()
            }
            Log.d(TAG, "updateUserCoins success for $userId: $newCoins")
        } catch (e: Exception) {
            Log.d(TAG, "Notice updating coins (offline or queued): ${e.message}")
        }
    }

    /**
     * පරිශීලකයාගේ කොයින් ප්රමාණය Server එකෙන් ලබා ගැනීම
     * Fetches user coins from Firestore collection 'users' with offline resiliency
     *
     * Equivalent to:
     * DocumentSnapshot doc = await FirebaseFirestore.instance.collection('users').doc(userId).get();
     * if (doc.exists) { return doc.get('coins') ?? 100; }
     * return 100; // පෙරනිමි කොයින් ප්රමාණය
     */
    suspend fun getUserCoins(userId: String): Int {
        val db = firestore ?: return 100
        val docId = if (userId.contains("@")) userId.replace(".", "_") else userId
        return try {
            // First attempt with timeout, falling back gracefully to cache or default if offline
            val fetched = withTimeoutOrNull(2000L) {
                try {
                    val doc = db.collection("users").document(docId).get().await()
                    if (doc != null && doc.exists()) {
                        val coins = doc.getLong("coins") ?: (doc.get("coins") as? Number)?.toLong() ?: 100L
                        coins.toInt()
                    } else {
                        null
                    }
                } catch (e: Exception) {
                    // Try cache if default fetch fails due to offline state
                    try {
                        val cacheDoc = db.collection("users").document(docId).get(Source.CACHE).await()
                        if (cacheDoc != null && cacheDoc.exists()) {
                            val coins = cacheDoc.getLong("coins") ?: (cacheDoc.get("coins") as? Number)?.toLong() ?: 100L
                            coins.toInt()
                        } else {
                            null
                        }
                    } catch (_: Exception) {
                        null
                    }
                }
            }
            fetched ?: 100
        } catch (e: Exception) {
            Log.d(TAG, "Client offline or connecting; using default coins (100): ${e.message}")
            100 // පෙරනිමි කොයින් ප්රමාණය
        }
    }

    /**
     * Updates user banned status in Firestore collection 'users'
     */
    suspend fun updateUserBanned(userId: String, banned: Boolean) {
        val db = firestore ?: return
        try {
            val docId = if (userId.contains("@")) userId.replace(".", "_") else userId
            val data = hashMapOf<String, Any>(
                "isBanned" to banned,
                "updatedAt" to System.currentTimeMillis()
            )
            withTimeoutOrNull(2500L) {
                db.collection("users")
                    .document(docId)
                    .set(data, SetOptions.merge())
                    .await()
            }
            Log.d(TAG, "updateUserBanned success for $userId: $banned")
        } catch (e: Exception) {
            Log.d(TAG, "Notice updating user banned status in Firestore: ${e.message}")
        }
    }

    /**
     * Deletes user document from Firestore
     */
    suspend fun deleteUser(userId: String) {
        val db = firestore ?: return
        try {
            val docId = if (userId.contains("@")) userId.replace(".", "_") else userId
            withTimeoutOrNull(2500L) {
                db.collection("users").document(docId).delete().await()
            }
            Log.d(TAG, "Deleted user from Firestore: $userId")
        } catch (e: Exception) {
            Log.d(TAG, "Notice deleting user in Firestore: ${e.message}")
        }
    }

    /**
     * Rewards coins in Firestore for subscription verification
     */
    suspend fun rewardUserForSubscription(campaignId: Long, email: String? = null): Boolean {
        val db = firestore ?: return false
        return try {
            val targetEmail = email ?: currentUser?.email ?: designatedAdminEmail
            val docId = if (targetEmail.contains("@")) targetEmail.replace(".", "_") else targetEmail
            val userDoc = db.collection("users").document(docId)
            withTimeoutOrNull(2500L) {
                db.runTransaction { transaction ->
                    val snapshot = transaction.get(userDoc)
                    val currentCoins = snapshot.getLong("coins") ?: 100L
                    val newCoins = currentCoins + 50L
                    transaction.update(userDoc, "coins", newCoins)
                }.await()
            }
            true
        } catch (e: Exception) {
            Log.d(TAG, "Notice rewarding user in Firestore: ${e.message}")
            false
        }
    }

    val storage: FirebaseStorage?
        get() = try {
            FirebaseStorage.getInstance()
        } catch (e: Exception) {
            Log.d(TAG, "FirebaseStorage not accessible: ${e.message}")
            null
        }

    /**
     * Upload an image to Firebase Storage with fallback to base64 Data URI
     */
    suspend fun uploadSupportChatImage(
        context: Context,
        userEmail: String,
        imageUri: android.net.Uri
    ): String? = withContext(Dispatchers.IO) {
        val safeEmail = if (userEmail.contains("@")) userEmail.replace(".", "_") else userEmail
        val fileName = "chat_${safeEmail}_${System.currentTimeMillis()}.jpg"

        // Attempt 1: Upload to Firebase Storage
        try {
            val storageInstance = storage
            if (storageInstance != null) {
                val ref = storageInstance.reference.child("support_chat_images/$safeEmail/$fileName")
                ref.putFile(imageUri).await()
                val downloadUrl = ref.downloadUrl.await().toString()
                Log.i(TAG, "Uploaded chat image to Firebase Storage: $downloadUrl")
                return@withContext downloadUrl
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase Storage upload fallback triggered: ${e.message}")
        }

        // Attempt 2: Fallback to compressed base64 data URI
        try {
            context.contentResolver.openInputStream(imageUri)?.use { input ->
                val bitmap = android.graphics.BitmapFactory.decodeStream(input)
                if (bitmap != null) {
                    val maxDimension = 1000
                    val scaledBitmap = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
                        val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
                        val (targetWidth, targetHeight) = if (ratio > 1f) {
                            Pair(maxDimension, (maxDimension / ratio).toInt())
                        } else {
                            Pair((maxDimension * ratio).toInt(), maxDimension)
                        }
                        android.graphics.Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
                    } else {
                        bitmap
                    }
                    val outputStream = ByteArrayOutputStream()
                    scaledBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, outputStream)
                    val byteArray = outputStream.toByteArray()
                    val base64 = android.util.Base64.encodeToString(byteArray, android.util.Base64.NO_WRAP)
                    return@withContext "data:image/jpeg;base64,$base64"
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to encode image to base64: ${e.message}")
        }
        null
    }

    /**
     * Send message in support chat
     */
    suspend fun sendSupportChatMessage(
        userEmail: String,
        senderEmail: String,
        senderName: String,
        isAdmin: Boolean,
        messageText: String,
        imageUrl: String? = null
    ): Result<SupportChatMessage> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        val safeEmail = if (userEmail.contains("@")) userEmail.replace(".", "_") else userEmail
        val msgId = java.util.UUID.randomUUID().toString()
        val timestamp = System.currentTimeMillis()

        val chatMessage = SupportChatMessage(
            id = msgId,
            userEmail = userEmail,
            senderEmail = senderEmail,
            senderName = senderName,
            isAdmin = isAdmin,
            message = messageText,
            imageUrl = imageUrl,
            timestamp = timestamp,
            status = "sent"
        )

        try {
            val messageMap = hashMapOf<String, Any?>(
                "id" to chatMessage.id,
                "userEmail" to chatMessage.userEmail,
                "senderEmail" to chatMessage.senderEmail,
                "senderName" to chatMessage.senderName,
                "isAdmin" to chatMessage.isAdmin,
                "message" to chatMessage.message,
                "imageUrl" to chatMessage.imageUrl,
                "timestamp" to chatMessage.timestamp,
                "status" to "sent"
            )

            // 1. Add message to user subcollection
            db.collection("support_chats")
                .document(safeEmail)
                .collection("messages")
                .document(msgId)
                .set(messageMap)
                .await()

            // 2. Update thread summary doc for Admin review
            val threadSummary = hashMapOf<String, Any?>(
                "userEmail" to userEmail,
                "userName" to (if (isAdmin) "User" else senderName),
                "lastMessage" to if (messageText.isNotBlank()) messageText else "[Photo attached]",
                "lastSenderEmail" to senderEmail,
                "lastTimestamp" to timestamp,
                "unreadByAdmin" to !isAdmin,
                "unreadByUser" to isAdmin
            )

            db.collection("support_chats")
                .document(safeEmail)
                .set(threadSummary, SetOptions.merge())
                .await()

            Result.success(chatMessage)
        } catch (e: Exception) {
            Log.e(TAG, "Error sending support chat message: ${e.message}")
            Result.failure(e)
        }
    }

    /**
     * Real-time listener for messages in a specific user's chat
     */
    fun listenToSupportMessages(
        userEmail: String,
        onUpdate: (List<SupportChatMessage>) -> Unit
    ): ListenerRegistration? {
        val db = firestore ?: return null
        val safeEmail = if (userEmail.contains("@")) userEmail.replace(".", "_") else userEmail

        return try {
            db.collection("support_chats")
                .document(safeEmail)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Support chat listen error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val messages = snapshot.documents.mapNotNull { doc ->
                            try {
                                SupportChatMessage(
                                    id = doc.getString("id") ?: doc.id,
                                    userEmail = doc.getString("userEmail") ?: userEmail,
                                    senderEmail = doc.getString("senderEmail") ?: "",
                                    senderName = doc.getString("senderName") ?: "",
                                    isAdmin = doc.getBoolean("isAdmin") ?: false,
                                    message = doc.getString("message") ?: "",
                                    imageUrl = doc.getString("imageUrl"),
                                    timestamp = doc.getLong("timestamp") ?: 0L,
                                    status = doc.getString("status") ?: "sent"
                                )
                            } catch (e: Exception) {
                                null
                            }
                        }
                        onUpdate(messages)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register support chat listener: ${e.message}")
            null
        }
    }

    /**
     * Real-time listener for admin to see all active user support threads
     */
    fun listenToSupportThreads(
        onUpdate: (List<SupportChatThread>) -> Unit
    ): ListenerRegistration? {
        val db = firestore ?: return null

        return try {
            db.collection("support_chats")
                .orderBy("lastTimestamp", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Support threads listen error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val threads = snapshot.documents.mapNotNull { doc ->
                            try {
                                val email = doc.getString("userEmail") ?: doc.id.replace("_", ".")
                                SupportChatThread(
                                    userEmail = email,
                                    userName = doc.getString("userName") ?: email.substringBefore("@"),
                                    lastMessage = doc.getString("lastMessage") ?: "",
                                    lastSenderEmail = doc.getString("lastSenderEmail") ?: "",
                                    lastTimestamp = doc.getLong("lastTimestamp") ?: System.currentTimeMillis(),
                                    unreadByAdmin = doc.getBoolean("unreadByAdmin") ?: false,
                                    unreadByUser = doc.getBoolean("unreadByUser") ?: false
                                )
                            } catch (e: Exception) {
                                null
                            }
                        }
                        onUpdate(threads)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register support threads listener: ${e.message}")
            null
        }
    }

    /**
     * Mark thread as read by Admin or User
     */
    suspend fun markSupportThreadRead(userEmail: String, byAdmin: Boolean) {
        val db = firestore ?: return
        val safeEmail = if (userEmail.contains("@")) userEmail.replace(".", "_") else userEmail
        try {
            val field = if (byAdmin) "unreadByAdmin" else "unreadByUser"
            db.collection("support_chats")
                .document(safeEmail)
                .update(field, false)
                .await()
        } catch (e: Exception) {
            Log.d(TAG, "Notice marking thread read: ${e.message}")
        }
    }

    /**
     * Sync app update configuration and announcements to Firestore
     */
    suspend fun syncAppUpdateToFirestore(config: AppUpdateConfig) {
        val db = firestore ?: return
        try {
            val data = hashMapOf(
                "requiredVersionCode" to config.requiredVersionCode,
                "versionName" to config.versionName,
                "updateTitle" to config.updateTitle,
                "updateMessage" to config.updateMessage,
                "downloadUrl" to config.downloadUrl,
                "directApkDownloadUrl" to config.directApkDownloadUrl,
                "tutorialVideoUrl" to config.tutorialVideoUrl,
                "announcementImageUrl" to config.announcementImageUrl,
                "requireVideoWatch" to config.requireVideoWatch,
                "isMandatory" to config.isMandatory,
                "lastAnnouncedTimestamp" to config.lastAnnouncedTimestamp,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("app_config")
                .document("update_settings")
                .set(data, SetOptions.merge())
                .await()
            Log.i(TAG, "Synced AppUpdateConfig to Firestore: ${config.versionName}")
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing update config to Firestore: ${e.message}")
        }
    }

    /**
     * Real-time listener for app updates and announcements published by Admin
     */
    fun listenToAppUpdateConfig(onUpdate: (AppUpdateConfig) -> Unit): ListenerRegistration? {
        val db = firestore ?: return null
        return try {
            db.collection("app_config")
                .document("update_settings")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "App update listen error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val config = AppUpdateConfig(
                            requiredVersionCode = (snapshot.getLong("requiredVersionCode") ?: 1L).toInt(),
                            versionName = snapshot.getString("versionName") ?: "1.0",
                            updateTitle = snapshot.getString("updateTitle") ?: "Sub Exchange New Version Available!",
                            updateMessage = snapshot.getString("updateMessage") ?: "A new update is available.",
                            downloadUrl = snapshot.getString("downloadUrl") ?: "https://play.google.com/store/apps/details?id=com.sub4sub.exchangeapp",
                            directApkDownloadUrl = snapshot.getString("directApkDownloadUrl") ?: "",
                            tutorialVideoUrl = snapshot.getString("tutorialVideoUrl") ?: "",
                            announcementImageUrl = snapshot.getString("announcementImageUrl") ?: "",
                            requireVideoWatch = snapshot.getBoolean("requireVideoWatch") ?: false,
                            isMandatory = snapshot.getBoolean("isMandatory") ?: false,
                            lastAnnouncedTimestamp = snapshot.getLong("lastAnnouncedTimestamp") ?: 0L
                        )
                        onUpdate(config)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register app update listener: ${e.message}")
            null
        }
    }
}
