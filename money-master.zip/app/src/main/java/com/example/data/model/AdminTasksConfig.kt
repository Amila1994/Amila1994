package com.example.data.model

data class AdminPromotionEvent(
    val isEventActive: Boolean = true,
    val title: String = "Mega Super Promo Season 1 🔥",
    val description: String = "නියමිත කාලය තුළ Campaigns සාදා, Subscribe සහ Like කර නොමිලේ Coins ලබාගන්න!",
    val durationHours: Int = 48,
    val endTimestamp: Long = System.currentTimeMillis() + (48 * 3600 * 1000L),
    val targetCampaigns: Int = 2,
    val targetSubscribes: Int = 5,
    val targetLikes: Int = 5,
    val rewardCoins: Int = 1000
)

data class AdminAppTask(
    val id: String,
    val title: String,
    val description: String,
    val targetCount: Int,
    val rewardCoins: Int,
    val isEnabled: Boolean = true,
    val category: String
)

data class AdminTasksConfig(
    val promoEvent: AdminPromotionEvent = AdminPromotionEvent(),
    val referralRewardCoins: Int = 200,
    val referredWelcomeCoins: Int = 100,
    val apkDownloadUrl: String = "https://ais-pre-6ny3g6omqci6s2hg5wn3kh-206468462108.asia-southeast1.run.app",
    val taskWatchStreak: AdminAppTask = AdminAppTask(
        id = "task_watch_streak",
        title = "Daily Video Watcher (වීඩියෝ නැරඹීම)",
        description = "Watch active community campaigns to earn bonus coins",
        targetCount = 5,
        rewardCoins = 150,
        isEnabled = true,
        category = "WATCH_STREAK"
    ),
    val taskDailyLogin: AdminAppTask = AdminAppTask(
        id = "task_daily_login",
        title = "Daily Check-In (දිනපතා පැමිණීම)",
        description = "Open the app today and claim daily attendance coins",
        targetCount = 1,
        rewardCoins = 75,
        isEnabled = true,
        category = "DAILY_LOGIN"
    ),
    val taskInviteFriend: AdminAppTask = AdminAppTask(
        id = "task_invite_friend",
        title = "Refer a Friend (මිතුරෙකුට ආරාධනා කිරීම)",
        description = "Share your referral link with a friend to install the app",
        targetCount = 1,
        rewardCoins = 300,
        isEnabled = true,
        category = "INVITE_FRIEND"
    ),
    val taskHighWatchTime: AdminAppTask = AdminAppTask(
        id = "task_high_watch",
        title = "Deep Watch Master (දිගු වීඩියෝ නැරඹීම)",
        description = "Watch videos with at least 120 seconds duration",
        targetCount = 3,
        rewardCoins = 250,
        isEnabled = true,
        category = "HIGH_WATCH_TIME"
    ),
    val taskCommunityDesk: AdminAppTask = AdminAppTask(
        id = "task_community",
        title = "Support & Community Desk (ප්‍රජාව හා සම්බන්ධ වීම)",
        description = "Check Help Desk or announcements in the community",
        targetCount = 1,
        rewardCoins = 100,
        isEnabled = true,
        category = "COMMUNITY_DESK"
    )
)
