package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.CampaignDao
import com.example.data.local.dao.ReloadRequestDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.WatchHistoryDao
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.ReloadRequestEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WatchHistoryEntity

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        UserEntity::class,
        CampaignEntity::class,
        WatchHistoryEntity::class,
        ReloadRequestEntity::class
    ],
    version = 7,
    exportSchema = false
)
abstract class SubExchangeDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun campaignDao(): CampaignDao
    abstract fun watchHistoryDao(): WatchHistoryDao
    abstract fun reloadRequestDao(): ReloadRequestDao

    companion object {
        @Volatile
        private var INSTANCE: SubExchangeDatabase? = null

        private fun columnExists(db: SupportSQLiteDatabase, table: String, column: String): Boolean {
            return try {
                db.query("PRAGMA table_info(`$table`)").use { cursor ->
                    val nameIndex = cursor.getColumnIndex("name")
                    if (nameIndex != -1) {
                        while (cursor.moveToNext()) {
                            if (cursor.getString(nameIndex).equals(column, ignoreCase = true)) {
                                return true
                            }
                        }
                    }
                    false
                }
            } catch (_: Exception) {
                false
            }
        }

        private fun safeAddColumn(db: SupportSQLiteDatabase, table: String, column: String, type: String, default: String) {
            try {
                if (!columnExists(db, table, column)) {
                    db.execSQL("ALTER TABLE `$table` ADD COLUMN `$column` $type NOT NULL DEFAULT $default")
                }
            } catch (_: Exception) {}
        }

        private fun runSafeMigration(db: SupportSQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS `users` (`email` TEXT NOT NULL, `coins` INTEGER NOT NULL DEFAULT 100, `dailyAdsWatched` INTEGER NOT NULL DEFAULT 0, `lastAdDate` TEXT NOT NULL DEFAULT '', `totalEarned` INTEGER NOT NULL DEFAULT 0, `totalSpent` INTEGER NOT NULL DEFAULT 0, `videosWatchedCount` INTEGER NOT NULL DEFAULT 0, `channelsSubscribedCount` INTEGER NOT NULL DEFAULT 0, `isBanned` INTEGER NOT NULL DEFAULT 0, `isAdmin` INTEGER NOT NULL DEFAULT 0, `eligibleReloadCoins` INTEGER NOT NULL DEFAULT 0, `fullTasksCompletedCount` INTEGER NOT NULL DEFAULT 0, `warningCount` INTEGER NOT NULL DEFAULT 0, `banReason` TEXT NOT NULL DEFAULT '', `banTimestamp` INTEGER NOT NULL DEFAULT 0, `unbanAdsWatched` INTEGER NOT NULL DEFAULT 0, `unbanDailyAdsWatched` INTEGER NOT NULL DEFAULT 0, `lastUnbanAdDate` TEXT NOT NULL DEFAULT '', `appealMessage` TEXT NOT NULL DEFAULT '', `appealStatus` TEXT NOT NULL DEFAULT '', `unsubscribedChannels` TEXT NOT NULL DEFAULT '', PRIMARY KEY(`email`))")
            db.execSQL("CREATE TABLE IF NOT EXISTS `campaigns` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `creatorEmail` TEXT NOT NULL, `videoUrl` TEXT NOT NULL, `videoTitle` TEXT NOT NULL, `channelName` TEXT NOT NULL, `channelId` TEXT NOT NULL DEFAULT '', `thumbnailUrl` TEXT NOT NULL, `campaignType` TEXT NOT NULL, `targetCount` INTEGER NOT NULL, `currentCount` INTEGER NOT NULL DEFAULT 0, `durationSeconds` INTEGER NOT NULL DEFAULT 300, `rewardCoins` INTEGER NOT NULL DEFAULT 50, `totalCostCoins` INTEGER NOT NULL DEFAULT 100, `isAdminPriority` INTEGER NOT NULL DEFAULT 0, `isGlobal` INTEGER NOT NULL DEFAULT 0, `isActive` INTEGER NOT NULL DEFAULT 1, `createdAt` INTEGER NOT NULL DEFAULT 0)")
            db.execSQL("CREATE TABLE IF NOT EXISTS `watch_history` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `userEmail` TEXT NOT NULL, `campaignId` INTEGER NOT NULL, `videoTitle` TEXT NOT NULL, `channelName` TEXT NOT NULL, `actionType` TEXT NOT NULL, `coinsEarned` INTEGER NOT NULL, `timestamp` INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE IF NOT EXISTS `reload_requests` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `userEmail` TEXT NOT NULL, `phoneNumber` TEXT NOT NULL, `operator` TEXT NOT NULL, `connectionType` TEXT NOT NULL, `amountLkr` INTEGER NOT NULL, `coinsRequired` INTEGER NOT NULL, `status` TEXT NOT NULL DEFAULT 'PENDING', `timestamp` INTEGER NOT NULL, `approvedTimestamp` INTEGER NOT NULL DEFAULT 0, `adminNote` TEXT NOT NULL DEFAULT '')")

            safeAddColumn(db, "users", "unsubscribedChannels", "TEXT", "''")
            safeAddColumn(db, "users", "appealMessage", "TEXT", "''")
            safeAddColumn(db, "users", "appealStatus", "TEXT", "''")
            safeAddColumn(db, "users", "warningCount", "INTEGER", "0")
            safeAddColumn(db, "users", "banReason", "TEXT", "''")
            safeAddColumn(db, "users", "banTimestamp", "INTEGER", "0")
            safeAddColumn(db, "users", "unbanAdsWatched", "INTEGER", "0")
            safeAddColumn(db, "users", "unbanDailyAdsWatched", "INTEGER", "0")
            safeAddColumn(db, "users", "lastUnbanAdDate", "TEXT", "''")
            safeAddColumn(db, "users", "eligibleReloadCoins", "INTEGER", "0")
            safeAddColumn(db, "users", "fullTasksCompletedCount", "INTEGER", "0")
            safeAddColumn(db, "campaigns", "channelId", "TEXT", "''")
            safeAddColumn(db, "campaigns", "isAdminPriority", "INTEGER", "0")
            safeAddColumn(db, "campaigns", "isGlobal", "INTEGER", "0")
            safeAddColumn(db, "campaigns", "durationSeconds", "INTEGER", "300")
            safeAddColumn(db, "reload_requests", "approvedTimestamp", "INTEGER", "0")
            safeAddColumn(db, "reload_requests", "adminNote", "TEXT", "''")
        }

        private val MIGRATION_1_7 = object : Migration(1, 7) {
            override fun migrate(db: SupportSQLiteDatabase) { runSafeMigration(db) }
        }
        private val MIGRATION_2_7 = object : Migration(2, 7) {
            override fun migrate(db: SupportSQLiteDatabase) { runSafeMigration(db) }
        }
        private val MIGRATION_3_7 = object : Migration(3, 7) {
            override fun migrate(db: SupportSQLiteDatabase) { runSafeMigration(db) }
        }
        private val MIGRATION_4_7 = object : Migration(4, 7) {
            override fun migrate(db: SupportSQLiteDatabase) { runSafeMigration(db) }
        }
        private val MIGRATION_5_7 = object : Migration(5, 7) {
            override fun migrate(db: SupportSQLiteDatabase) { runSafeMigration(db) }
        }
        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Version 6 and 7 schemas are identical, no migration queries needed
            }
        }

        fun getDatabase(context: Context): SubExchangeDatabase {
            return INSTANCE ?: synchronized(this) {
                try {
                    context.applicationContext.deleteDatabase("sub_exchange.db")
                } catch (_: Exception) {}

                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SubExchangeDatabase::class.java,
                    "sub_exchange_v5.db"
                )
                    .addMigrations(
                        MIGRATION_1_7,
                        MIGRATION_2_7,
                        MIGRATION_3_7,
                        MIGRATION_4_7,
                        MIGRATION_5_7,
                        MIGRATION_6_7
                    )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
