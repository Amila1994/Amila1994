package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.CampaignDao
import com.example.data.local.dao.ReloadRequestDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.WatchHistoryDao
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.ReloadRequestEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WatchHistoryEntity

@Database(
    entities = [
        UserEntity::class,
        CampaignEntity::class,
        WatchHistoryEntity::class,
        ReloadRequestEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class SubExchangeDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun campaignDao(): CampaignDao
    abstract fun watchHistoryDao(): WatchHistoryDao
    abstract fun reloadRequestDao(): ReloadRequestDao

    companion object {
        @Volatile
        private var INSTANCE: SubExchangeDatabase? = null

        fun getDatabase(context: Context): SubExchangeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SubExchangeDatabase::class.java,
                    "sub_exchange.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
