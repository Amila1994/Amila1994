package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "campaigns")
data class CampaignEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val creatorEmail: String,
    val videoUrl: String,
    val videoTitle: String,
    val channelName: String,
    val thumbnailUrl: String,
    val campaignType: String, // "SUBSCRIBE", "VIEW", "LIKE"
    val targetCount: Int,
    val currentCount: Int = 0,
    val durationSeconds: Int = 300, // default 5 minutes
    val rewardCoins: Int = 50, // reward given to watcher
    val totalCostCoins: Int = 100, // total coins spent by creator
    val isAdminPriority: Boolean = false, // Admin priority campaign
    val isGlobal: Boolean = false, // Broadcast to all users
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
