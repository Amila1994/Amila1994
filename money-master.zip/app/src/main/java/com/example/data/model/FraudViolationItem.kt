package com.example.data.model

data class FraudViolationItem(
    val id: String = "",
    val campaignId: Long = 0L,
    val channelName: String = "",
    val channelId: String = "",
    val videoTitle: String = "",
    val videoId: String = "",
    val thumbnailUrl: String = "",
    val directUrl: String = "",
    val violationType: String = "BOTH", // "UNSUBSCRIBE", "UNLIKE", "BOTH"
    val isSubResolved: Boolean = false,
    val isLikeResolved: Boolean = false,
    val detectedTimestamp: Long = System.currentTimeMillis()
) {
    val isFullyResolved: Boolean
        get() = when (violationType) {
            "UNSUBSCRIBE" -> isSubResolved
            "UNLIKE" -> isLikeResolved
            else -> isSubResolved && isLikeResolved
        }
}
