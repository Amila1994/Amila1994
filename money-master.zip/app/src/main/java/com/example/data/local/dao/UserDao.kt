package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE email = :email")
    fun getUserByEmail(email: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE email = :email")
    suspend fun getUserSync(email: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY email ASC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET coins = coins + :amount, totalEarned = totalEarned + :amount WHERE email = :email")
    suspend fun addCoins(email: String, amount: Int)

    @Query("UPDATE users SET coins = coins - :amount, totalSpent = totalSpent + :amount WHERE email = :email")
    suspend fun deductCoins(email: String, amount: Int)

    @Query("UPDATE users SET dailyAdsWatched = dailyAdsWatched + 1, coins = coins + :rewardCoins, totalEarned = totalEarned + :rewardCoins WHERE email = :email")
    suspend fun recordAdWatched(email: String, rewardCoins: Int)

    @Query("UPDATE users SET dailyAdsWatched = 0, lastAdDate = :today WHERE email = :email")
    suspend fun resetDailyAds(email: String, today: String)

    @Query("UPDATE users SET isBanned = :banned WHERE email = :email")
    suspend fun setBannedStatus(email: String, banned: Boolean)

    @Query("UPDATE users SET warningCount = :count WHERE email = :email")
    suspend fun updateWarningCount(email: String, count: Int)

    @Query("UPDATE users SET isBanned = :banned, banReason = :reason, banTimestamp = :timestamp, warningCount = 3 WHERE email = :email")
    suspend fun banUserWithReason(email: String, banned: Boolean, reason: String, timestamp: Long)

    @Query("UPDATE users SET isBanned = 0, warningCount = 0, banReason = '', unbanAdsWatched = 0, unbanDailyAdsWatched = 0, banTimestamp = 0, appealStatus = 'APPROVED', unsubscribedChannels = '' WHERE email = :email")
    suspend fun unbanUser(email: String)

    @Query("UPDATE users SET unsubscribedChannels = :channels WHERE email = :email")
    suspend fun updateUnsubscribedChannels(email: String, channels: String)

    @Query("UPDATE users SET warningCount = 0, unsubscribedChannels = '' WHERE email = :email")
    suspend fun resetStrikesAndUnsubs(email: String)

    @Query("UPDATE users SET unbanAdsWatched = unbanAdsWatched + 1, unbanDailyAdsWatched = unbanDailyAdsWatched + 1, lastUnbanAdDate = :today WHERE email = :email")
    suspend fun recordUnbanAdWatched(email: String, today: String)

    @Query("UPDATE users SET unbanDailyAdsWatched = 0, lastUnbanAdDate = :today WHERE email = :email")
    suspend fun resetUnbanDailyAds(email: String, today: String)

    @Query("UPDATE users SET appealMessage = :message, appealStatus = :status WHERE email = :email")
    suspend fun submitAppeal(email: String, message: String, status: String)

    @Query("UPDATE users SET coins = :newBalance WHERE email = :email")
    suspend fun setCoins(email: String, newBalance: Int)

    @Query("UPDATE users SET eligibleReloadCoins = eligibleReloadCoins + :coins, fullTasksCompletedCount = fullTasksCompletedCount + 1 WHERE email = :email")
    suspend fun addEligibleReloadCoins(email: String, coins: Int)

    @Query("UPDATE users SET eligibleReloadCoins = MAX(0, eligibleReloadCoins - :coins) WHERE email = :email")
    suspend fun deductEligibleReloadCoins(email: String, coins: Int)

    @Query("DELETE FROM users WHERE email = :email")
    suspend fun deleteUserByEmail(email: String)

    @Query("DELETE FROM users WHERE email IN ('admin@gmail.com', 'amila940703@gmail.com', 'tech_master@gmail.com', 'gamer_zone@gmail.com', 'music_vibes@gmail.com', 'creator_alex@gmail.com') OR (email != 'amilalasantha940703@gmail.com' AND (email LIKE '%tech_%' OR email LIKE '%gamer_%' OR email LIKE '%music_%' OR email LIKE '%creator_%'))")
    suspend fun deleteSampleUsers()
}
