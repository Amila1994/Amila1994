package com.example.data.youtube

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONObject
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

// =========================================================================
// 1. YouTube Data API v3 Data Models
// =========================================================================

@JsonClass(generateAdapter = true)
data class YouTubeSubscriptionListResponse(
    @Json(name = "kind") val kind: String? = null,
    @Json(name = "etag") val etag: String? = null,
    @Json(name = "pageInfo") val pageInfo: PageInfo? = null,
    @Json(name = "items") val items: List<SubscriptionItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PageInfo(
    @Json(name = "totalResults") val totalResults: Int = 0,
    @Json(name = "resultsPerPage") val resultsPerPage: Int = 0
)

@JsonClass(generateAdapter = true)
data class SubscriptionItem(
    @Json(name = "id") val id: String? = null,
    @Json(name = "snippet") val snippet: SubscriptionSnippet? = null
)

@JsonClass(generateAdapter = true)
data class SubscriptionSnippet(
    @Json(name = "channelId") val channelId: String? = null,
    @Json(name = "title") val title: String? = null,
    @Json(name = "resourceId") val resourceId: SubscriptionResourceId? = null
)

@JsonClass(generateAdapter = true)
data class SubscriptionResourceId(
    @Json(name = "kind") val kind: String? = null,
    @Json(name = "channelId") val channelId: String? = null
)

@JsonClass(generateAdapter = true)
data class YouTubeVideoRatingListResponse(
    @Json(name = "kind") val kind: String? = null,
    @Json(name = "etag") val etag: String? = null,
    @Json(name = "items") val items: List<VideoRatingItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class VideoRatingItem(
    @Json(name = "videoId") val videoId: String? = null,
    @Json(name = "rating") val rating: String? = null // "like", "dislike", "none", or "unspecified"
)

// =========================================================================
// 2. Retrofit API Interface
// =========================================================================

interface YouTubeSubscriptionApi {
    /**
     * Checks if the authenticated user ('mine=true') is subscribed to 'forChannelId'.
     * Requires OAuth scope: https://www.googleapis.com/auth/youtube.readonly or youtube
     */
    @GET("youtube/v3/subscriptions")
    suspend fun getSubscriptions(
        @Header("Authorization") authorization: String,
        @Query("part") part: String = "snippet",
        @Query("mine") mine: Boolean = true,
        @Query("forChannelId") forChannelId: String
    ): Response<YouTubeSubscriptionListResponse>

    /**
     * Retrieves all channels the authenticated user is currently subscribed to.
     * Endpoint: GET https://www.googleapis.com/youtube/v3/subscriptions?mine=true
     */
    @GET("youtube/v3/subscriptions")
    suspend fun getMySubscriptionsList(
        @Header("Authorization") authorization: String,
        @Query("part") part: String = "snippet",
        @Query("mine") mine: Boolean = true,
        @Query("maxResults") maxResults: Int = 50
    ): Response<YouTubeSubscriptionListResponse>

    /**
     * Retrieves the ratings that the authenticated user has given to specified video(s).
     * Endpoint: GET https://www.googleapis.com/youtube/v3/videos/getRating
     * Requires OAuth scope: https://www.googleapis.com/auth/youtube or youtube.force-ssl
     */
    @GET("youtube/v3/videos/getRating")
    suspend fun getVideoRating(
        @Header("Authorization") authorization: String,
        @Query("id") videoId: String
    ): Response<YouTubeVideoRatingListResponse>
}

data class YouTubeVerificationResult(
    val isVerified: Boolean,
    val isSubscribed: Boolean,
    val coinsEarned: Int,
    val message: String,
    val channelTitle: String,
    val isAlreadySubscribed: Boolean = false,
    val isAlreadyLiked: Boolean = false,
    val isViewOnlyCampaign: Boolean = false
)

data class YouTubeVideoDetails(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val channelId: String = "",
    val thumbnailUrl: String = ""
)

object YouTubeApiService {
    private const val TAG = "YouTubeApiService"
    private const val YOUTUBE_API_BASE_URL = "https://www.googleapis.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .build()

    private val subscriptionApi: YouTubeSubscriptionApi by lazy {
        Retrofit.Builder()
            .baseUrl(YOUTUBE_API_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(YouTubeSubscriptionApi::class.java)
    }

    /**
     * Verifies if the authenticated user is subscribed to the target YouTube channel.
     *
     * @param accessToken OAuth 2.0 Access Token with 'youtube.readonly' or 'youtube' scope.
     * @param targetChannelId The 24-character YouTube Channel ID (e.g., "UC_x5XG1OV2P6uZZ5FSM9Ttw").
     * @return Result.success(true) if subscribed, Result.success(false) if not subscribed,
     *         or Result.failure(Exception) if token expired or API error occurred.
     */
    suspend fun verifyChannelSubscription(
        accessToken: String,
        targetChannelId: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val bearerAuth = if (accessToken.startsWith("Bearer ", ignoreCase = true)) {
                accessToken
            } else {
                "Bearer $accessToken"
            }

            val response = subscriptionApi.getSubscriptions(
                authorization = bearerAuth,
                part = "snippet",
                mine = true,
                forChannelId = targetChannelId
            )

            if (response.isSuccessful) {
                val body = response.body()
                // If subscribed, YouTube returns items containing exactly 1 item for this channel.
                // If not subscribed, items is empty and totalResults is 0.
                val isSubscribed = body != null && body.items.isNotEmpty()
                Result.success(isSubscribed)
            } else {
                when (response.code()) {
                    401 -> {
                        // OAuth token expired, invalid, or missing required scope
                        Result.failure(
                            SecurityException("OAuth token expired or unauthorized (401). Please re-authenticate.")
                        )
                    }
                    403 -> {
                        // Quota limit exceeded or permissions error
                        val errorBody = response.errorBody()?.string() ?: ""
                        Result.failure(
                            IllegalStateException("YouTube API access forbidden (403): $errorBody")
                        )
                    }
                    else -> {
                        Result.failure(
                            RuntimeException("YouTube API error HTTP ${response.code()}: ${response.message()}")
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception verifying channel subscription: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches all channels the authenticated user is currently subscribed to on YouTube.
     */
    suspend fun getMySubscribedChannels(accessToken: String): Result<List<SubscriptionSnippet>> = withContext(Dispatchers.IO) {
        try {
            val bearerAuth = if (accessToken.startsWith("Bearer ", ignoreCase = true)) accessToken else "Bearer $accessToken"
            val response = subscriptionApi.getMySubscriptionsList(
                authorization = bearerAuth,
                part = "snippet",
                mine = true,
                maxResults = 50
            )
            if (response.isSuccessful) {
                val snippets = response.body()?.items?.mapNotNull { it.snippet } ?: emptyList()
                Result.success(snippets)
            } else {
                Result.failure(RuntimeException("YouTube API HTTP ${response.code()}: ${response.message()}"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception getting user subscriptions: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Verifies if the authenticated user has "Liked" the target YouTube video.
     *
     * @param accessToken OAuth 2.0 Access Token with 'youtube' or 'youtube.force-ssl' scope.
     * @param videoId The 11-character YouTube Video ID.
     * @return Result.success(true) if rating is "like", Result.success(false) otherwise,
     *         or Result.failure(Exception) on error.
     */
    suspend fun verifyVideoLiked(
        accessToken: String,
        videoId: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val bearerAuth = if (accessToken.startsWith("Bearer ", ignoreCase = true)) {
                accessToken
            } else {
                "Bearer $accessToken"
            }

            val response = subscriptionApi.getVideoRating(
                authorization = bearerAuth,
                videoId = videoId
            )

            if (response.isSuccessful) {
                val body = response.body()
                val items = body?.items ?: emptyList()
                val item = items.firstOrNull { it.videoId == videoId } ?: items.firstOrNull()
                // YouTube API returns rating = "like", "dislike", "none", or "unspecified"
                val isLiked = item?.rating.equals("like", ignoreCase = true)
                Result.success(isLiked)
            } else {
                when (response.code()) {
                    401 -> {
                        Result.failure(
                            SecurityException("OAuth token expired or unauthorized (401). Please re-authenticate.")
                        )
                    }
                    403 -> {
                        val errorBody = response.errorBody()?.string() ?: ""
                        Result.failure(
                            IllegalStateException("YouTube API access forbidden (403): $errorBody")
                        )
                    }
                    else -> {
                        Result.failure(
                            RuntimeException("YouTube API error HTTP ${response.code()}: ${response.message()}")
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception verifying video like: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Extracts YouTube Video ID from any YouTube URL format:
     * - https://www.youtube.com/watch?v=dQw4w9WgXcQ
     * - https://youtu.be/dQw4w9WgXcQ
     * - https://youtube.com/shorts/dQw4w9WgXcQ
     * - https://www.youtube.com/embed/dQw4w9WgXcQ
     */
    fun extractVideoId(url: String): String {
        if (url.isBlank()) return ""
        return try {
            val pattern = "(?<=watch\\?v=|/videos/|embed/|youtu\\.be/|/v/|/e/|shorts/)[^#&?\\n]*"
            val compiledPattern = Pattern.compile(pattern)
            val matcher = compiledPattern.matcher(url)
            if (matcher.find()) {
                val id = matcher.group()
                if (!id.isNullOrBlank()) id else ""
            } else if (url.length == 11 && !url.contains("/")) {
                url
            } else {
                ""
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing video ID: ${e.message}")
            ""
        }
    }

    /**
     * Attempts to resolve the 24-character YouTube Channel ID (starting with UC)
     * from a given video URL or channel string.
     */
    suspend fun resolveChannelIdFromVideo(videoUrlOrChannel: String, accessToken: String? = null): String = withContext(Dispatchers.IO) {
        if (videoUrlOrChannel.isBlank()) return@withContext ""
        val trimmed = videoUrlOrChannel.trim()

        // 1. Direct Regex match for UC Channel ID
        val directMatch = Regex("""(UC[a-zA-Z0-9_-]{22})""").find(trimmed)
        if (directMatch != null) {
            return@withContext directMatch.value
        }

        val videoId = extractVideoId(trimmed)
        if (videoId.isNotBlank()) {
            // 2. Try YouTube Data API v3 if accessToken or API key available
            val token = accessToken?.trim()
            if (!token.isNullOrBlank()) {
                try {
                    val bearer = if (token.startsWith("Bearer ", ignoreCase = true)) token else "Bearer $token"
                    val req = Request.Builder()
                        .url("https://www.googleapis.com/youtube/v3/videos?part=snippet&id=$videoId")
                        .addHeader("Authorization", bearer)
                        .build()
                    val res = okHttpClient.newCall(req).execute()
                    if (res.isSuccessful) {
                        val body = res.body?.string() ?: ""
                        val json = JSONObject(body)
                        val items = json.optJSONArray("items")
                        if (items != null && items.length() > 0) {
                            val chId = items.getJSONObject(0).optJSONObject("snippet")?.optString("channelId", "") ?: ""
                            if (chId.startsWith("UC")) return@withContext chId
                        }
                    }
                } catch (e: Exception) {
                    Log.d(TAG, "resolveChannelId API note: ${e.message}")
                }
            }

            // 3. Try official YouTube oEmbed endpoint (zero-quota)
            try {
                val oembedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$videoId&format=json"
                val req = Request.Builder().url(oembedUrl).build()
                val res = okHttpClient.newCall(req).execute()
                if (res.isSuccessful) {
                    val body = res.body?.string() ?: ""
                    val json = JSONObject(body)
                    val authorUrl = json.optString("author_url", "")
                    val chMatch = Regex("""(UC[a-zA-Z0-9_-]{22})""").find(authorUrl)
                    if (chMatch != null) return@withContext chMatch.value
                }
            } catch (e: Exception) {
                Log.d(TAG, "resolveChannelId oEmbed note: ${e.message}")
            }

            // 4. Scrape watch page HTML for channelId/browseId
            try {
                val url = URL("https://www.youtube.com/watch?v=$videoId")
                val conn = url.openConnection() as HttpURLConnection
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                conn.connectTimeout = 4000
                conn.readTimeout = 4000
                val html = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val match = Regex("""\"channelId\":\"(UC[a-zA-Z0-9_-]{22})\"""").find(html)
                    ?: Regex("""\"externalChannelId\":\"(UC[a-zA-Z0-9_-]{22})\"""").find(html)
                    ?: Regex("""\"browseId\":\"(UC[a-zA-Z0-9_-]{22})\"""").find(html)
                    ?: Regex("""/channel/(UC[a-zA-Z0-9_-]{22})""").find(html)
                val found = match?.groupValues?.get(1) ?: ""
                if (found.isNotBlank() && found.startsWith("UC")) return@withContext found
            } catch (e: Exception) {
                Log.d(TAG, "Channel ID auto-resolve attempt failed: ${e.message}")
            }
        }

        // 5. If it's a channel URL or handle
        if (trimmed.contains("youtube.com/") || trimmed.startsWith("@")) {
            try {
                val targetUrl = if (trimmed.startsWith("http")) trimmed else "https://www.youtube.com/$trimmed"
                val url = URL(targetUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                conn.connectTimeout = 4000
                conn.readTimeout = 4000
                val html = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val match = Regex("""\"channelId\":\"(UC[a-zA-Z0-9_-]{22})\"""").find(html)
                    ?: Regex("""\"externalChannelId\":\"(UC[a-zA-Z0-9_-]{22})\"""").find(html)
                    ?: Regex("""\"browseId\":\"(UC[a-zA-Z0-9_-]{22})\"""").find(html)
                val found = match?.groupValues?.get(1) ?: ""
                if (found.isNotBlank() && found.startsWith("UC")) return@withContext found
            } catch (_: Exception) {}
        }

        return@withContext ""
    }
    fun buildYouTubeEmbedHtml(videoId: String): String {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                <style>
                    * {
                        margin: 0;
                        padding: 0;
                        box-sizing: border-box;
                        -webkit-user-select: none;
                        user-select: none;
                        -webkit-touch-callout: none;
                    }
                    html, body {
                        background-color: #000000;
                        width: 100%;
                        height: 100%;
                        overflow: hidden;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                    }
                    .video-container {
                        position: relative;
                        width: 100%;
                        height: 100%;
                    }
                    iframe {
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        border: 0;
                    }
                    #fallback-banner {
                        display: none;
                        position: absolute;
                        bottom: 12px;
                        left: 50%;
                        transform: translateX(-50%);
                        background: rgba(200, 20, 20, 0.92);
                        color: white;
                        padding: 10px 18px;
                        border-radius: 24px;
                        font-size: 13px;
                        font-weight: bold;
                        z-index: 999;
                        text-align: center;
                        text-decoration: none;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.6);
                        white-space: nowrap;
                    }
                </style>
            </head>
            <body>
                <div class="video-container">
                    <iframe
                        id="ytplayer"
                        src="https://www.youtube-nocookie.com/embed/$videoId?autoplay=1&playsinline=1&rel=0&modestbranding=1&iv_load_policy=3&disablekb=1"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen>
                    </iframe>
                    <a id="fallback-banner" href="https://www.youtube.com/watch?v=$videoId">
                        ▶ Watch Video on YouTube (Error 152-4 Fix)
                    </a>
                </div>
                <script>
                    window.addEventListener('message', function(event) {
                        try {
                            var data = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
                            if (data && (data.event === 'onError' || data.info === 150 || data.info === 152 || data.info === 101 || data.info === 2)) {
                                var banner = document.getElementById('fallback-banner');
                                if (banner) banner.style.display = 'block';
                                if (window.AndroidBridge && window.AndroidBridge.onPlayerError) {
                                    window.AndroidBridge.onPlayerError(data.info || 152);
                                }
                            }
                        } catch(e) {}
                    });
                </script>
            </body>
            </html>
        """.trimIndent()
    }

    /**
     * Opens YouTube video directly in the YouTube Android App (via native URI)
     * with graceful fallback to external browser if the app is not installed.
     */
    fun openVideoInYouTubeApp(context: Context, videoUrl: String): Boolean {
        val videoId = extractVideoId(videoUrl)
        return try {
            // 1. Try launching native YouTube App
            val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(appIntent)
            true
        } catch (e: Exception) {
            // 2. Fallback to web browser or app chooser
            try {
                val webUrl = if (videoUrl.isNotBlank() && (videoUrl.startsWith("http://") || videoUrl.startsWith("https://"))) {
                    videoUrl
                } else {
                    "https://www.youtube.com/watch?v=$videoId"
                }
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
                true
            } catch (e2: Exception) {
                Log.e(TAG, "Failed to launch YouTube app or browser: ${e2.message}")
                false
            }
        }
    }

    /**
     * Opens YouTube Channel or Video in the YouTube app or browser so the user can easily subscribe.
     */
    fun openChannelInYouTube(context: Context, channelName: String, videoUrl: String): Boolean {
        return try {
            val target = when {
                channelName.startsWith("http") -> channelName
                channelName.startsWith("@") -> "https://www.youtube.com/$channelName"
                channelName.isNotBlank() -> "https://www.youtube.com/results?search_query=" + Uri.encode(channelName)
                else -> {
                    val videoId = extractVideoId(videoUrl)
                    "https://www.youtube.com/watch?v=$videoId"
                }
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(target)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            openVideoInYouTubeApp(context, videoUrl)
        }
    }

    /**
     * Strict real-time verification using YouTube Data API v3.
     * Validates that the authenticated user has actually subscribed to the target channel
     * and liked the specific video before granting coins.
     */
    suspend fun verifySubscriptionViaYouTubeApi(
        channelName: String,
        videoUrl: String,
        userEmail: String,
        isUserClaimedSubscribed: Boolean,
        watchedSeconds: Int,
        requiredSeconds: Int,
        rewardCoins: Int,
        campaignType: String = "SUBSCRIBE",
        isAlreadySubscribed: Boolean = false,
        isAlreadyLiked: Boolean = false,
        accessToken: String = "",
        targetChannelId: String = ""
    ): YouTubeVerificationResult = withContext(Dispatchers.IO) {
        // 1. Anti-cheat check: Ensure user watched the video duration
        val minWatchThreshold = (requiredSeconds * 0.85).toInt()
        if (watchedSeconds < minWatchThreshold && requiredSeconds > 10) {
            return@withContext YouTubeVerificationResult(
                isVerified = false,
                isSubscribed = false,
                coinsEarned = 0,
                message = "Anti-cheat: You must watch the complete video duration before claiming rewards.",
                channelTitle = channelName
            )
        }

        // 2. View-only campaign handling
        if (campaignType.equals("VIEW", ignoreCase = true)) {
            val viewCoins = if (rewardCoins > 0) rewardCoins else (requiredSeconds / 60).coerceAtLeast(1) * 10
            return@withContext YouTubeVerificationResult(
                isVerified = true,
                isSubscribed = false,
                coinsEarned = viewCoins,
                message = "View engagement verified! +$viewCoins coins credited.",
                channelTitle = channelName,
                isViewOnlyCampaign = true
            )
        }

        // 3. Clean and validate OAuth Access Token for YouTube Data API v3 calls
        val cleanToken = accessToken.trim()
        if (cleanToken.isBlank()) {
            return@withContext YouTubeVerificationResult(
                isVerified = false,
                isSubscribed = false,
                coinsEarned = 0,
                message = "YouTube Data API v3 error: OAuth Access Token missing. Please sign in with Google to verify real actions.",
                channelTitle = channelName
            )
        }

        val videoId = extractVideoId(videoUrl)
        val channelId = if (targetChannelId.isNotBlank()) {
            targetChannelId
        } else {
            resolveChannelIdFromVideo(videoUrl).ifBlank {
                resolveChannelIdFromVideo(channelName)
            }
        }

        // 4. Strict Real-Time Subscription Check via YouTube Data API v3
        val isSubscribeCampaign = campaignType.equals("SUBSCRIBE", ignoreCase = true)
        if (isSubscribeCampaign) {
            if (channelId.isBlank()) {
                return@withContext YouTubeVerificationResult(
                    isVerified = false,
                    isSubscribed = false,
                    coinsEarned = 0,
                    message = "Could not resolve YouTube Channel ID for $channelName. Please verify video link.",
                    channelTitle = channelName
                )
            }

            val subResult = verifyChannelSubscription(cleanToken, channelId)
            val isSubscribedOnYouTube = subResult.getOrDefault(false)

            if (!isSubscribedOnYouTube) {
                val failureMsg = if (subResult.isFailure) {
                    val ex = subResult.exceptionOrNull()
                    if (ex is SecurityException) {
                        "OAuth token expired or unauthorized. Please re-authenticate."
                    } else {
                        "YouTube API error: ${ex?.message ?: "Check failed"}"
                    }
                } else {
                    "YouTube Data API v3: You have not subscribed to '$channelName' yet on YouTube! Please subscribe first."
                }

                return@withContext YouTubeVerificationResult(
                    isVerified = false,
                    isSubscribed = false,
                    coinsEarned = 0,
                    message = failureMsg,
                    channelTitle = channelName
                )
            }
        }

        // 5. Strict Real-Time Like Check via YouTube Data API v3
        if (videoId.isNotBlank()) {
            val likeResult = verifyVideoLiked(cleanToken, videoId)
            val isLikedOnYouTube = likeResult.getOrDefault(false)

            if (!isLikedOnYouTube && !isAlreadyLiked) {
                val failureMsg = if (likeResult.isFailure) {
                    val ex = likeResult.exceptionOrNull()
                    if (ex is SecurityException) {
                        "OAuth token expired or unauthorized. Please re-authenticate."
                    } else {
                        "YouTube API error: ${ex?.message ?: "Check failed"}"
                    }
                } else {
                    "YouTube Data API v3: You have not liked this video yet on YouTube! Please like the video to verify."
                }

                return@withContext YouTubeVerificationResult(
                    isVerified = false,
                    isSubscribed = isSubscribeCampaign,
                    coinsEarned = 0,
                    message = failureMsg,
                    channelTitle = channelName
                )
            }
        }

        // 6. Both actions strictly confirmed in real-time by YouTube Data API v3
        YouTubeVerificationResult(
            isVerified = true,
            isSubscribed = true,
            coinsEarned = rewardCoins,
            message = "YouTube Data API v3: Real-time subscription & like verified successfully! +$rewardCoins coins credited.",
            channelTitle = channelName
        )
    }

    /**
     * Auto-fetches Video Title, Channel Name, Channel ID, and Thumbnail for any YouTube Video URL.
     * Queries YouTube Data API v3 when an access token or API key is provided, with an instant
     * zero-quota fallback to YouTube's official oEmbed metadata endpoint.
     */
    suspend fun fetchVideoDetails(
        videoUrlOrId: String,
        accessToken: String? = null
    ): Result<YouTubeVideoDetails> = withContext(Dispatchers.IO) {
        val videoId = extractVideoId(videoUrlOrId)
        if (videoId.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Invalid YouTube URL or Video ID"))
        }

        val defaultThumb = "https://img.youtube.com/vi/$videoId/hqdefault.jpg"

        // 1. Try YouTube Data API v3 if accessToken is provided
        if (!accessToken.isNullOrBlank()) {
            try {
                val bearerAuth = if (accessToken.startsWith("Bearer ", ignoreCase = true)) accessToken else "Bearer $accessToken"
                val apiUrl = "https://www.googleapis.com/youtube/v3/videos?part=snippet&id=$videoId"
                val request = Request.Builder()
                    .url(apiUrl)
                    .addHeader("Authorization", bearerAuth)
                    .build()
                val response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val json = JSONObject(body)
                    val items = json.optJSONArray("items")
                    if (items != null && items.length() > 0) {
                        val snippet = items.getJSONObject(0).optJSONObject("snippet")
                        if (snippet != null) {
                            val title = snippet.optString("title", "")
                            val channelTitle = snippet.optString("channelTitle", "")
                            val channelId = snippet.optString("channelId", "")
                            val highThumb = snippet.optJSONObject("thumbnails")
                                ?.optJSONObject("high")?.optString("url") ?: defaultThumb

                            if (title.isNotBlank()) {
                                return@withContext Result.success(
                                    YouTubeVideoDetails(
                                        videoId = videoId,
                                        title = title,
                                        channelTitle = channelTitle,
                                        channelId = channelId,
                                        thumbnailUrl = highThumb
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "YouTube Data API v3 video fetch fallback: ${e.message}")
            }
        }

        // 2. High-speed, zero-quota official YouTube oEmbed fallback
        try {
            val oembedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$videoId&format=json"
            val request = Request.Builder()
                .url(oembedUrl)
                .build()
            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: ""
                val json = JSONObject(body)
                val title = json.optString("title", "")
                val channelTitle = json.optString("author_name", "")
                val authorUrl = json.optString("author_url", "")
                val channelId = if (authorUrl.contains("/channel/")) {
                    authorUrl.substringAfter("/channel/").substringBefore("/")
                } else ""

                if (title.isNotBlank() || channelTitle.isNotBlank()) {
                    return@withContext Result.success(
                        YouTubeVideoDetails(
                            videoId = videoId,
                            title = title,
                            channelTitle = channelTitle,
                            channelId = channelId,
                            thumbnailUrl = defaultThumb
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "oEmbed fetch exception: ${e.message}")
        }

        // 3. HTML scrape fallback if network is restricted
        try {
            val url = URL("https://www.youtube.com/watch?v=$videoId")
            val conn = url.openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            val html = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val titleMatch = Regex("""<title>(.*?)( - YouTube)?</title>""").find(html)
            val channelMatch = Regex("""\"ownerChannelName\":\"(.*?)\"""").find(html)
                ?: Regex("""\"author\":\"(.*?)\"""").find(html)
            val channelIdMatch = Regex("""\"channelId\":\"(UC[a-zA-Z0-9_-]{22})\"""").find(html)

            val title = titleMatch?.groupValues?.get(1)?.trim() ?: ""
            val channel = channelMatch?.groupValues?.get(1)?.trim() ?: ""
            val chId = channelIdMatch?.groupValues?.get(1)?.trim() ?: ""

            if (title.isNotBlank()) {
                return@withContext Result.success(
                    YouTubeVideoDetails(
                        videoId = videoId,
                        title = title,
                        channelTitle = channel,
                        channelId = chId,
                        thumbnailUrl = defaultThumb
                    )
                )
            }
        } catch (e: Exception) {
            Log.d(TAG, "HTML title extract exception: ${e.message}")
        }

        Result.failure(RuntimeException("Unable to fetch video details from YouTube"))
    }
}
