package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.ReloadRequestEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReloadRequestDao {
    @Query("SELECT * FROM reload_requests ORDER BY timestamp DESC")
    fun getAllReloadRequests(): Flow<List<ReloadRequestEntity>>

    @Query("SELECT * FROM reload_requests WHERE userEmail = :email ORDER BY timestamp DESC")
    fun getReloadRequestsForUser(email: String): Flow<List<ReloadRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReloadRequest(request: ReloadRequestEntity): Long

    @Query("SELECT * FROM reload_requests WHERE id = :id")
    suspend fun getReloadRequestById(id: Long): ReloadRequestEntity?

    @Query("UPDATE reload_requests SET status = :status, approvedTimestamp = :timestamp, adminNote = :note WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, timestamp: Long, note: String = "")

    @Query("SELECT COUNT(*) FROM reload_requests WHERE status = 'PENDING'")
    fun getPendingCount(): Flow<Int>

    @Query("DELETE FROM reload_requests WHERE id = :id")
    suspend fun deleteReloadRequest(id: Long)
}
