package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reload_requests")
data class ReloadRequestEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userEmail: String,
    val phoneNumber: String,
    val operator: String, // Dialog, Mobitel, Airtel, Hutch
    val connectionType: String, // PREPAID, POSTPAID
    val amountLkr: Int, // e.g. 50, 100, 200, 500
    val coinsRequired: Int, // e.g. 5000, 10000
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED
    val timestamp: Long = System.currentTimeMillis(),
    val approvedTimestamp: Long = 0L,
    val adminNote: String = ""
)
