package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userEmail: String,
    val campaignId: Long,
    val videoTitle: String,
    val channelName: String,
    val actionType: String, // "WATCH", "SUBSCRIBE", "AD_REWARD"
    val coinsEarned: Int,
    val timestamp: Long = System.currentTimeMillis()
)
