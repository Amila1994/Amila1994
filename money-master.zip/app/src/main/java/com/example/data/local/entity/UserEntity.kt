package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val email: String,
    val coins: Int = 100,
    val dailyAdsWatched: Int = 0,
    val lastAdDate: String = "",
    val totalEarned: Int = 0,
    val totalSpent: Int = 0,
    val videosWatchedCount: Int = 0,
    val channelsSubscribedCount: Int = 0,
    val isBanned: Boolean = false,
    val isAdmin: Boolean = false,
    val eligibleReloadCoins: Int = 0,
    val fullTasksCompletedCount: Int = 0
)
