package com.example.data.model

data class AdminEconomyConfig(
    val rewardPerSubscribe: Int = 50,
    val rewardPerLike: Int = 20,
    val rewardPerComment: Int = 20,
    val rewardPerWatchMinute: Int = 15,
    val costPerSubscribe: Int = 100,
    val costPerLike: Int = 50,
    val costPerWatchMinute: Int = 30,
    val rewardPerAd: Int = 25,
    val maxDailyAds: Int = 20,
    val isReloadServiceActive: Boolean = true,
    val coinsPerLkrReload: Int = 100,
    val minReloadAmountLkr: Int = 50
)
