package com.example.data.model

data class AdminEconomyConfig(
    val rewardPerLike: Int = 20,
    val rewardPerSubscribe: Int = 50,
    val rewardPerWatchMinute: Int = 15,
    val costPerSubscribe: Int = 100,
    val costPerLike: Int = 50,
    val costPerWatchMinute: Int = 30
)
