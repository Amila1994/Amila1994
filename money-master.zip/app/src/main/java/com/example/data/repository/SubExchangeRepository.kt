package com.example.data.repository

import android.content.Context
import com.example.data.local.dao.CampaignDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.WatchHistoryDao
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WatchHistoryEntity
import com.example.data.model.AdminEconomyConfig
import com.example.data.model.AppUpdateConfig
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SubExchangeRepository(
    private val userDao: UserDao,
    private val campaignDao: CampaignDao,
    private val watchHistoryDao: WatchHistoryDao,
    private val reloadRequestDao: com.example.data.local.dao.ReloadRequestDao? = null,
    private val context: Context? = null
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val economyPrefs = context?.getSharedPreferences("subexchange_economy_config", Context.MODE_PRIVATE)
    private val updatePrefs = context?.getSharedPreferences("subexchange_update_config", Context.MODE_PRIVATE)

    fun getEconomyConfig(): AdminEconomyConfig {
        if (economyPrefs == null) return AdminEconomyConfig()
        return AdminEconomyConfig(
            rewardPerSubscribe = economyPrefs.getInt("rewardPerSubscribe", 50),
            rewardPerLike = economyPrefs.getInt("rewardPerLike", 20),
            rewardPerComment = economyPrefs.getInt("rewardPerComment", 20),
            rewardPerWatchMinute = economyPrefs.getInt("rewardPerWatchMinute", 15),
            costPerSubscribe = economyPrefs.getInt("costPerSubscribe", 100),
            costPerLike = economyPrefs.getInt("costPerLike", 50),
            costPerWatchMinute = economyPrefs.getInt("costPerWatchMinute", 30),
            rewardPerAd = economyPrefs.getInt("rewardPerAd", 25),
            maxDailyAds = economyPrefs.getInt("maxDailyAds", 20),
            isReloadServiceActive = economyPrefs.getBoolean("isReloadServiceActive", true),
            coinsPerLkrReload = economyPrefs.getInt("coinsPerLkrReload", 100),
            minReloadAmountLkr = economyPrefs.getInt("minReloadAmountLkr", 50)
        )
    }

    fun saveEconomyConfig(config: AdminEconomyConfig) {
        economyPrefs?.edit()
            ?.putInt("rewardPerSubscribe", config.rewardPerSubscribe)
            ?.putInt("rewardPerLike", config.rewardPerLike)
            ?.putInt("rewardPerComment", config.rewardPerComment)
            ?.putInt("rewardPerWatchMinute", config.rewardPerWatchMinute)
            ?.putInt("costPerSubscribe", config.costPerSubscribe)
            ?.putInt("costPerLike", config.costPerLike)
            ?.putInt("costPerWatchMinute", config.costPerWatchMinute)
            ?.putInt("rewardPerAd", config.rewardPerAd)
            ?.putInt("maxDailyAds", config.maxDailyAds)
            ?.putBoolean("isReloadServiceActive", config.isReloadServiceActive)
            ?.putInt("coinsPerLkrReload", config.coinsPerLkrReload)
            ?.putInt("minReloadAmountLkr", config.minReloadAmountLkr)
            ?.apply()
    }

    fun getUpdateConfig(): AppUpdateConfig {
        if (updatePrefs == null) return AppUpdateConfig()
        return AppUpdateConfig(
            requiredVersionCode = updatePrefs.getInt("requiredVersionCode", 1),
            versionName = updatePrefs.getString("versionName", "1.0") ?: "1.0",
            updateTitle = updatePrefs.getString("updateTitle", "Sub Exchange New Version Available!") ?: "Sub Exchange New Version Available!",
            updateMessage = updatePrefs.getString("updateMessage", "A new update is available. Please update the app to continue watching videos and earning coins.") ?: "",
            downloadUrl = updatePrefs.getString("downloadUrl", "https://play.google.com/store/apps/details?id=com.sub4sub.exchangeapp") ?: "https://play.google.com/store/apps/details?id=com.sub4sub.exchangeapp",
            directApkDownloadUrl = updatePrefs.getString("directApkDownloadUrl", "") ?: "",
            tutorialVideoUrl = updatePrefs.getString("tutorialVideoUrl", "") ?: "",
            announcementImageUrl = updatePrefs.getString("announcementImageUrl", "") ?: "",
            requireVideoWatch = updatePrefs.getBoolean("requireVideoWatch", false),
            isMandatory = updatePrefs.getBoolean("isMandatory", false),
            lastAnnouncedTimestamp = updatePrefs.getLong("lastAnnouncedTimestamp", 0L)
        )
    }

    fun saveUpdateConfig(config: AppUpdateConfig) {
        updatePrefs?.edit()
            ?.putInt("requiredVersionCode", config.requiredVersionCode)
            ?.putString("versionName", config.versionName)
            ?.putString("updateTitle", config.updateTitle)
            ?.putString("updateMessage", config.updateMessage)
            ?.putString("downloadUrl", config.downloadUrl)
            ?.putString("directApkDownloadUrl", config.directApkDownloadUrl)
            ?.putString("tutorialVideoUrl", config.tutorialVideoUrl)
            ?.putString("announcementImageUrl", config.announcementImageUrl)
            ?.putBoolean("requireVideoWatch", config.requireVideoWatch)
            ?.putBoolean("isMandatory", config.isMandatory)
            ?.putLong("lastAnnouncedTimestamp", config.lastAnnouncedTimestamp)
            ?.apply()
    }

    fun getUser(email: String): Flow<UserEntity?> = userDao.getUserByEmail(email)

    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()

    fun getActiveCampaigns(): Flow<List<CampaignEntity>> = campaignDao.getActiveCampaigns()

    fun getAllCampaigns(): Flow<List<CampaignEntity>> = campaignDao.getAllCampaigns()

    fun getCampaignsByCreator(email: String): Flow<List<CampaignEntity>> =
        campaignDao.getCampaignsByCreator(email)

    fun getWatchHistory(email: String): Flow<List<WatchHistoryEntity>> =
        watchHistoryDao.getHistoryForUser(email)

    fun getCompletedCampaignIds(email: String): Flow<List<Long>> =
        watchHistoryDao.getCompletedCampaignIds(email)

    suspend fun hasCompletedAdminCampaign(userEmail: String, adminCampaignId: Long): Boolean {
        return watchHistoryDao.hasCompletedCampaign(userEmail, adminCampaignId) > 0
    }

    suspend fun ensureUserExists(email: String): UserEntity {
        val cleanEmail = email.trim()
        val existing = userDao.getUserSync(cleanEmail)
        val today = dateFormat.format(Date())
        val isAdmin = cleanEmail.equals("amilalasantha940703@gmail.com", ignoreCase = true)
        if (existing == null) {
            val remoteCoins = com.example.data.firebase.FirebaseService.getUserCoins(cleanEmail)
            val startingCoins = if (isAdmin) 9999 else if (remoteCoins != 100 && remoteCoins > 0) remoteCoins else 0
            val newUser = UserEntity(
                email = cleanEmail,
                coins = startingCoins,
                dailyAdsWatched = 0,
                lastAdDate = today,
                totalEarned = startingCoins,
                totalSpent = 0,
                videosWatchedCount = 0,
                channelsSubscribedCount = 0,
                isBanned = false,
                isAdmin = isAdmin
            )
            userDao.insertUser(newUser)
            com.example.data.firebase.FirebaseService.updateUserCoins(newUser.email, newUser.coins)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(newUser)
            return newUser
        } else {
            val updated = if (existing.isAdmin != isAdmin) existing.copy(isAdmin = isAdmin) else existing
            if (updated.lastAdDate != today) {
                userDao.resetDailyAds(cleanEmail, today)
                val resetUser = updated.copy(dailyAdsWatched = 0, lastAdDate = today)
                com.example.data.firebase.FirebaseService.syncUserToFirestore(resetUser)
                return resetUser
            }
            com.example.data.firebase.FirebaseService.updateUserCoins(updated.email, updated.coins)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(updated)
            return updated
        }
    }

    suspend fun seedSampleDataIfEmpty() {
        // PERMANENT PURGE: Remove all sample mock users and sample dummy campaigns for Live Production
        try {
            userDao.deleteSampleUsers()
            campaignDao.deleteSampleCampaigns()
        } catch (_: Exception) {}

        // Ensure strictly only the designated Admin exists
        ensureUserExists("amilalasantha940703@gmail.com")
    }

    suspend fun claimFullEngagementReward(
        userEmail: String,
        campaign: CampaignEntity,
        subCoins: Int,
        likeCoins: Int,
        commentCoins: Int
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted (BAN)"))
        }

        val completedCount = watchHistoryDao.hasCompletedCampaign(userEmail, campaign.id)
        if (completedCount > 0 && !campaign.isAdminPriority) {
            return Result.failure(Exception("You have already completed this campaign!"))
        }

        val totalReward = subCoins + likeCoins + commentCoins
        userDao.addCoins(userEmail, totalReward)
        userDao.addEligibleReloadCoins(userEmail, totalReward)
        campaignDao.incrementProgress(campaign.id)

        val history = WatchHistoryEntity(
            userEmail = userEmail,
            campaignId = campaign.id,
            videoTitle = campaign.videoTitle,
            channelName = campaign.channelName,
            coinsEarned = totalReward,
            actionType = "SUB_LIKE_COMMENT"
        )
        watchHistoryDao.insertHistory(history)

        val updatedUser = userDao.getUserSync(userEmail)
        if (updatedUser != null) {
            com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, updatedUser.coins)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)
        }

        return Result.success(totalReward)
    }

    suspend fun completeVideoTask(
        userEmail: String,
        campaign: CampaignEntity,
        isSubscribeAction: Boolean
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted"))
        }

        // Anti-duplicate check (exempt admin global priority campaigns)
        val completedCount = watchHistoryDao.hasCompletedCampaign(userEmail, campaign.id)
        if (completedCount > 0 && !campaign.isAdminPriority) {
            return Result.failure(Exception("You have already completed this campaign!"))
        }

        val minutes = (campaign.durationSeconds / 60).coerceAtLeast(1)
        val configReward = getEconomyConfig().rewardPerWatchMinute * minutes
        val reward = if (campaign.rewardCoins > 0) campaign.rewardCoins else configReward
        val newCoins = user.coins + reward

        // Update user stats in Room DB
        val updatedUser = user.copy(
            coins = newCoins,
            totalEarned = user.totalEarned + reward,
            videosWatchedCount = user.videosWatchedCount + 1,
            channelsSubscribedCount = if (isSubscribeAction) user.channelsSubscribedCount + 1 else user.channelsSubscribedCount
        )
        userDao.updateUser(updatedUser)

        // Increment campaign progress
        campaignDao.incrementProgress(campaign.id)
        val updatedCampaign = campaignDao.getCampaignById(campaign.id)
        if (updatedCampaign != null && updatedCampaign.currentCount >= updatedCampaign.targetCount) {
            campaignDao.toggleActive(campaign.id, false)
        }

        // Record history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = campaign.id,
                videoTitle = campaign.videoTitle,
                channelName = campaign.channelName,
                actionType = if (isSubscribeAction) "SUBSCRIBE" else "WATCH",
                coinsEarned = reward
            )
        )

        // Sync with Firebase
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, newCoins)
        com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)

        return Result.success(reward)
    }

    /**
     * Confirms and rewards user for subscribing to a channel.
     * Checks anti-unsubscribe history for 6 months (180 days).
     * If user unsubscribed from YouTube and returns to re-subscribe to farm coins,
     * AUTO-BAN is immediately triggered!
     */
    suspend fun claimSubscriptionReward(
        userEmail: String,
        campaign: CampaignEntity
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted: You are banned."))
        }

        // 6-month (180 days) Anti-Unsubscribe & Duplicate Check
        val sixMonthsAgo = System.currentTimeMillis() - (180L * 24 * 60 * 60 * 1000L)
        val pastSubscription = watchHistoryDao.getRecentSubscription(userEmail, campaign.channelName, sixMonthsAgo)
        if (pastSubscription != null && !campaign.isAdminPriority) {
            // User was already rewarded for subscribing to this channel within 6 months.
            // This means they unsubscribed on YouTube and are trying to re-subscribe to farm coins.
            // AUTO-BAN the account as instructed!
            userDao.setBannedStatus(userEmail, true)
            com.example.data.firebase.FirebaseService.updateUserBanned(userEmail, true)
            return Result.failure(Exception("ANTI-CHEAT BAN: Auto-ban triggered! You previously subscribed to '${campaign.channelName}' within the last 6 months. Unsubscribing on YouTube to re-claim coins violates policies. Your account is permanently banned."))
        }

        val existingCompleted = watchHistoryDao.hasCompletedCampaign(userEmail, campaign.id)
        if (existingCompleted > 0 && !campaign.isAdminPriority) {
            return Result.failure(Exception("You have already subscribed to ${campaign.channelName} and claimed coins!"))
        }

        val reward = if (campaign.rewardCoins > 0) campaign.rewardCoins else getEconomyConfig().rewardPerSubscribe
        val newCoins = user.coins + reward

        val updatedUser = user.copy(
            coins = newCoins,
            totalEarned = user.totalEarned + reward,
            channelsSubscribedCount = user.channelsSubscribedCount + 1
        )
        userDao.updateUser(updatedUser)

        // Increment campaign progress
        campaignDao.incrementProgress(campaign.id)
        val updatedCampaign = campaignDao.getCampaignById(campaign.id)
        if (updatedCampaign != null && updatedCampaign.currentCount >= updatedCampaign.targetCount) {
            campaignDao.toggleActive(campaign.id, false)
        }

        // Record history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = campaign.id,
                videoTitle = campaign.videoTitle,
                channelName = campaign.channelName,
                actionType = "SUBSCRIBE",
                coinsEarned = reward
            )
        )

        // Sync with Firebase
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, newCoins)
        com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)

        return Result.success(reward)
    }

    /**
     * Confirms and rewards user for liking a video on YouTube.
     * Updates coins based on Admin Economy Configuration.
     */
    suspend fun claimLikeReward(
        userEmail: String,
        campaign: CampaignEntity
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted: You are banned."))
        }

        val existingCompleted = watchHistoryDao.hasCompletedCampaign(userEmail, campaign.id)
        if (existingCompleted > 0 && !campaign.isAdminPriority) {
            return Result.failure(Exception("You have already liked '${campaign.videoTitle}' and claimed coins!"))
        }

        val reward = getEconomyConfig().rewardPerLike
        val newCoins = user.coins + reward

        val updatedUser = user.copy(
            coins = newCoins,
            totalEarned = user.totalEarned + reward
        )
        userDao.updateUser(updatedUser)

        // Increment campaign progress
        campaignDao.incrementProgress(campaign.id)
        val updatedCampaign = campaignDao.getCampaignById(campaign.id)
        if (updatedCampaign != null && updatedCampaign.currentCount >= updatedCampaign.targetCount) {
            campaignDao.toggleActive(campaign.id, false)
        }

        // Record history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = campaign.id,
                videoTitle = campaign.videoTitle,
                channelName = campaign.channelName,
                actionType = "LIKE",
                coinsEarned = reward
            )
        )

        // Sync with Firebase
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, newCoins)
        com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)

        return Result.success(reward)
    }

    /**
     * Confirms and rewards user for commenting on a video on YouTube.
     */
    suspend fun claimCommentReward(
        userEmail: String,
        campaign: CampaignEntity,
        commentText: String
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted: You are banned."))
        }

        val reward = 20
        val newCoins = user.coins + reward

        val updatedUser = user.copy(
            coins = newCoins,
            totalEarned = user.totalEarned + reward
        )
        userDao.updateUser(updatedUser)

        // Increment campaign progress
        campaignDao.incrementProgress(campaign.id)

        // Record history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = campaign.id,
                videoTitle = campaign.videoTitle,
                channelName = campaign.channelName,
                actionType = "COMMENT: $commentText",
                coinsEarned = reward
            )
        )

        // Sync with Firebase
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, newCoins)
        com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)

        return Result.success(reward)
    }

    suspend fun watchAdForBonus(userEmail: String): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        val config = getEconomyConfig()
        val maxDaily = config.maxDailyAds
        val today = dateFormat.format(Date())

        var currentWatched = user.dailyAdsWatched
        if (user.lastAdDate != today) {
            currentWatched = 0
            userDao.resetDailyAds(userEmail, today)
        }

        if (currentWatched >= maxDaily) {
            return Result.failure(Exception("Daily ad limit reached ($maxDaily ads/day)"))
        }

        val bonusReward = config.rewardPerAd
        userDao.recordAdWatched(userEmail, bonusReward)
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, user.coins + bonusReward)

        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = -1,
                videoTitle = "Rewarded Partner Ad",
                channelName = "SubExchange Sponsor Network",
                actionType = "AD_REWARD",
                coinsEarned = bonusReward
            )
        )

        return Result.success(bonusReward)
    }

    suspend fun createCampaign(
        creatorEmail: String,
        videoUrl: String,
        videoTitle: String,
        channelName: String,
        thumbnailUrl: String,
        campaignType: String,
        targetCount: Int,
        durationSeconds: Int,
        costPerAction: Int,
        isAdminPriority: Boolean = false,
        isGlobal: Boolean = false
    ): Result<Long> {
        val user = userDao.getUserSync(creatorEmail) ?: return Result.failure(Exception("User not found"))
        val isAdmin = creatorEmail.equals("amilalasantha940703@gmail.com", ignoreCase = true)
        val effectiveAdminPriority = isAdminPriority || isAdmin
        val effectiveIsGlobal = isGlobal || isAdmin
        val totalCost = if (isAdmin) 0 else targetCount * costPerAction

        if (!isAdmin && user.coins < totalCost) {
            return Result.failure(Exception("Insufficient coins! Required: $totalCost, Available: ${user.coins}"))
        }

        if (!isAdmin && totalCost > 0) {
            userDao.deductCoins(creatorEmail, totalCost)
            val remainingCoins = user.coins - totalCost
            com.example.data.firebase.FirebaseService.updateUserCoins(creatorEmail, remainingCoins)
        }

        val rewardPerAction = when (campaignType) {
            "SUBSCRIBE" -> if (effectiveAdminPriority) 100 else 50
            "VIEW" -> if (durationSeconds >= 300) 50 else (durationSeconds / 6)
            else -> 25
        }

        val campaign = CampaignEntity(
            creatorEmail = creatorEmail,
            videoUrl = videoUrl,
            videoTitle = videoTitle,
            channelName = channelName,
            thumbnailUrl = thumbnailUrl.ifBlank {
                "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80"
            },
            campaignType = campaignType,
            targetCount = targetCount,
            currentCount = 0,
            durationSeconds = durationSeconds,
            rewardCoins = rewardPerAction,
            totalCostCoins = totalCost,
            isAdminPriority = effectiveAdminPriority,
            isGlobal = effectiveIsGlobal,
            isActive = true
        )

        val id = campaignDao.insertCampaign(campaign)
        com.example.data.firebase.FirebaseService.syncCampaignToFirestore(campaign.copy(id = id))
        return Result.success(id)
    }

    suspend fun toggleCampaignActive(id: Long, isActive: Boolean) {
        campaignDao.toggleActive(id, isActive)
    }

    suspend fun deleteCampaign(campaign: CampaignEntity) {
        campaignDao.deleteCampaign(campaign)
    }

    suspend fun setUserBanned(email: String, banned: Boolean) {
        userDao.setBannedStatus(email, banned)
        com.example.data.firebase.FirebaseService.updateUserBanned(email, banned)
    }

    suspend fun grantAdminBonusCoins(email: String, amount: Int) {
        userDao.addCoins(email, amount)
        userDao.getUserSync(email)?.let {
            com.example.data.firebase.FirebaseService.updateUserCoins(email, it.coins)
        }
    }

    suspend fun setUserCoins(email: String, newBalance: Int) {
        val safeBalance = newBalance.coerceAtLeast(0)
        userDao.setCoins(email, safeBalance)
        com.example.data.firebase.FirebaseService.updateUserCoins(email, safeBalance)
    }

    suspend fun modifyUserCoins(email: String, delta: Int) {
        val user = userDao.getUserSync(email) ?: return
        val updated = (user.coins + delta).coerceAtLeast(0)
        setUserCoins(email, updated)
    }

    suspend fun setCampaignAdminPriority(id: Long, isPriority: Boolean) {
        campaignDao.setAdminPriority(id, isPriority)
    }

    suspend fun setCampaignGlobal(id: Long, isGlobal: Boolean) {
        campaignDao.setGlobal(id, isGlobal)
    }

    suspend fun deleteUser(email: String) {
        userDao.deleteUserByEmail(email)
        campaignDao.deleteCampaignsByCreator(email)
        com.example.data.firebase.FirebaseService.deleteUser(email)
    }

    // --- Mobile Reload System ---
    fun getAllReloadRequests(): Flow<List<com.example.data.local.entity.ReloadRequestEntity>> =
        reloadRequestDao?.getAllReloadRequests() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    fun getReloadRequestsForUser(email: String): Flow<List<com.example.data.local.entity.ReloadRequestEntity>> =
        reloadRequestDao?.getReloadRequestsForUser(email) ?: kotlinx.coroutines.flow.flowOf(emptyList())

    fun getPendingReloadCount(): Flow<Int> =
        reloadRequestDao?.getPendingCount() ?: kotlinx.coroutines.flow.flowOf(0)

    suspend fun submitReloadRequest(
        userEmail: String,
        phoneNumber: String,
        operator: String,
        connectionType: String,
        amountLkr: Int
    ): Result<Long> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted: You are banned."))
        }
        val config = getEconomyConfig()
        if (!config.isReloadServiceActive) {
            return Result.failure(Exception("Mobile reload service is temporarily disabled by admin."))
        }
        val coinsRequired = amountLkr * config.coinsPerLkrReload

        if (user.coins < coinsRequired) {
            return Result.failure(Exception("Insufficient total coins! Required: $coinsRequired, Available: ${user.coins}"))
        }

        // Admin is exempt from video task restriction; regular users must have completed tasks
        val isAdmin = user.email.equals("amilalasantha940703@gmail.com", ignoreCase = true)
        val eligibleCoins = if (isAdmin || user.eligibleReloadCoins > 0) {
            user.eligibleReloadCoins.coerceAtLeast(user.coins)
        } else {
            user.eligibleReloadCoins
        }

        if (!isAdmin && eligibleCoins < coinsRequired) {
            return Result.failure(Exception("Only coins earned by completing video tasks (Watch + Subscribe + Like + Comment) are eligible for mobile reload! Eligible: $eligibleCoins, Required: $coinsRequired"))
        }

        val request = com.example.data.local.entity.ReloadRequestEntity(
            userEmail = userEmail,
            phoneNumber = phoneNumber.trim(),
            operator = operator,
            connectionType = connectionType,
            amountLkr = amountLkr,
            coinsRequired = coinsRequired,
            status = "PENDING",
            timestamp = System.currentTimeMillis()
        )
        val id = reloadRequestDao?.insertReloadRequest(request) ?: 0L

        // NOTE: Coins are NOT deducted here! They are ONLY deducted when admin approves!
        return Result.success(id)
    }

    suspend fun approveReloadRequest(id: Long, adminNote: String = "Approved by Admin"): Result<Unit> {
        val request = reloadRequestDao?.getReloadRequestById(id) ?: return Result.failure(Exception("Request not found"))
        if (request.status == "APPROVED") {
            return Result.failure(Exception("Reload request is already approved"))
        }

        val user = userDao.getUserSync(request.userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.coins < request.coinsRequired) {
            return Result.failure(Exception("User only has ${user.coins} coins, but reload requires ${request.coinsRequired} coins!"))
        }

        // CRITICAL REQUIREMENT: Coins are deducted ONLY upon admin approval!
        userDao.deductCoins(request.userEmail, request.coinsRequired)
        userDao.deductEligibleReloadCoins(request.userEmail, request.coinsRequired)

        val updatedUser = userDao.getUserSync(request.userEmail)
        if (updatedUser != null) {
            com.example.data.firebase.FirebaseService.updateUserCoins(request.userEmail, updatedUser.coins)
        }

        reloadRequestDao?.updateStatus(id, "APPROVED", System.currentTimeMillis(), adminNote)

        // Record successful reload in history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = request.userEmail,
                campaignId = -2L,
                videoTitle = "Mobile Reload - Rs. ${request.amountLkr} (${request.operator})",
                channelName = "${request.phoneNumber} [${request.connectionType}]",
                actionType = "RELOAD_SUCCESS",
                coinsEarned = -request.coinsRequired
            )
        )

        return Result.success(Unit)
    }

    suspend fun rejectReloadRequest(id: Long, reason: String = "Rejected by Admin"): Result<Unit> {
        val request = reloadRequestDao?.getReloadRequestById(id) ?: return Result.failure(Exception("Request not found"))
        if (request.status == "APPROVED") {
            return Result.failure(Exception("Cannot reject an already approved reload!"))
        }
        reloadRequestDao?.updateStatus(id, "REJECTED", System.currentTimeMillis(), reason)
        return Result.success(Unit)
    }

    fun toggleReloadService(isActive: Boolean) {
        val current = getEconomyConfig()
        saveEconomyConfig(current.copy(isReloadServiceActive = isActive))
    }
}
