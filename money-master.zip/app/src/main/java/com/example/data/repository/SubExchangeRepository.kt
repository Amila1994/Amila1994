package com.example.data.repository

import com.example.data.local.dao.CampaignDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.WatchHistoryDao
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WatchHistoryEntity
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SubExchangeRepository(
    private val userDao: UserDao,
    private val campaignDao: CampaignDao,
    private val watchHistoryDao: WatchHistoryDao
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun getUser(email: String): Flow<UserEntity?> = userDao.getUserByEmail(email)

    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()

    fun getActiveCampaigns(): Flow<List<CampaignEntity>> = campaignDao.getActiveCampaigns()

    fun getAllCampaigns(): Flow<List<CampaignEntity>> = campaignDao.getAllCampaigns()

    fun getCampaignsByCreator(email: String): Flow<List<CampaignEntity>> =
        campaignDao.getCampaignsByCreator(email)

    fun getWatchHistory(email: String): Flow<List<WatchHistoryEntity>> =
        watchHistoryDao.getHistoryForUser(email)

    suspend fun ensureUserExists(email: String): UserEntity {
        val existing = userDao.getUserSync(email)
        val today = dateFormat.format(Date())
        if (existing == null) {
            val isAdmin = email.equals("amilalasantha940703@gmail.com", ignoreCase = true) ||
                    email.equals("admin@gmail.com", ignoreCase = true) ||
                    email.equals("amila940703@gmail.com", ignoreCase = true)
            val remoteCoins = com.example.data.firebase.FirebaseService.getUserCoins(email)
            val startingCoins = if (isAdmin) 9999 else if (remoteCoins != 100) remoteCoins else 100
            val newUser = UserEntity(
                email = email,
                coins = startingCoins,
                dailyAdsWatched = 0,
                lastAdDate = today,
                totalEarned = startingCoins,
                totalSpent = 0,
                videosWatchedCount = 0,
                channelsSubscribedCount = 0,
                isBanned = false,
                isAdmin = isAdmin
            )
            userDao.insertUser(newUser)
            com.example.data.firebase.FirebaseService.updateUserCoins(newUser.email, newUser.coins)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(newUser)
            return newUser
        } else {
            // Check if ad counter should be reset for new day
            if (existing.lastAdDate != today) {
                userDao.resetDailyAds(email, today)
                val resetUser = existing.copy(dailyAdsWatched = 0, lastAdDate = today)
                com.example.data.firebase.FirebaseService.syncUserToFirestore(resetUser)
                return resetUser
            }
            com.example.data.firebase.FirebaseService.updateUserCoins(existing.email, existing.coins)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(existing)
            return existing
        }
    }

    suspend fun seedSampleDataIfEmpty() {
        val today = dateFormat.format(Date())
        // Seed mock users for admin panel
        val mockUsers = listOf(
            UserEntity("amilalasantha940703@gmail.com", coins = 9999, dailyAdsWatched = 2, lastAdDate = today, totalEarned = 12000, totalSpent = 2000, videosWatchedCount = 45, channelsSubscribedCount = 30, isAdmin = true),
            UserEntity("admin@gmail.com", coins = 9999, dailyAdsWatched = 2, lastAdDate = today, totalEarned = 12000, totalSpent = 2000, videosWatchedCount = 45, channelsSubscribedCount = 30, isAdmin = true),
            UserEntity("amila940703@gmail.com", coins = 250, dailyAdsWatched = 3, lastAdDate = today, totalEarned = 500, totalSpent = 250, videosWatchedCount = 8, channelsSubscribedCount = 5, isAdmin = true),
            UserEntity("tech_master@gmail.com", coins = 120, dailyAdsWatched = 1, lastAdDate = today, totalEarned = 320, totalSpent = 200, videosWatchedCount = 12, channelsSubscribedCount = 7, isAdmin = false),
            UserEntity("gamer_zone@gmail.com", coins = 40, dailyAdsWatched = 15, lastAdDate = today, totalEarned = 450, totalSpent = 410, videosWatchedCount = 20, channelsSubscribedCount = 15, isAdmin = false),
            UserEntity("music_vibes@gmail.com", coins = 0, dailyAdsWatched = 5, lastAdDate = today, totalEarned = 250, totalSpent = 250, videosWatchedCount = 5, channelsSubscribedCount = 4, isBanned = true, isAdmin = false)
        )
        for (u in mockUsers) {
            val ex = userDao.getUserSync(u.email)
            if (ex == null) {
                userDao.insertUser(u)
            }
        }

        // Seed initial campaigns
        val initialCampaigns = listOf(
            CampaignEntity(
                creatorEmail = "amilalasantha940703@gmail.com",
                videoUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                videoTitle = "⭐ Official Admin Priority Campaign: Watch, Like & Subscribe",
                channelName = "Amila Lasantha Official",
                thumbnailUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
                campaignType = "SUBSCRIBE",
                targetCount = 1000,
                currentCount = 215,
                durationSeconds = 180,
                rewardCoins = 100,
                totalCostCoins = 0,
                isAdminPriority = true,
                isGlobal = true,
                isActive = true
            ),
            CampaignEntity(
                creatorEmail = "tech_master@gmail.com",
                videoUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                videoTitle = "Android 16 Compose Masterclass: Build Modern Apps",
                channelName = "Tech Master Studio",
                thumbnailUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=600&auto=format&fit=crop&q=80",
                campaignType = "SUBSCRIBE",
                targetCount = 25,
                currentCount = 14,
                durationSeconds = 300,
                rewardCoins = 50,
                totalCostCoins = 250,
                isActive = true
            ),
            CampaignEntity(
                creatorEmail = "gamer_zone@gmail.com",
                videoUrl = "https://www.youtube.com/watch?v=kXYiU_JCYtU",
                videoTitle = "Top 10 Indie Games Coming in 2026 - Gameplay Showcase",
                channelName = "Gamer Zone Official",
                thumbnailUrl = "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=600&auto=format&fit=crop&q=80",
                campaignType = "VIEW",
                targetCount = 50,
                currentCount = 38,
                durationSeconds = 180,
                rewardCoins = 30,
                totalCostCoins = 300,
                isActive = true
            ),
            CampaignEntity(
                creatorEmail = "music_vibes@gmail.com",
                videoUrl = "https://www.youtube.com/watch?v=fJ9rUzIMcZQ",
                videoTitle = "Chill Lofi Beats To Study / Relax To - 24/7 Mix",
                channelName = "Lo-Fi Lounge Records",
                thumbnailUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
                campaignType = "SUBSCRIBE",
                targetCount = 30,
                currentCount = 22,
                durationSeconds = 300,
                rewardCoins = 50,
                totalCostCoins = 300,
                isActive = true
            ),
            CampaignEntity(
                creatorEmail = "creator_alex@gmail.com",
                videoUrl = "https://www.youtube.com/watch?v=9bZkp7q19f0",
                videoTitle = "Secret Smartphone Camera Hacks You Didn't Know!",
                channelName = "Alex Tech & Gear",
                thumbnailUrl = "https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?w=600&auto=format&fit=crop&q=80",
                campaignType = "LIKE",
                targetCount = 40,
                currentCount = 19,
                durationSeconds = 120,
                rewardCoins = 25,
                totalCostCoins = 200,
                isActive = true
            )
        )

        for (c in initialCampaigns) {
            campaignDao.insertCampaign(c)
        }
    }

    suspend fun completeVideoTask(
        userEmail: String,
        campaign: CampaignEntity,
        isSubscribeAction: Boolean
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted"))
        }

        val reward = campaign.rewardCoins
        userDao.addCoins(userEmail, reward)

        // Increment campaign progress
        campaignDao.incrementProgress(campaign.id)
        val updatedCampaign = campaignDao.getCampaignById(campaign.id)
        if (updatedCampaign != null && updatedCampaign.currentCount >= updatedCampaign.targetCount) {
            campaignDao.toggleActive(campaign.id, false)
        }

        // Record history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = campaign.id,
                videoTitle = campaign.videoTitle,
                channelName = campaign.channelName,
                actionType = if (isSubscribeAction) "SUBSCRIBE" else "WATCH",
                coinsEarned = reward
            )
        )

        // Update user stats
        val updatedUser = user.copy(
            coins = user.coins + reward,
            totalEarned = user.totalEarned + reward,
            videosWatchedCount = user.videosWatchedCount + 1,
            channelsSubscribedCount = if (isSubscribeAction) user.channelsSubscribedCount + 1 else user.channelsSubscribedCount
        )
        userDao.updateUser(updatedUser)
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, updatedUser.coins)

        return Result.success(reward)
    }

    suspend fun watchAdForBonus(userEmail: String): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        val maxDaily = 15
        val today = dateFormat.format(Date())

        var currentWatched = user.dailyAdsWatched
        if (user.lastAdDate != today) {
            currentWatched = 0
            userDao.resetDailyAds(userEmail, today)
        }

        if (currentWatched >= maxDaily) {
            return Result.failure(Exception("Daily ad limit reached ($maxDaily ads/day)"))
        }

        val bonusReward = 25
        userDao.recordAdWatched(userEmail, bonusReward)
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, user.coins + bonusReward)

        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = -1,
                videoTitle = "Rewarded Partner Ad",
                channelName = "SubExchange Sponsor Network",
                actionType = "AD_REWARD",
                coinsEarned = bonusReward
            )
        )

        return Result.success(bonusReward)
    }

    suspend fun createCampaign(
        creatorEmail: String,
        videoUrl: String,
        videoTitle: String,
        channelName: String,
        thumbnailUrl: String,
        campaignType: String,
        targetCount: Int,
        durationSeconds: Int,
        costPerAction: Int,
        isAdminPriority: Boolean = false,
        isGlobal: Boolean = false
    ): Result<Long> {
        val user = userDao.getUserSync(creatorEmail) ?: return Result.failure(Exception("User not found"))
        val isAdmin = creatorEmail.equals("amilalasantha940703@gmail.com", ignoreCase = true)
        val effectiveAdminPriority = isAdminPriority || isAdmin
        val effectiveIsGlobal = isGlobal || isAdmin
        val totalCost = if (isAdmin) 0 else targetCount * costPerAction

        if (!isAdmin && user.coins < totalCost) {
            return Result.failure(Exception("Insufficient coins! Required: $totalCost, Available: ${user.coins}"))
        }

        if (!isAdmin && totalCost > 0) {
            userDao.deductCoins(creatorEmail, totalCost)
            val remainingCoins = user.coins - totalCost
            com.example.data.firebase.FirebaseService.updateUserCoins(creatorEmail, remainingCoins)
        }

        val rewardPerAction = when (campaignType) {
            "SUBSCRIBE" -> if (effectiveAdminPriority) 100 else 50
            "VIEW" -> if (durationSeconds >= 300) 50 else (durationSeconds / 6)
            else -> 25
        }

        val campaign = CampaignEntity(
            creatorEmail = creatorEmail,
            videoUrl = videoUrl,
            videoTitle = videoTitle,
            channelName = channelName,
            thumbnailUrl = thumbnailUrl.ifBlank {
                "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80"
            },
            campaignType = campaignType,
            targetCount = targetCount,
            currentCount = 0,
            durationSeconds = durationSeconds,
            rewardCoins = rewardPerAction,
            totalCostCoins = totalCost,
            isAdminPriority = effectiveAdminPriority,
            isGlobal = effectiveIsGlobal,
            isActive = true
        )

        val id = campaignDao.insertCampaign(campaign)
        com.example.data.firebase.FirebaseService.syncCampaignToFirestore(campaign.copy(id = id))
        return Result.success(id)
    }

    suspend fun toggleCampaignActive(id: Long, isActive: Boolean) {
        campaignDao.toggleActive(id, isActive)
    }

    suspend fun deleteCampaign(campaign: CampaignEntity) {
        campaignDao.deleteCampaign(campaign)
    }

    suspend fun setUserBanned(email: String, banned: Boolean) {
        userDao.setBannedStatus(email, banned)
    }

    suspend fun grantAdminBonusCoins(email: String, amount: Int) {
        userDao.addCoins(email, amount)
        userDao.getUserSync(email)?.let {
            com.example.data.firebase.FirebaseService.updateUserCoins(email, it.coins)
        }
    }

    suspend fun setUserCoins(email: String, newBalance: Int) {
        val safeBalance = newBalance.coerceAtLeast(0)
        userDao.setCoins(email, safeBalance)
        com.example.data.firebase.FirebaseService.updateUserCoins(email, safeBalance)
    }

    suspend fun modifyUserCoins(email: String, delta: Int) {
        val user = userDao.getUserSync(email) ?: return
        val updated = (user.coins + delta).coerceAtLeast(0)
        setUserCoins(email, updated)
    }

    suspend fun setCampaignAdminPriority(id: Long, isPriority: Boolean) {
        campaignDao.setAdminPriority(id, isPriority)
    }

    suspend fun setCampaignGlobal(id: Long, isGlobal: Boolean) {
        campaignDao.setGlobal(id, isGlobal)
    }

    suspend fun deleteUser(email: String) {
        userDao.deleteUserByEmail(email)
        campaignDao.deleteCampaignsByCreator(email)
        com.example.data.firebase.FirebaseService.deleteUser(email)
    }
}
