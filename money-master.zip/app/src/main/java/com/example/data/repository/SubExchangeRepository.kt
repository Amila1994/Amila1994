package com.example.data.repository

import android.content.Context
import com.example.data.local.dao.CampaignDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.WatchHistoryDao
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WatchHistoryEntity
import com.example.data.model.AdminEconomyConfig
import com.example.data.model.AppUpdateConfig
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SubExchangeRepository(
    private val userDao: UserDao,
    private val campaignDao: CampaignDao,
    private val watchHistoryDao: WatchHistoryDao,
    private val reloadRequestDao: com.example.data.local.dao.ReloadRequestDao? = null,
    private val context: Context? = null
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val economyPrefs = context?.getSharedPreferences("subexchange_economy_config", Context.MODE_PRIVATE)
    private val updatePrefs = context?.getSharedPreferences("subexchange_update_config", Context.MODE_PRIVATE)

    fun getEconomyConfig(): AdminEconomyConfig {
        if (economyPrefs == null) return AdminEconomyConfig()
        return AdminEconomyConfig(
            rewardPerSubscribe = economyPrefs.getInt("rewardPerSubscribe", 50),
            rewardPerLike = economyPrefs.getInt("rewardPerLike", 20),
            rewardPerComment = economyPrefs.getInt("rewardPerComment", 20),
            rewardPerWatchMinute = economyPrefs.getInt("rewardPerWatchMinute", 15),
            costPerSubscribe = economyPrefs.getInt("costPerSubscribe", 100),
            costPerLike = economyPrefs.getInt("costPerLike", 50),
            costPerWatchMinute = economyPrefs.getInt("costPerWatchMinute", 30),
            rewardPerAd = economyPrefs.getInt("rewardPerAd", 25),
            maxDailyAds = economyPrefs.getInt("maxDailyAds", 20),
            isReloadServiceActive = economyPrefs.getBoolean("isReloadServiceActive", true),
            coinsPerLkrReload = economyPrefs.getInt("coinsPerLkrReload", 100),
            minReloadAmountLkr = economyPrefs.getInt("minReloadAmountLkr", 50)
        )
    }

    fun saveEconomyConfig(config: AdminEconomyConfig) {
        economyPrefs?.edit()
            ?.putInt("rewardPerSubscribe", config.rewardPerSubscribe)
            ?.putInt("rewardPerLike", config.rewardPerLike)
            ?.putInt("rewardPerComment", config.rewardPerComment)
            ?.putInt("rewardPerWatchMinute", config.rewardPerWatchMinute)
            ?.putInt("costPerSubscribe", config.costPerSubscribe)
            ?.putInt("costPerLike", config.costPerLike)
            ?.putInt("costPerWatchMinute", config.costPerWatchMinute)
            ?.putInt("rewardPerAd", config.rewardPerAd)
            ?.putInt("maxDailyAds", config.maxDailyAds)
            ?.putBoolean("isReloadServiceActive", config.isReloadServiceActive)
            ?.putInt("coinsPerLkrReload", config.coinsPerLkrReload)
            ?.putInt("minReloadAmountLkr", config.minReloadAmountLkr)
            ?.apply()
    }

    fun getUpdateConfig(): AppUpdateConfig {
        if (updatePrefs == null) return AppUpdateConfig()
        return AppUpdateConfig(
            requiredVersionCode = updatePrefs.getInt("requiredVersionCode", 1),
            versionName = updatePrefs.getString("versionName", "1.0") ?: "1.0",
            updateTitle = updatePrefs.getString("updateTitle", "Sub Exchange New Version Available!") ?: "Sub Exchange New Version Available!",
            updateMessage = updatePrefs.getString("updateMessage", "A new update is available. Please update the app to continue watching videos and earning coins.") ?: "",
            downloadUrl = updatePrefs.getString("downloadUrl", "https://play.google.com/store/apps/details?id=com.sub4sub.exchangeapp") ?: "https://play.google.com/store/apps/details?id=com.sub4sub.exchangeapp",
            directApkDownloadUrl = updatePrefs.getString("directApkDownloadUrl", "") ?: "",
            tutorialVideoUrl = updatePrefs.getString("tutorialVideoUrl", "") ?: "",
            announcementImageUrl = updatePrefs.getString("announcementImageUrl", "") ?: "",
            requireVideoWatch = updatePrefs.getBoolean("requireVideoWatch", false),
            isMandatory = updatePrefs.getBoolean("isMandatory", false),
            lastAnnouncedTimestamp = updatePrefs.getLong("lastAnnouncedTimestamp", 0L)
        )
    }

    fun saveUpdateConfig(config: AppUpdateConfig) {
        updatePrefs?.edit()
            ?.putInt("requiredVersionCode", config.requiredVersionCode)
            ?.putString("versionName", config.versionName)
            ?.putString("updateTitle", config.updateTitle)
            ?.putString("updateMessage", config.updateMessage)
            ?.putString("downloadUrl", config.downloadUrl)
            ?.putString("directApkDownloadUrl", config.directApkDownloadUrl)
            ?.putString("tutorialVideoUrl", config.tutorialVideoUrl)
            ?.putString("announcementImageUrl", config.announcementImageUrl)
            ?.putBoolean("requireVideoWatch", config.requireVideoWatch)
            ?.putBoolean("isMandatory", config.isMandatory)
            ?.putLong("lastAnnouncedTimestamp", config.lastAnnouncedTimestamp)
            ?.apply()
    }

    fun getUser(email: String): Flow<UserEntity?> = userDao.getUserByEmail(email)

    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()

    fun getActiveCampaigns(): Flow<List<CampaignEntity>> = campaignDao.getActiveCampaigns()

    fun getAllCampaigns(): Flow<List<CampaignEntity>> = campaignDao.getAllCampaigns()

    fun getCampaignsByCreator(email: String): Flow<List<CampaignEntity>> =
        campaignDao.getCampaignsByCreator(email)

    fun getWatchHistory(email: String): Flow<List<WatchHistoryEntity>> =
        watchHistoryDao.getHistoryForUser(email)

    fun getCompletedCampaignIds(email: String): Flow<List<Long>> =
        watchHistoryDao.getCompletedCampaignIds(email)

    suspend fun hasCompletedAdminCampaign(userEmail: String, adminCampaignId: Long): Boolean {
        return watchHistoryDao.hasCompletedCampaign(userEmail, adminCampaignId) > 0
    }

    suspend fun ensureUserExists(email: String): UserEntity {
        val cleanEmail = email.trim()
        val existing = userDao.getUserSync(cleanEmail)
        val today = dateFormat.format(Date())
        val isAdmin = cleanEmail.equals("amilalasantha940703@gmail.com", ignoreCase = true)
        if (existing == null) {
            val remoteCoins = com.example.data.firebase.FirebaseService.getUserCoins(cleanEmail)
            val startingCoins = if (isAdmin) 9999 else if (remoteCoins != 100 && remoteCoins > 0) remoteCoins else 0
            val newUser = UserEntity(
                email = cleanEmail,
                coins = startingCoins,
                dailyAdsWatched = 0,
                lastAdDate = today,
                totalEarned = startingCoins,
                totalSpent = 0,
                videosWatchedCount = 0,
                channelsSubscribedCount = 0,
                isBanned = false,
                isAdmin = isAdmin
            )
            userDao.insertUser(newUser)
            com.example.data.firebase.FirebaseService.updateUserCoins(newUser.email, newUser.coins)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(newUser)
            return newUser
        } else {
            val updated = if (existing.isAdmin != isAdmin) existing.copy(isAdmin = isAdmin) else existing
            if (updated.lastAdDate != today) {
                userDao.resetDailyAds(cleanEmail, today)
                val resetUser = updated.copy(dailyAdsWatched = 0, lastAdDate = today)
                com.example.data.firebase.FirebaseService.syncUserToFirestore(resetUser)
                return resetUser
            }
            com.example.data.firebase.FirebaseService.updateUserCoins(updated.email, updated.coins)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(updated)
            return updated
        }
    }

    suspend fun seedSampleDataIfEmpty() {
        // PERMANENT PURGE: Remove all sample mock users and sample dummy campaigns for Live Production
        try {
            userDao.deleteSampleUsers()
            campaignDao.deleteSampleCampaigns()
        } catch (_: Exception) {}

        // Ensure strictly only the designated Admin exists
        ensureUserExists("amilalasantha940703@gmail.com")
    }

    suspend fun claimFullEngagementReward(
        userEmail: String,
        campaign: CampaignEntity,
        subCoins: Int,
        likeCoins: Int,
        commentCoins: Int
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted (BAN)"))
        }

        val completedCount = watchHistoryDao.hasCompletedCampaign(userEmail, campaign.id)
        if (completedCount > 0 && !campaign.isAdminPriority) {
            return Result.failure(Exception("You have already completed this campaign!"))
        }

        val totalReward = subCoins + likeCoins + commentCoins
        userDao.addCoins(userEmail, totalReward)
        userDao.addEligibleReloadCoins(userEmail, totalReward)
        campaignDao.incrementProgress(campaign.id)

        val history = WatchHistoryEntity(
            userEmail = userEmail,
            campaignId = campaign.id,
            videoTitle = campaign.videoTitle,
            channelName = campaign.channelName,
            coinsEarned = totalReward,
            actionType = "SUB_LIKE_COMMENT"
        )
        watchHistoryDao.insertHistory(history)

        val updatedUser = userDao.getUserSync(userEmail)
        if (updatedUser != null) {
            com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, updatedUser.coins)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)
        }

        return Result.success(totalReward)
    }

    suspend fun completeVideoTask(
        userEmail: String,
        campaign: CampaignEntity,
        isSubscribeAction: Boolean
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted"))
        }

        // Anti-duplicate check (exempt admin global priority campaigns)
        val completedCount = watchHistoryDao.hasCompletedCampaign(userEmail, campaign.id)
        if (completedCount > 0 && !campaign.isAdminPriority) {
            return Result.failure(Exception("You have already completed this campaign!"))
        }

        val minutes = (campaign.durationSeconds / 60).coerceAtLeast(1)
        val configReward = getEconomyConfig().rewardPerWatchMinute * minutes
        val reward = if (campaign.rewardCoins > 0) campaign.rewardCoins else configReward
        val newCoins = user.coins + reward

        // Update user stats in Room DB
        val updatedUser = user.copy(
            coins = newCoins,
            totalEarned = user.totalEarned + reward,
            videosWatchedCount = user.videosWatchedCount + 1,
            channelsSubscribedCount = if (isSubscribeAction) user.channelsSubscribedCount + 1 else user.channelsSubscribedCount
        )
        userDao.updateUser(updatedUser)

        // Increment campaign progress
        campaignDao.incrementProgress(campaign.id)
        val updatedCampaign = campaignDao.getCampaignById(campaign.id)
        if (updatedCampaign != null && updatedCampaign.currentCount >= updatedCampaign.targetCount) {
            campaignDao.toggleActive(campaign.id, false)
        }

        // Record history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = campaign.id,
                videoTitle = campaign.videoTitle,
                channelName = campaign.channelName,
                actionType = if (isSubscribeAction) "SUBSCRIBE" else "WATCH",
                coinsEarned = reward
            )
        )

        // Sync with Firebase
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, newCoins)
        com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)
        if (isSubscribeAction) {
            val extractedVideoId = com.example.data.youtube.YouTubeApiService.extractVideoId(campaign.videoUrl)
            val uid = com.example.data.firebase.FirebaseService.auth?.currentUser?.uid ?: userEmail
            com.example.data.firebase.FirebaseService.syncVerifiedRewardToFirestore(
                com.example.data.firebase.FirebaseService.VerifiedRewardRecord(
                    userEmail = userEmail,
                    userId = uid,
                    campaignId = campaign.id,
                    channelName = campaign.channelName,
                    videoTitle = campaign.videoTitle,
                    videoId = extractedVideoId,
                    actionType = "SUBSCRIBE",
                    coinsEarned = reward
                )
            )
        }

        return Result.success(reward)
    }

    /**
     * Confirms and rewards user for subscribing to a channel.
     * Safely handles pre-existing subscriptions from older campaigns:
     * - If user is already subscribed, gracefully awards coins for watching the video without penalty or ban.
     */
    suspend fun claimSubscriptionReward(
        userEmail: String,
        campaign: CampaignEntity
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted: You are banned."))
        }

        // Duplicate check on the exact same campaign
        val existingCompleted = watchHistoryDao.hasCompletedCampaign(userEmail, campaign.id)
        if (existingCompleted > 0 && !campaign.isAdminPriority) {
            return Result.failure(Exception("You have already completed this campaign!"))
        }

        // Pre-existing subscription check for older campaigns of this channel:
        // Do NOT ban! Gracefully reward user for the completed video watch time!
        val sixMonthsAgo = System.currentTimeMillis() - (180L * 24 * 60 * 60 * 1000L)
        val pastSubscription = watchHistoryDao.getRecentSubscription(userEmail, campaign.channelName, sixMonthsAgo)
        if (pastSubscription != null && !campaign.isAdminPriority) {
            val minutes = (campaign.durationSeconds / 60).coerceAtLeast(1)
            val watchReward = (getEconomyConfig().costPerWatchMinute * minutes).coerceAtLeast(10)
            val newCoins = user.coins + watchReward

            val updatedUser = user.copy(
                coins = newCoins,
                totalEarned = user.totalEarned + watchReward,
                videosWatchedCount = user.videosWatchedCount + 1
            )
            userDao.updateUser(updatedUser)
            com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, newCoins)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)

            // Record watch history for this campaign
            watchHistoryDao.insertHistory(
                WatchHistoryEntity(
                    userEmail = userEmail,
                    campaignId = campaign.id,
                    videoTitle = campaign.videoTitle,
                    channelName = campaign.channelName,
                    actionType = "WATCH",
                    coinsEarned = watchReward
                )
            )

            campaignDao.incrementProgress(campaign.id)
            return Result.success(watchReward)
        }

        val reward = if (campaign.rewardCoins > 0) campaign.rewardCoins else getEconomyConfig().rewardPerSubscribe
        val newCoins = user.coins + reward

        val updatedUser = user.copy(
            coins = newCoins,
            totalEarned = user.totalEarned + reward,
            channelsSubscribedCount = user.channelsSubscribedCount + 1,
            videosWatchedCount = user.videosWatchedCount + 1
        )
        userDao.updateUser(updatedUser)

        // Increment campaign progress
        campaignDao.incrementProgress(campaign.id)
        val updatedCampaign = campaignDao.getCampaignById(campaign.id)
        if (updatedCampaign != null && updatedCampaign.currentCount >= updatedCampaign.targetCount) {
            campaignDao.toggleActive(campaign.id, false)
        }

        // Record history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = campaign.id,
                videoTitle = campaign.videoTitle,
                channelName = campaign.channelName,
                actionType = "SUBSCRIBE",
                coinsEarned = reward
            )
        )

        // Sync with Firebase
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, newCoins)
        com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)
        val extractedVideoId = com.example.data.youtube.YouTubeApiService.extractVideoId(campaign.videoUrl)
        val uid = com.example.data.firebase.FirebaseService.auth?.currentUser?.uid ?: userEmail
        com.example.data.firebase.FirebaseService.syncVerifiedRewardToFirestore(
            com.example.data.firebase.FirebaseService.VerifiedRewardRecord(
                userEmail = userEmail,
                userId = uid,
                campaignId = campaign.id,
                channelName = campaign.channelName,
                videoTitle = campaign.videoTitle,
                videoId = extractedVideoId,
                actionType = "SUBSCRIBE",
                coinsEarned = reward
            )
        )

        return Result.success(reward)
    }

    /**
     * THREE-STRIKE WARNING & ACCOUNT BAN POLICY:
     * - Edge Case Safe:
     *   1. If campaign is strictly for Views where Sub/Like isn't required -> Never penalize or strike!
     *   2. Only counts ACTUAL removals where the user had previously verified and earned coins for this specific channel/video.
     *   3. 1st & 2nd Violation (warningCount 1 or 2):
     *      Strict warning shown in RED: "නැවත වතාවක් මෙසේ කළහොත් ගිණුම තහනම් (Ban) වේ"
     *   4. 3rd Violation (warningCount 3):
     *      Account banned with reason "Repeated Unsubscribing/Unliking", ban timestamp set for 3 days window.
     */
    suspend fun handleUnsubscribeOrUnlikeViolation(
        userEmail: String,
        targetIdentifier: String,
        isUnsubscribe: Boolean,
        campaignType: String = "SUBSCRIBE"
    ): ViolationResult? {
        // Edge Case 1: If campaign is strictly for Views, Sub/Like isn't required. Never strike or ban!
        if (campaignType.equals("VIEW", ignoreCase = true)) {
            return null
        }

        // Edge Case 2: Only count ACTUAL removals!
        // User must have previously earned coins for subscribing to this channel or liking this video.
        val verifiedCount = if (isUnsubscribe) {
            watchHistoryDao.countVerifiedSubscriptionsForChannel(userEmail, targetIdentifier)
        } else {
            watchHistoryDao.countVerifiedLikesForVideo(userEmail, targetIdentifier)
        }

        // If user never had verified/claimed reward for this channel/video, it is NOT an unsub/unlike violation.
        if (verifiedCount <= 0) {
            return null
        }

        val user = userDao.getUserSync(userEmail) ?: return null
        val currentWarnings = user.warningCount

        val existingUnsubs = user.unsubscribedChannels.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
        if (isUnsubscribe && targetIdentifier.isNotBlank()) {
            existingUnsubs.add(targetIdentifier.trim())
            com.example.data.firebase.FirebaseService.recordUnsubscribedChannelsInFirestore(userEmail, listOf(targetIdentifier.trim()))
        }
        val unsubsList = existingUnsubs.toList()
        val unsubsString = unsubsList.joinToString(",")

        return if (currentWarnings < 2) {
            val nextWarning = currentWarnings + 1
            userDao.updateWarningCount(userEmail, nextWarning)
            userDao.updateUnsubscribedChannels(userEmail, unsubsString)
            val updatedUser = user.copy(warningCount = nextWarning, unsubscribedChannels = unsubsString)
            com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)
            val warningMsg = if (nextWarning == 1) {
                "⚠️ Warning 1/3: You unsubscribed/unliked after earning coins. Please re-subscribe! Next violation will bring you closer to an account ban."
            } else {
                "🚨 Warning 2/3: නැවත වතාවක් මෙසේ කළහොත් ගිණුම තහනම් (Ban) වේ! Final Warning before permanent account ban."
            }
            ViolationResult.Warning(nextWarning, warningMsg, unsubsList)
        } else {
            val reason = "Repeated Unsubscribing/Unliking Fraud (3/3 Strikes)"
            val now = System.currentTimeMillis()
            userDao.banUserWithReason(userEmail, true, reason, now)
            userDao.updateUnsubscribedChannels(userEmail, unsubsString)
            com.example.data.firebase.FirebaseService.updateUserBanned(userEmail, true)
            val bannedUser = user.copy(
                isBanned = true,
                warningCount = 3,
                banReason = reason,
                banTimestamp = now,
                unbanAdsWatched = 0,
                unbanDailyAdsWatched = 0,
                unsubscribedChannels = unsubsString
            )
            com.example.data.firebase.FirebaseService.syncUserToFirestore(bannedUser)
            ViolationResult.Banned(reason, "ඔබ විසින් නාලිකා Sub/Like 3 වරක් ඉවත් කළ බැවින් ඔබගේ ගිණුම තහනම් (Ban) කරන ලදී.", unsubsList)
        }
    }

    /**
     * Robust Fraud-Detection Engine:
     * Differentiates external/pre-existing subscriptions from genuine unsubscribe fraud.
     *
     * 1. If user was NEVER rewarded by our app for this campaign/channel before,
     *    but YouTube indicates they are already subscribed -> Safe external sub.
     *    Allow earning coins (e.g. watch reward) without strike or ban penalties.
     *
     * 2. If user WAS previously rewarded by our app for this campaign/channel,
     *    but subsequent check shows they have now unsubscribed (YouTube API returns empty items)
     *    -> Genuine Unsubscribe Fraud. Increments strikes and applies visual warning / ban.
     */
    suspend fun auditSubscriptionFraud(
        userEmail: String,
        channelName: String,
        isCurrentlySubscribedOnYouTube: Boolean,
        campaignType: String = "SUBSCRIBE"
    ): FraudCheckResult {
        if (campaignType.equals("VIEW", ignoreCase = true)) {
            return FraudCheckResult.LegitimateEngagement
        }

        var pastReward = watchHistoryDao.getVerifiedSubscriptionForChannel(userEmail, channelName)
        if (pastReward == null) {
            val cloudReward = com.example.data.firebase.FirebaseService.getVerifiedRewardForChannel(userEmail, channelName)
            if (cloudReward != null) {
                val restored = WatchHistoryEntity(
                    userEmail = userEmail,
                    campaignId = cloudReward.campaignId,
                    videoTitle = cloudReward.videoTitle,
                    channelName = cloudReward.channelName,
                    actionType = cloudReward.actionType,
                    coinsEarned = cloudReward.coinsEarned,
                    timestamp = cloudReward.timestamp
                )
                watchHistoryDao.insertHistory(restored)
                pastReward = restored
            }
        }

        if (pastReward == null) {
            // User was never rewarded by our app for this channel before.
            // External/prior subscription: allow safe participation without strike/ban penalties!
            return FraudCheckResult.ExternalPriorSubscriptionSafe
        }

        // User was previously verified and rewarded by our app for this channel!
        if (!isCurrentlySubscribedOnYouTube) {
            // Mark reward as fraud in Firestore lifetime collection
            com.example.data.firebase.FirebaseService.markRewardAsFraudInFirestore(userEmail, channelName)

            // Genuine fraud detected: They earned coins from our app, but unsubscribed on YouTube!
            val violation = handleUnsubscribeOrUnlikeViolation(
                userEmail = userEmail,
                targetIdentifier = channelName,
                isUnsubscribe = true,
                campaignType = campaignType
            )

            val (strike, isBanned, msg) = when (violation) {
                is ViolationResult.Warning -> Triple(
                    violation.warningCount,
                    false,
                    violation.message
                )
                is ViolationResult.Banned -> Triple(
                    3,
                    true,
                    violation.message
                )
                null -> Triple(0, false, "Subscription verified")
            }

            return FraudCheckResult.GenuineUnsubscribeFraud(
                channelName = channelName,
                strikeCount = strike,
                isBanned = isBanned,
                message = msg
            )
        }

        return FraudCheckResult.LegitimateEngagement
    }

    suspend fun isUserAlreadySubscribedToChannel(userEmail: String, channelName: String): Boolean {
        return watchHistoryDao.countVerifiedSubscriptionsForChannel(userEmail, channelName) > 0
    }

    suspend fun isUserAlreadyLikedVideo(userEmail: String, videoTitle: String): Boolean {
        return watchHistoryDao.countVerifiedLikesForVideo(userEmail, videoTitle) > 0
    }

    /**
     * Submit an appeal message to Admin requesting account unban.
     */
    suspend fun submitUnbanAppeal(userEmail: String, message: String): Result<Boolean> {
        val cleanMsg = message.trim()
        if (cleanMsg.isBlank()) {
            return Result.failure(Exception("කරුණාකර ඔබගේ පණිවිඩය ඇතුළත් කරන්න."))
        }
        userDao.submitAppeal(userEmail, cleanMsg, "PENDING")
        val user = userDao.getUserSync(userEmail)
        if (user != null) {
            com.example.data.firebase.FirebaseService.syncUserToFirestore(user)
        }
        return Result.success(true)
    }

    /**
     * Unban Option 2: Watch 20 ads within 3 days (max 7 ads per day) to automatically unban the account.
     */
    suspend fun watchUnbanAd(userEmail: String): Result<UnbanProgressResult> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (!user.isBanned) {
            return Result.success(UnbanProgressResult(user.unbanAdsWatched, user.unbanDailyAdsWatched, true, "Account is not banned."))
        }

        val now = System.currentTimeMillis()
        val threeDaysMillis = 3L * 24L * 60L * 60L * 1000L // 72 hours
        val banTime = if (user.banTimestamp > 0) user.banTimestamp else now
        val timeElapsed = now - banTime

        val totalGoal = 20
        val dailyCap = 7

        if (timeElapsed > threeDaysMillis && user.unbanAdsWatched < totalGoal) {
            return Result.failure(Exception("දවස් 3 ක කාල සීමාව අවසන් වී ඇත. කරුණාකර Admin Help මඟින් අභියාචනයක් යොමු කරන්න."))
        }

        val today = dateFormat.format(Date())
        var dailyWatched = user.unbanDailyAdsWatched
        if (user.lastUnbanAdDate != today) {
            dailyWatched = 0
            userDao.resetUnbanDailyAds(userEmail, today)
        }

        if (dailyWatched >= dailyCap && user.unbanAdsWatched < totalGoal) {
            return Result.failure(Exception("අද දිනට නියමිත දැන්වීම් $dailyCap සම්පූර්ණයි ($dailyWatched/$dailyCap). හෙට නැවත දැන්වීම් නරඹන්න (දින 3 කින් දැන්වීම් 20 සම්පූර්ණ කරන්න)."))
        }

        val newTotalWatched = user.unbanAdsWatched + 1
        val newDailyWatched = dailyWatched + 1
        userDao.recordUnbanAdWatched(userEmail, today)

        return if (newTotalWatched >= totalGoal) {
            // Reached 20 ads over 3 days -> AUTOMATIC UNBAN!
            userDao.unbanUser(userEmail)
            com.example.data.firebase.FirebaseService.updateUserBanned(userEmail, false)
            val unbannedUser = userDao.getUserSync(userEmail)
            if (unbannedUser != null) {
                com.example.data.firebase.FirebaseService.syncUserToFirestore(unbannedUser)
            }
            Result.success(
                UnbanProgressResult(
                    totalWatched = newTotalWatched,
                    todayWatched = newDailyWatched,
                    isUnbanned = true,
                    message = "සුබ පැතුම්! ඔබ දැන්වීම් 20 සාර්ථකව නරඹා ඇත. ඔබගේ ගිණුම ස්වයංක්‍රීයව සක්‍රීය (Unban) කරන ලදී!"
                )
            )
        } else {
            val remainingTotal = totalGoal - newTotalWatched
            val remainingDaily = (dailyCap - newDailyWatched).coerceAtLeast(0)
            Result.success(
                UnbanProgressResult(
                    totalWatched = newTotalWatched,
                    todayWatched = newDailyWatched,
                    isUnbanned = false,
                    message = "දැන්වීම නැරඹීම සාර්ථකයි! අද දිනට: $newDailyWatched/$dailyCap | මුළු ඉලක්කය: $newTotalWatched/$totalGoal (ඉතිරි: $remainingTotal)"
                )
            )
        }
    }

    /**
     * Unban user directly by Admin approval.
     */
    suspend fun unbanUserDirectly(userEmail: String): Result<Boolean> {
        val cleanEmail = userEmail.trim().lowercase()
        userDao.unbanUser(cleanEmail)
        com.example.data.firebase.FirebaseService.adminUnbanUserInFirestore(cleanEmail)
        com.example.data.firebase.FirebaseService.updateUserBanned(cleanEmail, false)
        val unbanned = userDao.getUserSync(cleanEmail)
        if (unbanned != null) {
            com.example.data.firebase.FirebaseService.syncUserToFirestore(unbanned)
        }
        return Result.success(true)
    }

    suspend fun adminUnbanUser(userEmail: String): Boolean {
        return unbanUserDirectly(userEmail).isSuccess
    }

    /**
     * Resolves all active fraud violations once the user has fixed all sub and like requirements.
     * Clears strikes and violations from Room & Firestore so user can resume normal dashboard workflow.
     */
    suspend fun resolveAllViolations(userEmail: String): Result<Boolean> {
        val cleanEmail = userEmail.trim().lowercase()
        userDao.resetStrikesAndUnsubs(cleanEmail)
        com.example.data.firebase.FirebaseService.clearActiveViolationsInFirestore(cleanEmail)
        com.example.data.firebase.FirebaseService.clearUnsubscribedChannelsInFirestore(cleanEmail)
        val user = userDao.getUserSync(cleanEmail)
        if (user != null) {
            com.example.data.firebase.FirebaseService.syncUserToFirestore(user)
        }
        return Result.success(true)
    }

    suspend fun inspectUserInFirestore(email: String): Pair<com.example.data.firebase.FirebaseService.FirestoreUserProfile?, List<com.example.data.firebase.FirebaseService.VerifiedRewardRecord>> {
        return com.example.data.firebase.FirebaseService.inspectUserInFirestore(email)
    }

    suspend fun adminBanUser(email: String, reason: String): Boolean {
        val cleanEmail = email.trim().lowercase()
        userDao.banUserWithReason(cleanEmail, true, reason, System.currentTimeMillis())
        return com.example.data.firebase.FirebaseService.adminBanUserInFirestore(cleanEmail, reason)
    }

    suspend fun adminSetCoins(email: String, coins: Int): Boolean {
        val cleanEmail = email.trim().lowercase()
        userDao.setCoins(cleanEmail, coins)
        return com.example.data.firebase.FirebaseService.adminSetCoinsInFirestore(cleanEmail, coins)
    }

    suspend fun adminResetStrikes(email: String): Boolean {
        val cleanEmail = email.trim().lowercase()
        userDao.resetStrikesAndUnsubs(cleanEmail)
        return com.example.data.firebase.FirebaseService.adminResetStrikesInFirestore(cleanEmail)
    }

    suspend fun adminDeleteUser(email: String): Boolean {
        val cleanEmail = email.trim().lowercase()
        userDao.deleteUserByEmail(cleanEmail)
        return com.example.data.firebase.FirebaseService.adminDeleteUserInFirestore(cleanEmail)
    }

    /**
     * Confirms and rewards user for liking a video on YouTube.
     * Updates coins based on Admin Economy Configuration.
     */
    suspend fun claimLikeReward(
        userEmail: String,
        campaign: CampaignEntity
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted: You are banned."))
        }

        val existingCompleted = watchHistoryDao.hasCompletedCampaign(userEmail, campaign.id)
        if (existingCompleted > 0 && !campaign.isAdminPriority) {
            return Result.failure(Exception("You have already liked '${campaign.videoTitle}' and claimed coins!"))
        }

        val reward = getEconomyConfig().rewardPerLike
        val newCoins = user.coins + reward

        val updatedUser = user.copy(
            coins = newCoins,
            totalEarned = user.totalEarned + reward
        )
        userDao.updateUser(updatedUser)

        // Increment campaign progress
        campaignDao.incrementProgress(campaign.id)
        val updatedCampaign = campaignDao.getCampaignById(campaign.id)
        if (updatedCampaign != null && updatedCampaign.currentCount >= updatedCampaign.targetCount) {
            campaignDao.toggleActive(campaign.id, false)
        }

        // Record history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = campaign.id,
                videoTitle = campaign.videoTitle,
                channelName = campaign.channelName,
                actionType = "LIKE",
                coinsEarned = reward
            )
        )

        // Sync with Firebase
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, newCoins)
        com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)

        return Result.success(reward)
    }

    /**
     * Confirms and rewards user for commenting on a video on YouTube.
     */
    suspend fun claimCommentReward(
        userEmail: String,
        campaign: CampaignEntity,
        commentText: String
    ): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted: You are banned."))
        }

        val reward = 20
        val newCoins = user.coins + reward

        val updatedUser = user.copy(
            coins = newCoins,
            totalEarned = user.totalEarned + reward
        )
        userDao.updateUser(updatedUser)

        // Increment campaign progress
        campaignDao.incrementProgress(campaign.id)

        // Record history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = campaign.id,
                videoTitle = campaign.videoTitle,
                channelName = campaign.channelName,
                actionType = "COMMENT: $commentText",
                coinsEarned = reward
            )
        )

        // Sync with Firebase
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, newCoins)
        com.example.data.firebase.FirebaseService.syncUserToFirestore(updatedUser)

        return Result.success(reward)
    }

    suspend fun watchAdForBonus(userEmail: String): Result<Int> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        val config = getEconomyConfig()
        val maxDaily = config.maxDailyAds
        val today = dateFormat.format(Date())

        var currentWatched = user.dailyAdsWatched
        if (user.lastAdDate != today) {
            currentWatched = 0
            userDao.resetDailyAds(userEmail, today)
        }

        if (currentWatched >= maxDaily) {
            return Result.failure(Exception("Daily ad limit reached ($maxDaily ads/day)"))
        }

        val bonusReward = config.rewardPerAd
        userDao.recordAdWatched(userEmail, bonusReward)
        com.example.data.firebase.FirebaseService.updateUserCoins(userEmail, user.coins + bonusReward)

        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = userEmail,
                campaignId = -1,
                videoTitle = "Rewarded Partner Ad",
                channelName = "SubExchange Sponsor Network",
                actionType = "AD_REWARD",
                coinsEarned = bonusReward
            )
        )

        return Result.success(bonusReward)
    }

    suspend fun createCampaign(
        creatorEmail: String,
        videoUrl: String,
        videoTitle: String,
        channelName: String,
        thumbnailUrl: String,
        campaignType: String,
        targetCount: Int,
        durationSeconds: Int,
        costPerAction: Int,
        isAdminPriority: Boolean = false,
        isGlobal: Boolean = false
    ): Result<Long> {
        val user = userDao.getUserSync(creatorEmail) ?: return Result.failure(Exception("User not found"))
        val isAdmin = creatorEmail.equals("amilalasantha940703@gmail.com", ignoreCase = true)
        val effectiveAdminPriority = isAdminPriority || isAdmin
        val effectiveIsGlobal = isGlobal || isAdmin
        val totalCost = if (isAdmin) 0 else targetCount * costPerAction

        if (!isAdmin && user.coins < totalCost) {
            return Result.failure(Exception("Insufficient coins! Required: $totalCost, Available: ${user.coins}"))
        }

        if (!isAdmin && totalCost > 0) {
            userDao.deductCoins(creatorEmail, totalCost)
            val remainingCoins = user.coins - totalCost
            com.example.data.firebase.FirebaseService.updateUserCoins(creatorEmail, remainingCoins)
        }

        val rewardPerAction = when (campaignType) {
            "SUBSCRIBE" -> if (effectiveAdminPriority) 100 else 50
            "VIEW" -> if (durationSeconds >= 300) 50 else (durationSeconds / 6)
            else -> 25
        }

        val campaign = CampaignEntity(
            creatorEmail = creatorEmail,
            videoUrl = videoUrl,
            videoTitle = videoTitle,
            channelName = channelName,
            thumbnailUrl = thumbnailUrl.ifBlank {
                "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80"
            },
            campaignType = campaignType,
            targetCount = targetCount,
            currentCount = 0,
            durationSeconds = durationSeconds,
            rewardCoins = rewardPerAction,
            totalCostCoins = totalCost,
            isAdminPriority = effectiveAdminPriority,
            isGlobal = effectiveIsGlobal,
            isActive = true
        )

        val id = campaignDao.insertCampaign(campaign)
        com.example.data.firebase.FirebaseService.syncCampaignToFirestore(campaign.copy(id = id))
        return Result.success(id)
    }

    suspend fun toggleCampaignActive(id: Long, isActive: Boolean) {
        campaignDao.toggleActive(id, isActive)
    }

    suspend fun deleteCampaign(campaign: CampaignEntity) {
        campaignDao.deleteCampaign(campaign)
    }

    suspend fun setUserBanned(email: String, banned: Boolean) {
        userDao.setBannedStatus(email, banned)
        com.example.data.firebase.FirebaseService.updateUserBanned(email, banned)
    }

    suspend fun grantAdminBonusCoins(email: String, amount: Int) {
        userDao.addCoins(email, amount)
        userDao.getUserSync(email)?.let {
            com.example.data.firebase.FirebaseService.updateUserCoins(email, it.coins)
        }
    }

    suspend fun setUserCoins(email: String, newBalance: Int) {
        val safeBalance = newBalance.coerceAtLeast(0)
        userDao.setCoins(email, safeBalance)
        com.example.data.firebase.FirebaseService.updateUserCoins(email, safeBalance)
    }

    suspend fun modifyUserCoins(email: String, delta: Int) {
        val user = userDao.getUserSync(email) ?: return
        val updated = (user.coins + delta).coerceAtLeast(0)
        setUserCoins(email, updated)
    }

    suspend fun setCampaignAdminPriority(id: Long, isPriority: Boolean) {
        campaignDao.setAdminPriority(id, isPriority)
    }

    suspend fun setCampaignGlobal(id: Long, isGlobal: Boolean) {
        campaignDao.setGlobal(id, isGlobal)
    }

    suspend fun deleteUser(email: String) {
        userDao.deleteUserByEmail(email)
        campaignDao.deleteCampaignsByCreator(email)
        com.example.data.firebase.FirebaseService.deleteUser(email)
    }

    // --- Mobile Reload System ---
    fun getAllReloadRequests(): Flow<List<com.example.data.local.entity.ReloadRequestEntity>> =
        reloadRequestDao?.getAllReloadRequests() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    fun getReloadRequestsForUser(email: String): Flow<List<com.example.data.local.entity.ReloadRequestEntity>> =
        reloadRequestDao?.getReloadRequestsForUser(email) ?: kotlinx.coroutines.flow.flowOf(emptyList())

    fun getPendingReloadCount(): Flow<Int> =
        reloadRequestDao?.getPendingCount() ?: kotlinx.coroutines.flow.flowOf(0)

    suspend fun submitReloadRequest(
        userEmail: String,
        phoneNumber: String,
        operator: String,
        connectionType: String,
        amountLkr: Int
    ): Result<Long> {
        val user = userDao.getUserSync(userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.isBanned) {
            return Result.failure(Exception("Account is restricted: You are banned."))
        }
        val config = getEconomyConfig()
        if (!config.isReloadServiceActive) {
            return Result.failure(Exception("Mobile reload service is temporarily disabled by admin."))
        }
        val coinsRequired = amountLkr * config.coinsPerLkrReload

        if (user.coins < coinsRequired) {
            return Result.failure(Exception("Insufficient total coins! Required: $coinsRequired, Available: ${user.coins}"))
        }

        // Admin is exempt from video task restriction; regular users must have completed tasks
        val isAdmin = user.email.equals("amilalasantha940703@gmail.com", ignoreCase = true)
        val eligibleCoins = if (isAdmin || user.eligibleReloadCoins > 0) {
            user.eligibleReloadCoins.coerceAtLeast(user.coins)
        } else {
            user.eligibleReloadCoins
        }

        if (!isAdmin && eligibleCoins < coinsRequired) {
            return Result.failure(Exception("Only coins earned by completing video tasks (Watch + Subscribe + Like + Comment) are eligible for mobile reload! Eligible: $eligibleCoins, Required: $coinsRequired"))
        }

        val request = com.example.data.local.entity.ReloadRequestEntity(
            userEmail = userEmail,
            phoneNumber = phoneNumber.trim(),
            operator = operator,
            connectionType = connectionType,
            amountLkr = amountLkr,
            coinsRequired = coinsRequired,
            status = "PENDING",
            timestamp = System.currentTimeMillis()
        )
        val id = reloadRequestDao?.insertReloadRequest(request) ?: 0L

        // NOTE: Coins are NOT deducted here! They are ONLY deducted when admin approves!
        return Result.success(id)
    }

    suspend fun approveReloadRequest(id: Long, adminNote: String = "Approved by Admin"): Result<Unit> {
        val request = reloadRequestDao?.getReloadRequestById(id) ?: return Result.failure(Exception("Request not found"))
        if (request.status == "APPROVED") {
            return Result.failure(Exception("Reload request is already approved"))
        }

        val user = userDao.getUserSync(request.userEmail) ?: return Result.failure(Exception("User not found"))
        if (user.coins < request.coinsRequired) {
            return Result.failure(Exception("User only has ${user.coins} coins, but reload requires ${request.coinsRequired} coins!"))
        }

        // CRITICAL REQUIREMENT: Coins are deducted ONLY upon admin approval!
        userDao.deductCoins(request.userEmail, request.coinsRequired)
        userDao.deductEligibleReloadCoins(request.userEmail, request.coinsRequired)

        val updatedUser = userDao.getUserSync(request.userEmail)
        if (updatedUser != null) {
            com.example.data.firebase.FirebaseService.updateUserCoins(request.userEmail, updatedUser.coins)
        }

        reloadRequestDao?.updateStatus(id, "APPROVED", System.currentTimeMillis(), adminNote)

        // Record successful reload in history
        watchHistoryDao.insertHistory(
            WatchHistoryEntity(
                userEmail = request.userEmail,
                campaignId = -2L,
                videoTitle = "Mobile Reload - Rs. ${request.amountLkr} (${request.operator})",
                channelName = "${request.phoneNumber} [${request.connectionType}]",
                actionType = "RELOAD_SUCCESS",
                coinsEarned = -request.coinsRequired
            )
        )

        return Result.success(Unit)
    }

    suspend fun rejectReloadRequest(id: Long, reason: String = "Rejected by Admin"): Result<Unit> {
        val request = reloadRequestDao?.getReloadRequestById(id) ?: return Result.failure(Exception("Request not found"))
        if (request.status == "APPROVED") {
            return Result.failure(Exception("Cannot reject an already approved reload!"))
        }
        reloadRequestDao?.updateStatus(id, "REJECTED", System.currentTimeMillis(), reason)
        return Result.success(Unit)
    }

    fun toggleReloadService(isActive: Boolean) {
        val current = getEconomyConfig()
        saveEconomyConfig(current.copy(isReloadServiceActive = isActive))
    }
}

sealed class ViolationResult {
    data class Warning(val warningCount: Int, val message: String, val unsubscribedChannels: List<String> = emptyList()) : ViolationResult()
    data class Banned(val reason: String, val message: String, val unsubscribedChannels: List<String> = emptyList()) : ViolationResult()
}

sealed class FraudCheckResult {
    object LegitimateEngagement : FraudCheckResult()
    object ExternalPriorSubscriptionSafe : FraudCheckResult()
    data class GenuineUnsubscribeFraud(
        val channelName: String,
        val strikeCount: Int,
        val isBanned: Boolean,
        val message: String
    ) : FraudCheckResult()
}

data class UnbanProgressResult(
    val totalWatched: Int,
    val todayWatched: Int,
    val isUnbanned: Boolean,
    val message: String
)

