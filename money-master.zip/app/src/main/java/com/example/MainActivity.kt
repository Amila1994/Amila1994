package com.example

import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AdRewardModal
import com.example.ui.components.AdminActiveCampaignsDialog
import com.example.ui.components.AdminEconomySettingsDialog
import com.example.ui.components.AdminManageUsersDialog
import com.example.ui.components.AdminReloadManagementDialog
import com.example.ui.components.AdminUpdateSettingsDialog
import com.example.ui.components.AdminUserInspectionDialog
import com.example.ui.components.AppUpdateDialog
import com.example.ui.components.CelebrationDialog
import com.example.ui.components.CoinBadge
import com.example.ui.components.CreateCampaignDialog
import com.example.ui.components.NavDrawerMenuDialog
import com.example.ui.components.UserReloadDialog
import com.example.ui.components.ViolationWarningDialog
import com.example.ui.screens.AccountBannedScreen
import com.example.ui.screens.CampaignScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MultiItemViolationBlockingScreen
import com.example.ui.screens.OtpVerificationScreen
import com.example.ui.screens.ProfileAndAdminScreen
import com.example.ui.screens.SupportChatScreen
import com.example.ui.screens.WatchAndEarnScreen
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SubExchangeTheme
import com.example.ui.viewmodel.SubExchangeViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.data.firebase.FirebaseService.initialize(applicationContext)
        enableEdgeToEdge()
        setContent {
            SubExchangeTheme {
                SubExchangeAppRoot()
            }
        }
    }
}

@Composable
fun SubExchangeAppRoot(
    viewModel: SubExchangeViewModel = viewModel()
) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val isAuthenticating by viewModel.isAuthenticating.collectAsState()
    val pendingOtpEmail by viewModel.pendingOtpEmail.collectAsState()
    val latestDispatchedOtp by viewModel.latestDispatchedOtp.collectAsState()
    val isVerifyingOtp by viewModel.isVerifyingOtp.collectAsState()
    val otpErrorMessage by viewModel.otpErrorMessage.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val violationWarning by viewModel.violationWarning.collectAsState()
    val unsubscribedChannelsList by viewModel.unsubscribedChannelsList.collectAsState()
    val isWarningDismissedByUser by viewModel.isWarningDismissedByUser.collectAsState()
    val banReason by viewModel.banReason.collectAsState()
    val isWatchingUnbanAd by viewModel.isWatchingUnbanAd.collectAsState()
    val unbanAdCountdown by viewModel.unbanAdCountdown.collectAsState()
    val unbanStatusMessage by viewModel.unbanStatusMessage.collectAsState()
    val activeViolations by viewModel.activeViolations.collectAsState()
    val isVerifyingViolations by viewModel.isVerifyingViolations.collectAsState()
    val violationVerificationMessage by viewModel.violationVerificationMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    var initialDashboardTab by rememberSaveable { mutableIntStateOf(1) }
    val context = LocalContext.current

    // Request notification permission on Android 13+ (API 33+) for app update & announcements alerts
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { /* Handled gracefully */ }
        LaunchedEffect(Unit) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) {
                permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(
                targetState = when {
                    currentUser?.isBanned == true -> 3
                    isLoggedIn && activeViolations.isNotEmpty() -> 4
                    isLoggedIn -> 2
                    pendingOtpEmail != null -> 1
                    else -> 0
                },
                animationSpec = tween(durationMillis = 350),
                label = "AuthNavCrossfade"
            ) { navState ->
                when (navState) {
                    0 -> LoginScreen(
                        isAuthenticating = isAuthenticating,
                        bannedNotice = if (banReason.isNotBlank()) banReason else if (currentUser?.isBanned == true) currentUser?.banReason else null,
                        onLoginWithGoogle = { ctx, email ->
                            viewModel.startGoogleSignInAndSendOtp(ctx, email)
                        },
                        onDirectSignIn = { ctx, email ->
                            viewModel.loginWithGoogle(ctx, email) { isAdmin ->
                                initialDashboardTab = if (isAdmin) 2 else 1
                                viewModel.selectDashboardTab(if (isAdmin) 2 else 1)
                            }
                        }
                    )
                    1 -> OtpVerificationScreen(
                        email = pendingOtpEmail ?: "",
                        latestDispatchedOtp = latestDispatchedOtp,
                        isVerifying = isVerifyingOtp,
                        errorMessage = otpErrorMessage,
                        onVerifyOtp = { enteredOtp ->
                            viewModel.verifyOtpAndCompleteLogin(enteredOtp) { isAdmin ->
                                initialDashboardTab = if (isAdmin) 2 else 1
                                viewModel.selectDashboardTab(if (isAdmin) 2 else 1)
                            }
                        },
                        onResendOtp = { viewModel.resendVerificationOtp() },
                        onCancel = { viewModel.cancelOtpVerification() }
                    )
                    2 -> MainDashboard(
                        viewModel = viewModel,
                        initialTab = initialDashboardTab
                    )
                    3 -> {
                        currentUser?.let { user ->
                            AccountBannedScreen(
                                user = user,
                                isWatchingAd = isWatchingUnbanAd,
                                adCountdown = unbanAdCountdown,
                                statusMessage = unbanStatusMessage,
                                onWatchAd = { viewModel.startWatchUnbanAd() },
                                onSubmitAppeal = { msg -> viewModel.submitUnbanAppeal(msg) },
                                onLogout = { viewModel.logout() },
                                onClearStatusMessage = { viewModel.clearUnbanStatusMessage() }
                            )
                        }
                    }
                    4 -> {
                        MultiItemViolationBlockingScreen(
                            userEmail = currentUser?.email ?: "",
                            strikeCount = (currentUser?.warningCount ?: 1).coerceAtLeast(1),
                            violations = activeViolations,
                            isVerifying = isVerifyingViolations,
                            verificationStatusMessage = violationVerificationMessage,
                            onOpenYouTubeItem = { item -> viewModel.openViolationOnYouTube(context, item) },
                            onToggleSubResolved = { id -> viewModel.toggleViolationSubResolved(id) },
                            onToggleLikeResolved = { id -> viewModel.toggleViolationLikeResolved(id) },
                            onVerifyAndResolveAll = { viewModel.verifyAndResolveAllViolations(context) },
                            onLogout = { viewModel.logout() }
                        )
                    }
                    else -> {}
                }
            }

            val activeUnsubs = remember(unsubscribedChannelsList, currentUser?.unsubscribedChannels) {
                if (unsubscribedChannelsList.isNotEmpty()) {
                    unsubscribedChannelsList
                } else {
                    currentUser?.unsubscribedChannels?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() } ?: emptyList()
                }
            }

            if (!isWarningDismissedByUser && activeViolations.isEmpty() && (violationWarning != null || (activeUnsubs.isNotEmpty() && currentUser?.isBanned == false))) {
                ViolationWarningDialog(
                    warningMessage = violationWarning ?: "ඔබ කාසි උපයාගත් YouTube නාලිකාවලින් ඉවත් වී ඇත (Unsubscribed detected). කරුණාකර නැවත Subscribe කරන්න!",
                    strikeCount = (currentUser?.warningCount ?: 1).coerceAtLeast(1),
                    unsubscribedChannels = activeUnsubs,
                    onResubscribeChannel = { channelName ->
                        viewModel.openChannelOnYouTube(context, channelName)
                        viewModel.resubscribeToChannel(channelName)
                    },
                    onDismiss = { viewModel.dismissViolationWarning() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboard(
    viewModel: SubExchangeViewModel,
    initialTab: Int = 1,
    modifier: Modifier = Modifier
) {
    val currentUserEmail by viewModel.currentUserEmail.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val activeCampaigns by viewModel.activeCampaigns.collectAsState()
    val userCampaigns by viewModel.userCampaigns.collectAsState()
    val allCampaigns by viewModel.allCampaigns.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val watchHistory by viewModel.watchHistory.collectAsState()

    val selectedCampaign by viewModel.selectedCampaign.collectAsState()
    val isWatching by viewModel.isWatching.collectAsState()
    val remainingSeconds by viewModel.remainingSeconds.collectAsState()
    val totalSeconds by viewModel.totalWatchSeconds.collectAsState()
    val isTimerFinished by viewModel.isTimerFinished.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()
    val isLiked by viewModel.isLiked.collectAsState()
    val fastMode by viewModel.fastMode.collectAsState()

    val isWatchingAd by viewModel.isWatchingAd.collectAsState()
    val adCountdown by viewModel.adCountdown.collectAsState()

    val rewardCelebration by viewModel.rewardCelebration.collectAsState()

    val isVerifyingYouTube by viewModel.isVerifyingYouTube.collectAsState()
    val youTubeVerificationStatus by viewModel.youTubeVerificationStatus.collectAsState()
    val showNotEnoughWatchTimeDialog by viewModel.showNotEnoughWatchTimeDialog.collectAsState()
    val showNotSubscribedDialog by viewModel.showNotSubscribedDialog.collectAsState()
    val isFullWatchMode by viewModel.isFullWatchMode.collectAsState()
    val isVideoPlaying by viewModel.isVideoPlaying.collectAsState()
    val economyConfig by viewModel.economyConfig.collectAsState()
    val context = LocalContext.current

    val currentDashboardTab by viewModel.currentDashboardTab.collectAsState()
    var selectedTab by rememberSaveable { mutableIntStateOf(initialTab) }

    LaunchedEffect(currentDashboardTab) {
        selectedTab = currentDashboardTab
    }

    var showCreateCampaignDialog by remember { mutableStateOf(false) }
    var showManageUsersDialog by remember { mutableStateOf(false) }
    var showAllCampaignsDialog by remember { mutableStateOf(false) }
    var showEconomySettingsDialog by remember { mutableStateOf(false) }
    var showUpdateSettingsDialog by remember { mutableStateOf(false) }
    var showReloadDialog by remember { mutableStateOf(false) }
    var showAdminReloadManagementDialog by remember { mutableStateOf(false) }
    var showUserInspectionDialog by remember { mutableStateOf(false) }
    var inspectionTargetEmail by remember { mutableStateOf("") }
    var showNavDrawerMenu by remember { mutableStateOf(false) }
    var showSupportChat by remember { mutableStateOf(false) }

    val supportMessages by viewModel.supportMessages.collectAsState()
    val supportThreads by viewModel.supportThreads.collectAsState()
    val activeChatUserEmail by viewModel.activeChatUserEmail.collectAsState()
    val isSendingChatMessage by viewModel.isSendingChatMessage.collectAsState()
    val isUploadingChatImage by viewModel.isUploadingChatImage.collectAsState()
    val chatUploadProgress by viewModel.chatUploadProgress.collectAsState()

    val appUpdateConfig by viewModel.appUpdateConfig.collectAsState()
    val isUpdateRequired by viewModel.isUpdateRequired.collectAsState()
    var showUserUpdateDialog by rememberSaveable { mutableStateOf(false) }
    var lastDismissedUpdateTimestamp by rememberSaveable { mutableLongStateOf(0L) }
    val userReloadRequests by viewModel.userReloadRequests.collectAsState()
    val allReloadRequests by viewModel.allReloadRequests.collectAsState()
    val pendingReloadCount by viewModel.pendingReloadCount.collectAsState()
    val inspectedUser by viewModel.inspectedUser.collectAsState()
    val inspectedUserHistory by viewModel.inspectedUserHistory.collectAsState()
    val isSearchingInspectedUser by viewModel.isSearchingInspectedUser.collectAsState()
    val inspectUserSearchError by viewModel.inspectUserSearchError.collectAsState()
    val oauthAccessToken by viewModel.oauthAccessToken.collectAsState()

    val userCoins = currentUser?.coins ?: 0
    val dailyAdCount = currentUser?.dailyAdsWatched ?: 0
    val maxDailyAds = 15
    val isPrimaryAdmin = currentUserEmail.equals(com.example.data.firebase.FirebaseService.designatedAdminEmail, ignoreCase = true)
    val isAdmin = isPrimaryAdmin || currentUser?.isAdmin == true

    LaunchedEffect(appUpdateConfig.lastAnnouncedTimestamp, isUpdateRequired, isPrimaryAdmin, currentUserEmail) {
        if (!isPrimaryAdmin) {
            if (isUpdateRequired) {
                showUserUpdateDialog = true
            } else if (appUpdateConfig.lastAnnouncedTimestamp > 0L && appUpdateConfig.lastAnnouncedTimestamp > lastDismissedUpdateTimestamp) {
                showUserUpdateDialog = true
            } else if (appUpdateConfig.requiredVersionCode > viewModel.currentAppVersionCode && lastDismissedUpdateTimestamp == 0L) {
                showUserUpdateDialog = true
            }
        }
    }

    val isWatchingFullscreen = isFullWatchMode && selectedTab == 1

    // Handle back button: return to Subscribe tab (1) before exiting
    BackHandler(enabled = selectedTab != 1 && !isFullWatchMode) {
        selectedTab = 1
    }

    // Auto-select first campaign if none selected
    LaunchedEffect(activeCampaigns) {
        if (selectedCampaign == null && activeCampaigns.isNotEmpty()) {
            viewModel.selectCampaign(activeCampaigns.first())
        }
    }

    Scaffold(
        topBar = {
            if (!isWatchingFullscreen) {
                CenterAlignedTopAppBar(
                    navigationIcon = {
                        IconButton(
                            onClick = { showNavDrawerMenu = true },
                            modifier = Modifier.testTag("menu_drawer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Menu",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                title = {
                    Text(
                        text = "SubExchange",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontStyle = FontStyle.Italic,
                            fontSize = 22.sp
                        ),
                        color = RedPrimary
                    )
                },
                actions = {
                    CoinBadge(
                        coins = userCoins,
                        modifier = Modifier.padding(end = 12.dp),
                        onClick = {
                            if (dailyAdCount < maxDailyAds) {
                                viewModel.watchRewardedAd()
                            }
                        }
                    )
                },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.testTag("main_app_bar")
                )
            }
        },
        bottomBar = {
            if (!isWatchingFullscreen) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    // Tab 0: Campaign (USub tab 1)
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { 
                            selectedTab = 0
                            viewModel.selectDashboardTab(0)
                        },
                        icon = { Icon(Icons.Default.Campaign, contentDescription = "Campaign") },
                        label = {
                            Text(
                                text = "Campaign",
                                fontStyle = if (selectedTab == 0) FontStyle.Italic else FontStyle.Normal,
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RedPrimary,
                            selectedTextColor = RedPrimary,
                            indicatorColor = RedPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("tab_campaigns")
                    )
                    // Tab 1: Subscribe (USub tab 2 - Center)
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { 
                            selectedTab = 1
                            viewModel.selectDashboardTab(1)
                        },
                        icon = { Icon(Icons.Default.Subscriptions, contentDescription = "Subscribe") },
                        label = {
                            Text(
                                text = "Subscribe",
                                fontStyle = if (selectedTab == 1) FontStyle.Italic else FontStyle.Normal,
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RedPrimary,
                            selectedTextColor = RedPrimary,
                            indicatorColor = RedPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("tab_subscribe")
                    )
                    // Tab 2: Profile & Admin
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { 
                            selectedTab = 2
                            viewModel.selectDashboardTab(2)
                        },
                        icon = { 
                            Icon(
                                imageVector = if (isAdmin) Icons.Default.AdminPanelSettings else Icons.Default.Person, 
                                contentDescription = if (isAdmin) "Admin Panel" else "Profile"
                            ) 
                        },
                        label = {
                            Text(
                                text = if (isAdmin) "Admin Panel" else "Profile",
                                fontStyle = if (selectedTab == 2) FontStyle.Italic else FontStyle.Normal,
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RedPrimary,
                            selectedTextColor = RedPrimary,
                            indicatorColor = RedPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("tab_earn_coin")
                    )
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (isWatchingFullscreen) androidx.compose.foundation.layout.PaddingValues(0.dp) else innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (currentUser?.isBanned == true) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFB71C1C)),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("banned_user_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "🚫 ACCOUNT PERMANENTLY BANNED",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Anti-Cheat: Unsubscribing or unliking after claiming coins violates SubExchange policies. Your account is permanently suspended.",
                                color = Color(0xFFFFCDD2),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (selectedTab) {
                0 -> CampaignScreen(
                    userCoins = userCoins,
                    campaigns = userCampaigns,
                    onOpenCreateCampaign = { showCreateCampaignDialog = true },
                    onToggleActive = { id, active -> viewModel.toggleCampaignStatus(id, active) },
                    onDeleteCampaign = { viewModel.deleteCampaign(it) }
                )
                1 -> WatchAndEarnScreen(
                    currentCampaign = selectedCampaign,
                    activeCampaigns = activeCampaigns,
                    isWatching = isWatching,
                    remainingSeconds = remainingSeconds,
                    totalSeconds = totalSeconds,
                    isTimerFinished = isTimerFinished,
                    isVideoPlaying = isVideoPlaying,
                    isSubscribed = isSubscribed,
                    isLiked = isLiked,
                    fastMode = fastMode,
                    dailyAdsWatched = dailyAdCount,
                    maxDailyAds = maxDailyAds,
                    isVerifyingYouTube = isVerifyingYouTube,
                    youTubeVerificationStatus = youTubeVerificationStatus,
                    showNotEnoughWatchTimeDialog = showNotEnoughWatchTimeDialog,
                    showNotSubscribedDialog = showNotSubscribedDialog,
                    isFullWatchMode = isFullWatchMode,
                    onDismissNotEnoughWatchTimeDialog = { viewModel.dismissNotEnoughWatchTimeDialog() },
                    onDismissNotSubscribedDialog = { viewModel.dismissNotSubscribedDialog() },
                    onStartWatching = { viewModel.startWatching() },
                    onStopWatching = { viewModel.stopWatching() },
                    onOpenFullWatch = { viewModel.openFullWatchMode() },
                    onExitFullWatch = { viewModel.exitFullWatchMode() },
                    onVideoStateChanged = { playing ->
                        if (playing) viewModel.onVideoPlaying() else viewModel.onVideoPaused()
                    },
                    onSubscribeDetected = { viewModel.recordUserSubscribedOnYouTube() },
                    onLikeDetected = { viewModel.recordUserLikedOnYouTube() },
                    onCommentDetected = { viewModel.recordUserCommentedOnYouTube() },
                    onSeekAttempted = { viewModel.onSeekAttempted() },
                    onUnsubscribeDetected = { selectedCampaign?.channelName?.let { viewModel.onUserAttemptedUnsubscribe(it) } },
                    onToggleSubscribe = { viewModel.toggleSubscribe(context) },
                    onWatchOnYouTube = { viewModel.watchVideoOnYouTube(context) },
                    onToggleLike = { viewModel.toggleLike() },
                    onToggleFastMode = { viewModel.toggleFastMode() },
                    onSelectCampaign = { viewModel.selectCampaign(it) },
                    onWatchAd = { viewModel.watchRewardedAd() },
                    onSeeOther = { viewModel.seeNextCampaign() },
                    onPrevious = { viewModel.seePreviousCampaign() },
                    onNext = { viewModel.seeNextCampaign() },
                    onVerifyAndRewardUser = { viewModel.verifyAndRewardUser(context) },
                    onLikeVideo = { viewModel.likeVideo(context) },
                    onCommentVideo = { viewModel.commentOnVideo(context, it) },
                    accessToken = oauthAccessToken,
                    onDirectVerifiedSuccess = { campaign, coins ->
                        viewModel.claimVerifiedYouTubeReward(campaign, coins)
                    }
                )
                2 -> ProfileAndAdminScreen(
                    user = currentUser,
                    email = currentUserEmail,
                    isAdmin = isAdmin,
                    watchHistory = watchHistory,
                    onSwitchUser = { viewModel.switchUser(it) },
                    onOpenManageUsers = { showManageUsersDialog = true },
                    onOpenAllCampaigns = { showAllCampaignsDialog = true },
                    onOpenEconomySettings = { showEconomySettingsDialog = true },
                    onOpenUpdateSettings = { showUpdateSettingsDialog = true },
                    onOpenReload = { showReloadDialog = true },
                    onOpenAdminReloadManagement = { showAdminReloadManagementDialog = true },
                    pendingReloadCount = pendingReloadCount,
                    onOpenUserInspection = { targetEmail ->
                        inspectionTargetEmail = targetEmail
                        showUserInspectionDialog = true
                    },
                    onGrantBonusCoins = { viewModel.grantBonusCoins(currentUserEmail, it) },
                    onOpenCreateGlobalCampaign = { showCreateCampaignDialog = true },
                    onLogout = { viewModel.logout() }
                )
            }
        }
    }
}

    // Rewarded Ad Modal
    if (isWatchingAd) {
        AdRewardModal(
            countdown = adCountdown,
            onDismiss = { viewModel.dismissAd() }
        )
    }

    // Celebration Dialog on Coin Reward
    rewardCelebration?.let { (title, coinsWon) ->
        CelebrationDialog(
            title = title,
            coinsEarned = coinsWon,
            onDismiss = { viewModel.dismissCelebration() }
        )
    }

    // Create Campaign Dialog
    if (showCreateCampaignDialog) {
        CreateCampaignDialog(
            userCoins = userCoins,
            isAdmin = isAdmin,
            economyConfig = economyConfig,
            accessToken = oauthAccessToken,
            onDismiss = { showCreateCampaignDialog = false },
            onCreate = { url, title, channel, channelId, thumb, type, target, duration, cost, isAdminPriority, isGlobal ->
                viewModel.createCampaign(
                    videoUrl = url,
                    videoTitle = title,
                    channelName = channel,
                    thumbnailUrl = thumb,
                    campaignType = type,
                    targetCount = target,
                    durationSeconds = duration,
                    costPerAction = cost,
                    isAdminPriority = isAdminPriority,
                    isGlobal = isGlobal,
                    channelId = channelId,
                    onSuccess = { showCreateCampaignDialog = false }
                )
            }
        )
    }

    // Navigation Drawer Menu Dialog (Opened from top-left 3 lines hamburger menu)
    if (showNavDrawerMenu) {
        NavDrawerMenuDialog(
            user = currentUser,
            email = currentUserEmail,
            isAdmin = isPrimaryAdmin,
            pendingReloadCount = pendingReloadCount,
            onDismiss = { showNavDrawerMenu = false },
            onOpenReload = { showReloadDialog = true },
            onOpenProfile = { selectedTab = 2 },
            onOpenHistory = { selectedTab = 2 },
            onOpenHelp = {
                viewModel.openSupportChat()
                showSupportChat = true
            },
            onOpenAdminReloadManagement = { showAdminReloadManagementDialog = true },
            onOpenAdminManageUsers = { showManageUsersDialog = true },
            onOpenAdminEconomy = { showEconomySettingsDialog = true },
            onOpenAdminUpdateSettings = { showUpdateSettingsDialog = true },
            onLogout = { viewModel.logout() }
        )
    }

    // Mobile Reload Dialog for Users
    if (showReloadDialog) {
        UserReloadDialog(
            user = currentUser,
            economyConfig = economyConfig,
            userHistory = userReloadRequests,
            onDismiss = { showReloadDialog = false },
            onSubmitReload = { phone, operator, type, amountLkr ->
                viewModel.submitReloadRequest(
                    phoneNumber = phone,
                    operator = operator,
                    connectionType = type,
                    amountLkr = amountLkr,
                    onSuccess = {},
                    onError = {}
                )
            }
        )
    }

    // Admin Mobile Reload Management Dialog
    if (showAdminReloadManagementDialog) {
        AdminReloadManagementDialog(
            requests = allReloadRequests,
            economyConfig = economyConfig,
            onDismiss = { showAdminReloadManagementDialog = false },
            onApprove = { id -> viewModel.approveReloadRequest(id) },
            onReject = { id, reason -> viewModel.rejectReloadRequest(id, reason) },
            onToggleActive = { isActive -> viewModel.toggleReloadService(isActive) }
        )
    }

    // Admin Dialogs
    if (showManageUsersDialog) {
        AdminManageUsersDialog(
            users = allUsers,
            onDismiss = { showManageUsersDialog = false },
            onToggleBan = { email, banned -> viewModel.toggleUserBan(email, banned) },
            onModifyCoins = { email, delta -> viewModel.modifyUserCoins(email, delta) },
            onSetCoins = { email, newBalance -> viewModel.setUserCoins(email, newBalance) },
            onDeleteUser = { email -> viewModel.deleteUser(email) },
            onInspectUser = { targetEmail ->
                inspectionTargetEmail = targetEmail
                showUserInspectionDialog = true
            }
        )
    }

    if (showUserInspectionDialog) {
        AdminUserInspectionDialog(
            initialSearchEmail = inspectionTargetEmail,
            registeredEmails = allUsers.map { it.email },
            inspectedUser = inspectedUser,
            inspectedUserHistory = inspectedUserHistory,
            isSearching = isSearchingInspectedUser,
            searchError = inspectUserSearchError,
            onSearchEmail = { email -> viewModel.searchAndInspectUserInFirestore(email) },
            onUnbanUser = { email -> viewModel.adminUnbanInspectedUser(email) },
            onBanUser = { email, reason -> viewModel.adminBanInspectedUser(email, reason) },
            onSetCoins = { email, balance -> viewModel.adminSetInspectedUserCoins(email, balance) },
            onResetStrikes = { email -> viewModel.adminResetInspectedUserStrikes(email) },
            onDeleteUser = { email -> viewModel.adminDeleteInspectedUser(email) },
            onDismiss = {
                showUserInspectionDialog = false
                viewModel.clearInspectedUser()
            }
        )
    }

    if (showAllCampaignsDialog) {
        AdminActiveCampaignsDialog(
            campaigns = allCampaigns,
            onDismiss = { showAllCampaignsDialog = false },
            onToggleActive = { id, active -> viewModel.toggleCampaignStatus(id, active) },
            onDeleteCampaign = { viewModel.deleteCampaign(it) }
        )
    }

    if (showEconomySettingsDialog) {
        AdminEconomySettingsDialog(
            currentConfig = economyConfig,
            onDismiss = { showEconomySettingsDialog = false },
            onSave = { newConfig -> viewModel.updateEconomyConfig(newConfig) }
        )
    }

    // Admin App Updates & Push Notifications Dialog
    if (showUpdateSettingsDialog) {
        AdminUpdateSettingsDialog(
            currentConfig = appUpdateConfig,
            onDismiss = { showUpdateSettingsDialog = false },
            onPublishUpdate = { newConfig, sendNotification ->
                viewModel.publishAppUpdate(newConfig, sendNotification)
            },
            onClearUpdate = { viewModel.clearAppUpdate() }
        )
    }

    // Help & Support Chat Screen (Direct Chat with Admin + Screenshot Uploads)
    if (showSupportChat) {
        SupportChatScreen(
            currentUserEmail = currentUserEmail,
            isAdmin = isAdmin,
            activeChatEmail = activeChatUserEmail,
            messages = supportMessages,
            threads = supportThreads,
            isSending = isSendingChatMessage,
            isUploading = isUploadingChatImage,
            uploadProgressText = chatUploadProgress,
            onSendMessage = { text, uri, ctx ->
                viewModel.sendSupportMessage(text, uri, ctx)
            },
            onSelectThread = { targetEmail ->
                viewModel.selectSupportThread(targetEmail)
            },
            onClose = {
                showSupportChat = false
            }
        )
    }

    // Global User App Update & Announcement Dialog (Pops up when Admin publishes an update/notification)
    if (showUserUpdateDialog && !isPrimaryAdmin) {
        AppUpdateDialog(
            updateConfig = appUpdateConfig,
            isMandatory = isUpdateRequired,
            onDismiss = {
                showUserUpdateDialog = false
                lastDismissedUpdateTimestamp = appUpdateConfig.lastAnnouncedTimestamp
            },
            onUpdateVerified = {
                viewModel.simulateUpdateInstalled()
                showUserUpdateDialog = false
                lastDismissedUpdateTimestamp = appUpdateConfig.lastAnnouncedTimestamp
            }
        )
    }
}
