package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AdRewardModal
import com.example.ui.components.AdminActiveCampaignsDialog
import com.example.ui.components.AdminManageUsersDialog
import com.example.ui.components.CelebrationDialog
import com.example.ui.components.CoinBadge
import com.example.ui.components.CreateCampaignDialog
import com.example.ui.screens.CampaignScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.OtpVerificationScreen
import com.example.ui.screens.ProfileAndAdminScreen
import com.example.ui.screens.WatchAndEarnScreen
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.SubExchangeTheme
import com.example.ui.viewmodel.SubExchangeViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.data.firebase.FirebaseService.initialize(applicationContext)
        enableEdgeToEdge()
        setContent {
            SubExchangeTheme {
                SubExchangeAppRoot()
            }
        }
    }
}

@Composable
fun SubExchangeAppRoot(
    viewModel: SubExchangeViewModel = viewModel()
) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val isAuthenticating by viewModel.isAuthenticating.collectAsState()
    val pendingOtpEmail by viewModel.pendingOtpEmail.collectAsState()
    val latestDispatchedOtp by viewModel.latestDispatchedOtp.collectAsState()
    val isVerifyingOtp by viewModel.isVerifyingOtp.collectAsState()
    val otpErrorMessage by viewModel.otpErrorMessage.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    var initialDashboardTab by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(
                targetState = when {
                    isLoggedIn -> 2
                    pendingOtpEmail != null -> 1
                    else -> 0
                },
                animationSpec = tween(durationMillis = 350),
                label = "AuthNavCrossfade"
            ) { navState ->
                when (navState) {
                    0 -> LoginScreen(
                        isAuthenticating = isAuthenticating,
                        onLoginWithGoogle = { context, email ->
                            viewModel.startGoogleSignInAndSendOtp(context, email)
                        }
                    )
                    1 -> OtpVerificationScreen(
                        email = pendingOtpEmail ?: "",
                        latestDispatchedOtp = latestDispatchedOtp,
                        isVerifying = isVerifyingOtp,
                        errorMessage = otpErrorMessage,
                        onVerifyOtp = { enteredOtp ->
                            viewModel.verifyOtpAndCompleteLogin(enteredOtp) { isAdmin ->
                                initialDashboardTab = if (isAdmin) 2 else 0
                            }
                        },
                        onResendOtp = { viewModel.resendVerificationOtp() },
                        onCancel = { viewModel.cancelOtpVerification() }
                    )
                    else -> MainDashboard(
                        viewModel = viewModel,
                        initialTab = initialDashboardTab
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboard(
    viewModel: SubExchangeViewModel,
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    val currentUserEmail by viewModel.currentUserEmail.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val activeCampaigns by viewModel.activeCampaigns.collectAsState()
    val userCampaigns by viewModel.userCampaigns.collectAsState()
    val allCampaigns by viewModel.allCampaigns.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val watchHistory by viewModel.watchHistory.collectAsState()

    val selectedCampaign by viewModel.selectedCampaign.collectAsState()
    val isWatching by viewModel.isWatching.collectAsState()
    val remainingSeconds by viewModel.remainingSeconds.collectAsState()
    val totalSeconds by viewModel.totalWatchSeconds.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()
    val isLiked by viewModel.isLiked.collectAsState()
    val fastMode by viewModel.fastMode.collectAsState()

    val isWatchingAd by viewModel.isWatchingAd.collectAsState()
    val adCountdown by viewModel.adCountdown.collectAsState()

    val rewardCelebration by viewModel.rewardCelebration.collectAsState()

    val isVerifyingYouTube by viewModel.isVerifyingYouTube.collectAsState()
    val youTubeVerificationStatus by viewModel.youTubeVerificationStatus.collectAsState()
    val context = LocalContext.current

    var selectedTab by rememberSaveable { mutableIntStateOf(initialTab) }
    var showCreateCampaignDialog by remember { mutableStateOf(false) }
    var showManageUsersDialog by remember { mutableStateOf(false) }
    var showAllCampaignsDialog by remember { mutableStateOf(false) }

    val userCoins = currentUser?.coins ?: 100
    val dailyAdCount = currentUser?.dailyAdsWatched ?: 0
    val maxDailyAds = 15
    val isAdmin = currentUser?.isAdmin == true ||
            currentUserEmail.equals(com.example.data.firebase.FirebaseService.designatedAdminEmail, ignoreCase = true) ||
            currentUserEmail.equals("admin@gmail.com", ignoreCase = true) ||
            currentUserEmail.equals("amila940703@gmail.com", ignoreCase = true)

    // Handle back button: return to tab 0 before exiting
    BackHandler(enabled = selectedTab != 0) {
        selectedTab = 0
    }

    // Auto-select first campaign if none selected
    LaunchedEffect(activeCampaigns) {
        if (selectedCampaign == null && activeCampaigns.isNotEmpty()) {
            viewModel.selectCampaign(activeCampaigns.first())
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = if (isAdmin) "Admin Dashboard" else "SubExchange App",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 19.sp
                        )
                    )
                },
                actions = {
                    CoinBadge(
                        coins = userCoins,
                        modifier = Modifier.padding(end = 12.dp),
                        onClick = {
                            if (dailyAdCount < maxDailyAds) {
                                viewModel.watchRewardedAd()
                            }
                        }
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = if (isAdmin) RedPrimary else MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier.testTag("main_app_bar")
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.VideoLibrary, contentDescription = "Earn Watch") },
                    label = { Text("Earn Watch") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RedPrimary,
                        selectedTextColor = RedPrimary,
                        indicatorColor = RedPrimary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_earn_watch")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Campaign, contentDescription = "Campaigns") },
                    label = { Text("Campaigns") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RedPrimary,
                        selectedTextColor = RedPrimary,
                        indicatorColor = RedPrimary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_campaigns")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                    label = { Text("Profile") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RedPrimary,
                        selectedTextColor = RedPrimary,
                        indicatorColor = RedPrimary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("tab_profile")
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (selectedTab) {
                0 -> WatchAndEarnScreen(
                    currentCampaign = selectedCampaign,
                    activeCampaigns = activeCampaigns,
                    isWatching = isWatching,
                    remainingSeconds = remainingSeconds,
                    totalSeconds = totalSeconds,
                    isSubscribed = isSubscribed,
                    isLiked = isLiked,
                    fastMode = fastMode,
                    dailyAdsWatched = dailyAdCount,
                    maxDailyAds = maxDailyAds,
                    isVerifyingYouTube = isVerifyingYouTube,
                    youTubeVerificationStatus = youTubeVerificationStatus,
                    onStartWatching = { viewModel.startWatching() },
                    onStopWatching = { viewModel.stopWatching() },
                    onToggleSubscribe = { viewModel.toggleSubscribe() },
                    onToggleLike = { viewModel.toggleLike() },
                    onToggleFastMode = { viewModel.toggleFastMode() },
                    onSelectCampaign = { viewModel.selectCampaign(it) },
                    onWatchAd = { viewModel.watchRewardedAd() }
                )
                1 -> CampaignScreen(
                    userCoins = userCoins,
                    campaigns = userCampaigns,
                    onOpenCreateCampaign = { showCreateCampaignDialog = true },
                    onToggleActive = { id, active -> viewModel.toggleCampaignStatus(id, active) },
                    onDeleteCampaign = { viewModel.deleteCampaign(it) }
                )
                2 -> ProfileAndAdminScreen(
                    user = currentUser,
                    email = currentUserEmail,
                    isAdmin = isAdmin,
                    watchHistory = watchHistory,
                    onSwitchUser = { viewModel.switchUser(it) },
                    onOpenManageUsers = { showManageUsersDialog = true },
                    onOpenAllCampaigns = { showAllCampaignsDialog = true },
                    onGrantBonusCoins = { viewModel.grantBonusCoins(currentUserEmail, it) },
                    onOpenCreateGlobalCampaign = { showCreateCampaignDialog = true },
                    onLogout = { viewModel.logout() }
                )
            }
        }
    }

    // Rewarded Ad Modal
    if (isWatchingAd) {
        AdRewardModal(
            countdown = adCountdown,
            onDismiss = { viewModel.dismissAd() }
        )
    }

    // Celebration Dialog on Coin Reward
    rewardCelebration?.let { (title, coinsWon) ->
        CelebrationDialog(
            title = title,
            coinsEarned = coinsWon,
            onDismiss = { viewModel.dismissCelebration() }
        )
    }

    // Create Campaign Dialog
    if (showCreateCampaignDialog) {
        CreateCampaignDialog(
            userCoins = userCoins,
            isAdmin = isAdmin,
            onDismiss = { showCreateCampaignDialog = false },
            onCreate = { url, title, channel, thumb, type, target, duration, cost, isAdminPriority, isGlobal ->
                viewModel.createCampaign(
                    videoUrl = url,
                    videoTitle = title,
                    channelName = channel,
                    thumbnailUrl = thumb,
                    campaignType = type,
                    targetCount = target,
                    durationSeconds = duration,
                    costPerAction = cost,
                    isAdminPriority = isAdminPriority,
                    isGlobal = isGlobal,
                    onSuccess = { showCreateCampaignDialog = false }
                )
            }
        )
    }

    // Admin Dialogs
    if (showManageUsersDialog) {
        AdminManageUsersDialog(
            users = allUsers,
            onDismiss = { showManageUsersDialog = false },
            onToggleBan = { email, banned -> viewModel.toggleUserBan(email, banned) },
            onModifyCoins = { email, delta -> viewModel.modifyUserCoins(email, delta) },
            onDeleteUser = { email -> viewModel.deleteUser(email) }
        )
    }

    if (showAllCampaignsDialog) {
        AdminActiveCampaignsDialog(
            campaigns = allCampaigns,
            onDismiss = { showAllCampaignsDialog = false },
            onToggleActive = { id, active -> viewModel.toggleCampaignStatus(id, active) },
            onDeleteCampaign = { viewModel.deleteCampaign(it) }
        )
    }
}
