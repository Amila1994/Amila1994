package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("SubExchange", appName)
  }

  @Test
  fun `email validator rejects fake and dummy emails`() {
    val fakeEmails = listOf(
      "test@test.com",
      "fake@fake.com",
      "asdf@asdf.com",
      "user@tempmail.com",
      "spammer@mailinator.com",
      "123@abc.xyz",
      "a@b.c",
      "dummy@gmail.com",
      "test@gmail.com",
      "aaaaaaa@gmail.com"
    )
    for (email in fakeEmails) {
      val result = com.example.util.EmailValidator.validate(email)
      assertTrue("Expected $email to be rejected as fake/invalid", result is com.example.util.EmailValidator.Result.Invalid)
    }
  }

  @Test
  fun `email validator accepts legitimate emails and admin emails`() {
    val validEmails = listOf(
      "amilalasantha940703@gmail.com",
      "amila940703@gmail.com",
      "kasun.bandara98@gmail.com",
      "perera.gamage@yahoo.com",
      "nimal.sampath@outlook.com"
    )
    for (email in validEmails) {
      val result = com.example.util.EmailValidator.validate(email)
      assertTrue("Expected $email to be accepted as valid", result is com.example.util.EmailValidator.Result.Valid)
    }
  }
}
